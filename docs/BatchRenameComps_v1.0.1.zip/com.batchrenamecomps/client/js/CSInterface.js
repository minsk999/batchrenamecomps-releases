/**
 * CSInterface.js - Adobe CEP API (BatchRenameComps 전용 최소 구현)
 */

var SystemPath = {
    USER_DATA: "userData",
    EXTENSION: "extension",
    HOST_APPLICATION: "hostApplication"
};

function CSInterface() {
    try {
        var env = window.__adobe_cep__.getHostEnvironment();
        this.hostEnvironment = JSON.parse(env);
    } catch(e) {
        console.warn("[BRC] hostEnvironment 파싱 실패:", e);
        this.hostEnvironment = {};
    }
}

CSInterface.prototype.evalScript = function(script, callback) {
    if (!callback) callback = function() {};
    if (typeof window.__adobe_cep__ !== "undefined") {
        window.__adobe_cep__.evalScript(script, callback);
    } else {
        console.warn("[CEP] evalScript 불가:", script.substring(0, 80));
        callback("");
    }
};

CSInterface.prototype.getSystemPath = function(pathType) {
    try {
        var raw = window.__adobe_cep__.getSystemPath(pathType);
        return decodeURIComponent(raw)
            .replace(/^file:\/\/\/([A-Za-z]:)/, "$1")
            .replace(/^file:\/\//, "");
    } catch(e) { return ""; }
};

CSInterface.prototype.setPanelFlyoutMenu = function(xml) {
    try {
        if (window.__adobe_cep__) {
            // CEP 공식 방식
            window.__adobe_cep__.invokeSync("setPanelFlyoutMenu", xml);
        }
    } catch(e) {
        try {
            // 대안 방식
            if (typeof cep !== "undefined" && cep.flyout) {
                cep.flyout.setMenu(xml);
            }
        } catch(e2) {
            console.warn("[CEP] setPanelFlyoutMenu 불가:", e2);
        }
    }
};

CSInterface.prototype.addEventListener = function(type, callback) {
    try {
        if (window.__adobe_cep__) {
            window.__adobe_cep__.addEventListener(type, callback);
        }
    } catch(e) { console.warn("[CEP] addEventListener 불가:", e); }
};
