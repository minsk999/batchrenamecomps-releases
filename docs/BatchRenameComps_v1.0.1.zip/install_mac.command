#!/bin/bash
cd "$(dirname "$0")"

echo ""
echo "  ============================================"
echo "   BatchRenameComps 설치 (After Effects / Premiere Pro)"
echo "  ============================================"
echo ""

SRC="$(pwd)/com.batchrenamecomps"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/com.batchrenamecomps"

if [ ! -f "$SRC/CSXS/manifest.xml" ]; then
    echo "  [오류] 이 파일 옆에서 com.batchrenamecomps 폴더를 찾을 수 없어요."
    echo "  압축을 통째로 푼 뒤, 그 폴더 안에서 이 파일을 실행해 주세요."
    echo ""
    read -n 1 -s -r -p "  아무 키나 누르면 닫혀요..."
    exit 1
fi

echo "  확장 폴더에 복사 중:"
echo "    $DEST"
echo ""
rm -rf "$DEST"
mkdir -p "$(dirname "$DEST")"
cp -R "$SRC" "$DEST"

echo "  CEP 디버그 모드 켜는 중 (서명 없는 확장 허용)..."
for V in 9 10 11 12; do
    defaults write "com.adobe.CSXS.$V" PlayerDebugMode 1 >/dev/null 2>&1
done
killall cfprefsd >/dev/null 2>&1

if [ -f "$DEST/CSXS/manifest.xml" ]; then
    echo ""
    echo "  설치 완료!"
    echo "  After Effects / Premiere Pro를 완전히 종료한 뒤 다시 실행하세요."
    echo "  메뉴: 창 > 확장 > BatchRenameComps"
else
    echo ""
    echo "  [오류] 설치 실패. 팀장(구민석)에게 문의해 주세요."
fi
echo ""
read -n 1 -s -r -p "  아무 키나 누르면 닫혀요..."
echo ""
