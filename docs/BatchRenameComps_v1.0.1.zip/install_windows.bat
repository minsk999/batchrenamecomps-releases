@echo off
setlocal
title BatchRenameComps Installer

echo.
echo  ============================================
echo   BatchRenameComps Installer
echo   After Effects / Premiere Pro
echo  ============================================
echo.

set "SRC=%~dp0com.batchrenamecomps"
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.batchrenamecomps"

if not exist "%SRC%\CSXS\manifest.xml" (
    echo  [ERROR] Cannot find com.batchrenamecomps next to this file.
    echo  Please unzip the whole package and run this .bat from inside it.
    echo.
    pause
    exit /b 1
)

echo  Installing extension to:
echo    %DEST%
echo.
if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy /e /i /y /q "%SRC%" "%DEST%" >nul

echo  Enabling CEP debug mode (unsigned extension)...
for %%V in (9 10 11 12) do (
    reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
)

if exist "%DEST%\CSXS\manifest.xml" (
    echo.
    echo  Installation complete!
    echo  Quit After Effects / Premiere Pro completely, then reopen.
    echo  Open via: Window ^> Extensions ^> BatchRenameComps
) else (
    echo.
    echo  [ERROR] Install failed. Please contact the team lead.
)
echo.
pause
endlocal
