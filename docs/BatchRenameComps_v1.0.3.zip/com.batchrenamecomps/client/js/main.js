// ============================================================
// BatchRenameComps - main.js
// ============================================================

var cs;
try {
    cs = new CSInterface();
} catch(e) {
    console.error("[BRC] CSInterface 초기화 실패:", e);
}

// ── 커스텀 툴팁 (JS) ─────────────────────────────────────────
var _tooltipEl = null;
var STORAGE_KEY_TOOLTIPS = "brc_tooltips_enabled";
function tooltipsEnabled() {
    var v = localStorage.getItem(STORAGE_KEY_TOOLTIPS);
    return v === null ? true : v === "1";
}
function setTooltipsEnabled(on) {
    localStorage.setItem(STORAGE_KEY_TOOLTIPS, on ? "1" : "0");
}

// 렌더: 자동 출력(즉시 렌더 시작) 여부
var STORAGE_KEY_AUTORENDER = "brc_autorender_enabled";
function autoRenderEnabled() {
    var v = localStorage.getItem(STORAGE_KEY_AUTORENDER);
    return v === null ? false : v === "1"; // 기본 off (안전)
}
function setAutoRenderEnabled(on) {
    localStorage.setItem(STORAGE_KEY_AUTORENDER, on ? "1" : "0");
}
function showTooltip(target, text) {
    if (!tooltipsEnabled()) return;
    if (!_tooltipEl) {
        _tooltipEl = document.createElement("div");
        _tooltipEl.className = "brc-tooltip";
        document.body.appendChild(_tooltipEl);
    }
    _tooltipEl.textContent = text;
    var rect = target.getBoundingClientRect();
    // 일단 표시해야 크기를 잴 수 있음
    _tooltipEl.style.left = "0px";
    _tooltipEl.style.top = "0px";
    _tooltipEl.classList.add("show");
    var tw = _tooltipEl.offsetWidth;
    var th = _tooltipEl.offsetHeight;
    // 기본: 타겟 위쪽 가운데
    var left = rect.left + rect.width / 2 - tw / 2;
    var top = rect.top - th - 6;
    // 화면 위로 잘리면 아래로
    if (top < 4) top = rect.bottom + 6;
    // 가로 화면 밖이면 보정
    if (left < 4) left = 4;
    if (left + tw > window.innerWidth - 4) left = window.innerWidth - tw - 4;
    _tooltipEl.style.left = left + "px";
    _tooltipEl.style.top = top + "px";
}
function hideTooltip() {
    if (_tooltipEl) _tooltipEl.classList.remove("show");
}
function bindTooltip(el, text) {
    if (!el) return;
    var timer = null;
    el.addEventListener("mouseenter", function() {
        timer = setTimeout(function() { showTooltip(el, text); }, 300);
    });
    el.addEventListener("mouseleave", function() {
        if (timer) clearTimeout(timer);
        hideTooltip();
    });
    el.addEventListener("mousedown", function() {
        if (timer) clearTimeout(timer);
        hideTooltip();
    });
}

// Shift 키 상태 전역 추적
var _shiftHeld = false;
document.addEventListener("keydown", function(e) {
    if (e.key === "Shift" || e.keyCode === 16) _shiftHeld = true;
});

// 마우스 4,5번 키로 설정창 토글
document.addEventListener("mousedown", function(e) {
    if (e.button === 3 || e.button === 4) {
        e.preventDefault();
        e.stopPropagation();
        var isSettings = document.getElementById("settingsScreen").classList.contains("slide-in");
        if (isSettings) closeSettings(); else openSettings();
    }
});
document.addEventListener("keyup", function(e) {
    if (e.key === "Shift" || e.keyCode === 16) _shiftHeld = false;
});

// ── 설정 화면 전환 ───────────────────────────────────────────
function setSettingsTabIndex(active) {
    var els = document.querySelectorAll("#settingsScreen input, #settingsScreen button, #settingsScreen select");
    els.forEach(function(el) { el.tabIndex = active ? 0 : -1; });
}
function setMainTabIndex(active) {
    var els = document.querySelectorAll("#mainScreen input, #mainScreen button, #mainScreen select");
    els.forEach(function(el) {
        // 기존 tabindex 값 유지 (icon-btn 등 -1인 것들 그대로)
        if (!active) {
            el.dataset.origTab = el.tabIndex;
            el.tabIndex = -1;
        } else {
            if (el.dataset.origTab !== undefined) {
                el.tabIndex = parseInt(el.dataset.origTab);
            }
        }
    });
}

function openSettings() {
    document.getElementById("mainScreen").classList.add("slide-out");
    document.getElementById("settingsScreen").classList.add("slide-in");
    setMainTabIndex(false);
    setSettingsTabIndex(true);
    renderResPresets();
    renderTreeSelector();
    loadImportPath();
}
function closeSettings() {
    document.getElementById("mainScreen").classList.remove("slide-out");
    document.getElementById("settingsScreen").classList.remove("slide-in");
    setSettingsTabIndex(false);
    setMainTabIndex(true);
    applyResPresets();
}

// ── Flyout 메뉴 (햄버거) ────────────────────────────────────
function setupFlyoutMenu() {
    try {
        var xml = '<Menu><MenuItem Id="settings" Label="\uC124\uC815" Enabled="true" Checked="false"/>'
                + '<MenuItem Id="checkUpdate" Label="\uC5C5\uB370\uC774\uD2B8 \uD655\uC778" Enabled="true" Checked="false"/></Menu>';
        window.__adobe_cep__.invokeSync("setPanelFlyoutMenu", xml);
        window.__adobe_cep__.addEventListener("com.adobe.csxs.events.flyoutMenuClicked", function(e) {
            try {
                var data = JSON.parse(e);
                var mid = data && data.data ? data.data.menuId : null;
                if (mid === "settings") openSettings();
                else if (mid === "checkUpdate" && window.brcCheckUpdate) window.brcCheckUpdate();
            } catch(err) {
                var m2 = e && e.data ? e.data.menuId : null;
                if (m2 === "settings") openSettings();
                else if (m2 === "checkUpdate" && window.brcCheckUpdate) window.brcCheckUpdate();
            }
        });
    } catch(e) {
        console.warn("[BRC] Flyout 메뉴 설정 실패:", e);
    }
}

// ── 컨텍스트 메뉴 ────────────────────────────────────────────
var ctxMenu = document.getElementById("ctxMenu");

function showCtxMenu(x, y) {
    ctxMenu.classList.add("show");
    // 먼저 위치 초기화 후 크기 측정
    ctxMenu.style.left = "0px";
    ctxMenu.style.top = "0px";
    ctxMenu.style.maxHeight = "";
    var rect = ctxMenu.getBoundingClientRect();
    var W = window.innerWidth;
    var H = window.innerHeight;
    var margin = 4;

    var mw = rect.width;
    var mh = rect.height;

    // 가로 위치: 오른쪽으로 넘치면 왼쪽으로, 그래도 넘치면 우측 경계에 붙임
    var left = x;
    if (left + mw > W - margin) left = x - mw;
    if (left < margin) left = W - mw - margin;
    if (left < margin) left = margin;

    // 세로 위치: 아래로 넘치면 위로, 그래도 넘치면 상단 경계 + 스크롤
    var top = y;
    if (top + mh > H - margin) top = y - mh;
    if (top < margin) {
        top = margin;
        // 패널보다 메뉴가 더 크면 최대 높이 제한 + 스크롤
        if (mh > H - margin * 2) {
            ctxMenu.style.maxHeight = (H - margin * 2) + "px";
            ctxMenu.style.overflowY = "auto";
        }
    }

    ctxMenu.style.left = left + "px";
    ctxMenu.style.top  = top + "px";
}
function hideCtxMenu() { ctxMenu.classList.remove("show"); }

document.addEventListener("click", function(e) {
    // 컨텍스트 메뉴 내부 클릭이면 닫지 않음 (드롭다운/버튼 조작 허용)
    if (ctxMenu.contains(e.target)) return;
    hideCtxMenu();
});
document.addEventListener("contextmenu", function(e) { e.preventDefault(); });

// ── 해상도 프리셋 관리 ───────────────────────────────────────
var STORAGE_KEY_RES = "brc_res_presets";
function getResPresets() {
    try {
        var raw = localStorage.getItem(STORAGE_KEY_RES);
        if (raw) return JSON.parse(raw);
    } catch(e) {}
    return RES_LIST.slice(1); // 기본값 (None 제외)
}
function saveResPresets(list) {
    try { localStorage.setItem(STORAGE_KEY_RES, JSON.stringify(list)); } catch(e) {}
}
function applyResPresets() {
    var presets = getResPresets();
    var sel = $("resolution");
    var curVal = sel.value;
    fillSelect(sel, ["None"].concat(presets));
    // 기존 선택값 유지
    setSelect("resolution", curVal.replace(/\s*\(.*\)$/, ""));
}

function renderResPresets() {
    var presets = getResPresets();
    var list = document.getElementById("resPresetList");
    list.innerHTML = "";
    presets.forEach(function(item, idx) {
        var row = document.createElement("div");
        row.className = "res-preset-item";
        row.draggable = true;
        row.dataset.idx = idx;

        var handle = document.createElement("span");
        handle.className = "drag-handle";
        handle.innerHTML = '<svg><use href="#ico-drag"/></svg>';

        var text = document.createElement("span");
        text.className = "res-preset-text";
        text.textContent = item;

        var del = document.createElement("button");
        del.className = "res-delete-btn";
        del.innerHTML = '<svg><use href="#ico-delete"/></svg>';
        del.addEventListener("click", function() {
            customConfirm("'" + item + "' 해상도를 삭제할까요?", function(ok) {
                if (!ok) return;
                var cur = getResPresets();
                cur.splice(idx, 1);
                saveResPresets(cur);
                renderResPresets();
            });
        });

        row.appendChild(handle);
        row.appendChild(text);
        row.appendChild(del);
        list.appendChild(row);

        // 드래그 이벤트
        row.addEventListener("dragstart", function() {
            this.classList.add("dragging");
            list.dataset.dragFrom = idx;
        });
        row.addEventListener("dragend", function() {
            this.classList.remove("dragging");
            document.querySelectorAll(".res-preset-item").forEach(function(el) {
                el.classList.remove("drag-over");
            });
        });
        row.addEventListener("dragover", function(e) {
            e.preventDefault();
            document.querySelectorAll(".res-preset-item").forEach(function(el) {
                el.classList.remove("drag-over");
            });
            this.classList.add("drag-over");
        });
        row.addEventListener("drop", function(e) {
            e.preventDefault();
            var from = parseInt(list.dataset.dragFrom);
            var to = parseInt(this.dataset.idx);
            if (from === to) return;
            var moved = presets.splice(from, 1)[0];
            presets.splice(to, 0, moved);
            saveResPresets(presets);
            renderResPresets();
        });
    });
}

// ── 임포트 경로 관리 ─────────────────────────────────────────
var STORAGE_KEY_IMPORT = "brc_import_path";

function loadImportPath() {
    var path = localStorage.getItem(STORAGE_KEY_IMPORT) || "";
    document.getElementById("importPathInput").value = path;
    var lpath = localStorage.getItem(STORAGE_KEY_LOCALTREE) || "";
    document.getElementById("localTreePathInput").value = lpath;
}
function saveImportPath(path) {
    localStorage.setItem(STORAGE_KEY_IMPORT, path);
}
function getImportPath() {
    return localStorage.getItem(STORAGE_KEY_IMPORT) || "";
}

var STORAGE_KEY_LOCALTREE = "brc_localtree_path";
function saveLocalTreePath(path) {
    localStorage.setItem(STORAGE_KEY_LOCALTREE, path);
}
function getLocalTreePath() {
    return localStorage.getItem(STORAGE_KEY_LOCALTREE) || "";
}

// 마지막으로 생성한 로컬 폴더트리 경로
var STORAGE_KEY_LASTTREE = "brc_last_created_tree";
function saveLastCreatedTreePath(path) {
    localStorage.setItem(STORAGE_KEY_LASTTREE, path);
}
function getLastCreatedTreePath() {
    return localStorage.getItem(STORAGE_KEY_LASTTREE) || "";
}

// 저장 기록 (최근 저장한 파일 경로 목록, 최신순, 최대 50개)
var STORAGE_KEY_SAVEHIST = "brc_save_history";
function getSaveHistory() {
    try {
        var raw = localStorage.getItem(STORAGE_KEY_SAVEHIST);
        if (raw) {
            var arr = JSON.parse(raw);
            if (arr && arr.length) return arr;
        }
    } catch(e) {}
    return [];
}
function addSaveHistory(fullPath) {
    if (!fullPath) return;
    var hist = getSaveHistory();
    // 이미 있으면 제거 후 맨 앞으로
    hist = hist.filter(function(p) { return p !== fullPath; });
    hist.unshift(fullPath);
    if (hist.length > 50) hist = hist.slice(0, 50);
    try { localStorage.setItem(STORAGE_KEY_SAVEHIST, JSON.stringify(hist)); } catch(e) {}
}
// 저장 기록에서 특정 경로 제거 (파일이 이동/삭제됐을 때 정리용)
function removeSaveHistory(fullPath) {
    if (!fullPath) return;
    var hist = getSaveHistory();
    hist = hist.filter(function(p) { return p !== fullPath; });
    try { localStorage.setItem(STORAGE_KEY_SAVEHIST, JSON.stringify(hist)); } catch(e) {}
}
// 경로에서 파일명만 추출
function basenameFromPath(p) {
    if (!p) return "";
    var parts = p.split(/[\\\/]/);
    return parts[parts.length - 1] || p;
}

// 오늘 날짜 YYMMDD
function todayYYMMDD() {
    var d = new Date();
    var yy = String(d.getFullYear()).slice(2);
    var mm = ("0" + (d.getMonth() + 1)).slice(-2);
    var dd = ("0" + d.getDate()).slice(-2);
    return yy + mm + dd;
}

// ── 폴더트리 데이터 ──────────────────────────────────────────
var STORAGE_KEY_TREES = "brc_folder_trees";
var STORAGE_KEY_SEL_AE = "brc_sel_ae_tree";

// 폴더 버튼이 사용할 "현재 선택된 프로젝트(ae) 트리" id
function getSelectedAeTreeId() {
    return localStorage.getItem(STORAGE_KEY_SEL_AE) || "";
}
function setSelectedAeTreeId(id) {
    localStorage.setItem(STORAGE_KEY_SEL_AE, id);
}
// 선택된 ae 트리 객체 반환 (없으면 첫 ae 트리)
function getSelectedAeTree() {
    var trees = getTrees();
    var id = getSelectedAeTreeId();
    if (id) {
        for (var i = 0; i < trees.length; i++) {
            if (trees[i].id === id && trees[i].type === "ae") return trees[i];
        }
    }
    for (var j = 0; j < trees.length; j++) {
        if (trees[j].type === "ae") return trees[j];
    }
    return null;
}

var STORAGE_KEY_SEL_LOCAL = "brc_sel_local_tree";
function getSelectedLocalTreeId() {
    return localStorage.getItem(STORAGE_KEY_SEL_LOCAL) || "";
}
function setSelectedLocalTreeId(id) {
    localStorage.setItem(STORAGE_KEY_SEL_LOCAL, id);
}
// 선택된 로컬 트리 객체 반환 (없으면 첫 로컬 트리)
function getSelectedLocalTree() {
    var trees = getTrees();
    var id = getSelectedLocalTreeId();
    if (id) {
        for (var i = 0; i < trees.length; i++) {
            if (trees[i].id === id && trees[i].type === "local") return trees[i];
        }
    }
    for (var j = 0; j < trees.length; j++) {
        if (trees[j].type === "local") return trees[j];
    }
    return null;
}

// 기본 트리 정의 (node: {name, children:[]})
function defaultTrees() {
    // n(name, children, ext) - ext는 확장자/특수태그 배열
    function n(name, children, ext) {
        var node = { name: name, children: children || [] };
        if (ext && ext.length) node.extensions = ext;
        return node;
    }
    return [
        {
            id: "ae_full", type: "ae", label: "프로젝트 폴더트리",
            nodes: [
                n("00_Master"), 
                n("01_Comp", [n("_Main", [], ["[comp]"]), n("Etc")]),
                n("02_Sc", [
                    n("Image", [
                        n("LOGO"),
                        n("Rester", [], ["jpg","jpeg","png","gif","bmp","tif","tiff","tga","exr","hdr","dpx","cin","psd","psb"]),
                        n("Vector", [], ["ai","eps","svg","pdf"])
                    ]),
                    n("Project", [], ["aep","aet"]),
                    n("Video", [
                        n("Original", [], ["mp4","mov","avi","wmv","mkv","mxf","r3d","braw","m4v","m2v","webm"]),
                        n("Render"),
                        n("Source")
                    ])
                ]),
                n("03_Mix", [n("BGM"), n("Nar"), n("SE")], ["mp3","wma","wav","aif","aiff","m4a","flac","ogg","aac"]),
                n("Ref")
            ]
        },
        {
            id: "ae_simple", type: "ae", label: "프로젝트 폴더트리 심플",
            nodes: [
                n("00_Master"),
                n("01_Comp", [], ["[comp]"]),
                n("02_Sc", [
                    n("Image", [], ["jpg","jpeg","png","gif","bmp","tif","tiff","tga","exr","hdr","dpx","cin","psd","psb","ai","eps","svg","pdf"]),
                    n("Video", [], ["mp4","mov","avi","wmv","mkv","mxf","r3d","braw","m4v","m2v","webm","mp3","wma","wav","aif","aiff","m4a","flac","ogg","aac"])
                ]),
                n("03_Ref")
            ]
        },
        {
            id: "local_full", type: "local", label: "로컬 폴더트리",
            nodes: [
                n("00_Master"), n("01_Doc"), n("02_Ref"), n("03_Ae"), n("04_Pr"),
                n("05_Sc", [
                    n("Image", [n("LOGO"), n("Raster"), n("Vector")]),
                    n("Project"),
                    n("Video", [n("Original"), n("Render"), n("Source")])
                ]),
                n("06_Mix", [n("BGM"), n("Nar"), n("SE")])
            ]
        },
        {
            id: "local_simple", type: "local", label: "로컬 폴더트리 심플",
            nodes: [
                n("00_Master"), n("01_Pr"), n("02_Ae"),
                n("03_Sc", [n("Image"), n("Video")]),
                n("04_Ref")
            ]
        }
    ];
}

function getTrees() {
    try {
        var raw = localStorage.getItem(STORAGE_KEY_TREES);
        if (raw) {
            var parsed = JSON.parse(raw);
            if (parsed && parsed.length) {
                // 구 라벨 마이그레이션
                var changed = false;
                parsed.forEach(function(t) {
                    if (t.label === "AE 폴더트리") { t.label = "프로젝트 폴더트리"; changed = true; }
                    else if (t.label === "AE 폴더트리 심플") { t.label = "프로젝트 폴더트리 심플"; changed = true; }
                });

                // 확장자 매핑 마이그레이션: 기본 트리에 확장자가 하나도 없으면 기본값 주입
                var defs = defaultTrees();
                parsed.forEach(function(t) {
                    if (t.type !== "ae") return;
                    // 이 트리에 확장자가 이미 하나라도 있으면 건드리지 않음 (사용자 커스텀 보존)
                    var hasAnyExt = false;
                    (function scan(arr) {
                        for (var i = 0; i < arr.length; i++) {
                            if (arr[i].extensions && arr[i].extensions.length) hasAnyExt = true;
                            if (arr[i].children) scan(arr[i].children);
                        }
                    })(t.nodes);
                    if (hasAnyExt) return;
                    // 같은 id의 기본 트리 찾아서 이름이 같은 노드에 확장자 복사
                    var def = null;
                    for (var d = 0; d < defs.length; d++) if (defs[d].id === t.id) { def = defs[d]; break; }
                    if (!def) return;
                    // 기본 트리의 이름→확장자 맵
                    var nameExt = {};
                    (function collect(arr) {
                        for (var i = 0; i < arr.length; i++) {
                            if (arr[i].extensions && arr[i].extensions.length)
                                nameExt[arr[i].name.toLowerCase()] = arr[i].extensions;
                            if (arr[i].children) collect(arr[i].children);
                        }
                    })(def.nodes);
                    // 사용자 트리 노드에 주입
                    (function inject(arr) {
                        for (var i = 0; i < arr.length; i++) {
                            var key = arr[i].name.toLowerCase();
                            if (nameExt[key]) { arr[i].extensions = nameExt[key].slice(); changed = true; }
                            if (arr[i].children) inject(arr[i].children);
                        }
                    })(t.nodes);
                });

                if (changed) {
                    try { localStorage.setItem(STORAGE_KEY_TREES, JSON.stringify(parsed)); } catch(e) {}
                }
                return parsed;
            }
        }
    } catch(e) {}
    return defaultTrees();
}
function saveTrees(trees) {
    try { localStorage.setItem(STORAGE_KEY_TREES, JSON.stringify(trees)); } catch(e) {}
}
function getTreeById(id) {
    var trees = getTrees();
    for (var i = 0; i < trees.length; i++) if (trees[i].id === id) return trees[i];
    return null;
}

// path 배열로 노드 찾기 ([0,2,1] = nodes[0].children[2].children[1])
function getNodeByPath(nodes, path) {
    var cur = { children: nodes };
    for (var i = 0; i < path.length; i++) {
        if (!cur.children || !cur.children[path[i]]) return null;
        cur = cur.children[path[i]];
    }
    return cur;
}
// path의 부모 children 배열과 마지막 인덱스 반환
function getParentArr(nodes, path) {
    if (path.length === 1) return { arr: nodes, idx: path[0] };
    var parent = getNodeByPath(nodes, path.slice(0, -1));
    if (!parent) return null;
    if (!parent.children) parent.children = [];
    return { arr: parent.children, idx: path[path.length - 1] };
}

// 현재 트리에 변경 저장
function saveCurrentTree(tree) {
    var trees = getTrees();
    trees[_curTreeIdx] = tree;
    saveTrees(trees);
}

// 현재 편집 중인 트리 인덱스
var _curTreeIdx = 0;

// 트리 셀렉터 렌더링
function renderTreeSelector() {
    var trees = getTrees();
    if (_curTreeIdx >= trees.length) _curTreeIdx = trees.length - 1;
    if (_curTreeIdx < 0) _curTreeIdx = 0;
    var sel = document.getElementById("treeSelect");
    sel.innerHTML = "";
    trees.forEach(function(t, i) {
        var opt = document.createElement("option");
        opt.value = i;
        opt.textContent = t.label;
        if (i === _curTreeIdx) opt.selected = true;
        sel.appendChild(opt);
    });

    // 닷 인디케이터
    var dots = document.getElementById("treeDots");
    if (dots) {
        dots.innerHTML = "";
        if (trees.length > 1) {
            trees.forEach(function(t, i) {
                var dot = document.createElement("div");
                dot.className = "tree-dot" + (i === _curTreeIdx ? " active" : "");
                bindTooltip(dot, t.label);
                dot.addEventListener("click", function() {
                    _curTreeIdx = i;
                    renderTreeSelector();
                });
                dots.appendChild(dot);
            });
        }
    }

    var cur = trees[_curTreeIdx];
    document.getElementById("treeTypeBadge").textContent =
        cur ? (cur.type === "ae" ? "\uD504\uB85C\uC81D\uD2B8 \uD3F4\uB354\uD2B8\uB9AC" : "\uB85C\uCEEC \uD3F4\uB354\uD2B8\uB9AC") : "";
    renderTreeNodes();
}

// 트리 노드 렌더링 (1단계: 표시 + 기본 버튼)
function renderTreeNodes() {
    var trees = getTrees();
    var tree = trees[_curTreeIdx];
    var list = document.getElementById("treeNodeList");
    list.innerHTML = "";
    if (!tree) return;

    function renderNode(node, path, depth) {
        var row = document.createElement("div");
        row.className = "tree-node-row";
        row.style.paddingLeft = (4 + depth * 16) + "px";
        row.dataset.path = path.join(",");

        var handle = document.createElement("span");
        handle.className = "tree-node-handle";
        handle.innerHTML = '<svg><use href="#ico-drag"/></svg>';

        var name = document.createElement("span");
        name.className = "tree-node-name";
        name.textContent = node.name;

        var addBtn = document.createElement("button");
        addBtn.className = "tree-node-btn";
        addBtn.innerHTML = '<svg><use href="#ico-plus"/></svg>';
        bindTooltip(addBtn, "하위 폴더 추가");
        addBtn.addEventListener("click", function() {
            var p = path.slice();
            customPrompt("추가할 하위 폴더 이름:", "새폴더", function(newName) {
                if (!newName) return;
                newName = newName.trim();
                if (!newName) return;
                var trees = getTrees();
                var t = trees[_curTreeIdx];
                var target = getNodeByPath(t.nodes, p);
                if (!target) return;
                if (!target.children) target.children = [];
                target.children.push({ name: newName, children: [] });
                saveTrees(trees);
                renderTreeNodes();
                syncCtxMenu();
            });
        });

        var editBtn = document.createElement("button");
        editBtn.className = "tree-node-btn";
        editBtn.innerHTML = '<svg><use href="#ico-edit"/></svg>';
        bindTooltip(editBtn, "이름 변경");
        editBtn.addEventListener("click", function() {
            startInlineEdit(row, name, node, path.slice());
        });

        var delBtn = document.createElement("button");
        delBtn.className = "tree-node-btn";
        delBtn.innerHTML = '<svg><use href="#ico-delete"/></svg>';
        bindTooltip(delBtn, "삭제");
        delBtn.addEventListener("click", function() {
            var p = path.slice();
            var hasChildren = node.children && node.children.length > 0;
            var msg = hasChildren
                ? "'" + node.name + "' 폴더와 하위 폴더를 모두 삭제할까요?"
                : "'" + node.name + "' 폴더를 삭제할까요?";
            customConfirm(msg, function(ok) {
                if (!ok) return;
                var trees = getTrees();
                var t = trees[_curTreeIdx];
                var pa = getParentArr(t.nodes, p);
                if (pa) {
                    pa.arr.splice(pa.idx, 1);
                    saveTrees(trees);
                    renderTreeNodes();
                    syncCtxMenu();
                }
            });
        });

        row.appendChild(handle);
        row.appendChild(name);

        // 확장자 매핑 (AE 타입 트리만)
        if (tree.type === "ae") {
            var extCount = (node.extensions && node.extensions.length) ? node.extensions.length : 0;
            var extBtn = document.createElement("button");
            extBtn.className = "tree-node-ext" + (extCount > 0 ? " has-ext" : "");
            extBtn.textContent = extCount > 0 ? ("ext " + extCount) : "ext";
            bindTooltip(extBtn, "이 폴더로 자동 분류할 확장자 관리");
            extBtn.addEventListener("click", function() {
                editNodeExtensions(node, path.slice());
            });
            row.appendChild(extBtn);
        }

        row.appendChild(addBtn);
        row.appendChild(editBtn);
        row.appendChild(delBtn);
        list.appendChild(row);

        // 드래그 시작 - 핸들에서만 시작 가능
        row.draggable = true;
        var dragPath = path.slice();
        row.addEventListener("dragstart", function(e) {
            _dragSrcPath = dragPath;
            _dragSrcRow = row;
            row.classList.add("dragging");
            try { e.dataTransfer.effectAllowed = "move"; } catch(_) {}
        });
        row.addEventListener("dragend", function() {
            row.classList.remove("dragging");
            clearDragHints();
            _dragSrcPath = null;
            _dragSrcRow = null;
        });
        row.addEventListener("dragover", function(e) {
            if (!_dragSrcPath) return;
            // 자기 자신이나 자식 위로 드래그하면 무시 (순환 방지)
            if (isAncestorPath(_dragSrcPath, dragPath)) return;
            e.preventDefault();
            try { e.dataTransfer.dropEffect = "move"; } catch(_) {}
            clearDragHints();
            var rect = row.getBoundingClientRect();
            var y = e.clientY - rect.top;
            var h = rect.height;
            if (y < h * 0.25) {
                row.classList.add("drag-over-before");
                _dropMode = "before";
            } else if (y > h * 0.75) {
                row.classList.add("drag-over-after");
                _dropMode = "after";
            } else {
                row.classList.add("drag-over-into");
                _dropMode = "into";
            }
            _dropTargetPath = dragPath;
        });
        row.addEventListener("dragleave", function() {
            row.classList.remove("drag-over-before");
            row.classList.remove("drag-over-after");
            row.classList.remove("drag-over-into");
        });
        row.addEventListener("drop", function(e) {
            if (!_dragSrcPath) return;
            e.preventDefault();
            e.stopPropagation();
            performDrop(_dragSrcPath, _dropTargetPath, _dropMode);
            clearDragHints();
            _dragSrcPath = null;
        });

        // 자식 재귀
        if (node.children && node.children.length) {
            for (var i = 0; i < node.children.length; i++) {
                renderNode(node.children[i], path.concat(i), depth + 1);
            }
        }
    }

    for (var i = 0; i < tree.nodes.length; i++) {
        renderNode(tree.nodes[i], [i], 0);
    }

    // 리스트 빈 영역에 드롭 → 최상위 맨 끝에 추가
    list.ondragover = function(e) {
        if (!_dragSrcPath) return;
        if (e.target === list) {
            e.preventDefault();
            try { e.dataTransfer.dropEffect = "move"; } catch(_) {}
        }
    };
    list.ondrop = function(e) {
        if (!_dragSrcPath) return;
        if (e.target !== list) return;
        e.preventDefault();
        // 최상위 맨 끝에 추가 = 마지막 노드의 after
        var lastIdx = tree.nodes.length - 1;
        if (lastIdx >= 0) {
            performDrop(_dragSrcPath, [lastIdx], "after");
        }
        clearDragHints();
        _dragSrcPath = null;
    };
}

// ── 드래그 상태 + 헬퍼 ───────────────────────────────────────
var _dragSrcPath = null;
var _dragSrcRow = null;
var _dropTargetPath = null;
var _dropMode = null;

function clearDragHints() {
    var nodes = document.querySelectorAll(".tree-node-row");
    for (var i = 0; i < nodes.length; i++) {
        nodes[i].classList.remove("drag-over-before");
        nodes[i].classList.remove("drag-over-after");
        nodes[i].classList.remove("drag-over-into");
    }
}

// targetPath가 srcPath의 자식인지 (자기 자신 포함) — 순환 방지용
function isAncestorPath(srcPath, targetPath) {
    if (targetPath.length < srcPath.length) return false;
    for (var i = 0; i < srcPath.length; i++) {
        if (srcPath[i] !== targetPath[i]) return false;
    }
    return true;
}

// 드롭 실행
function performDrop(srcPath, targetPath, mode) {
    if (!srcPath || !targetPath || !mode) return;
    if (isAncestorPath(srcPath, targetPath)) return;

    var trees = getTrees();
    var tree = trees[_curTreeIdx];

    // 1) 소스 노드 추출 (제거)
    var srcParentArr, srcIdx;
    if (srcPath.length === 1) {
        srcParentArr = tree.nodes;
        srcIdx = srcPath[0];
    } else {
        var srcParent = getNodeByPath(tree.nodes, srcPath.slice(0, -1));
        if (!srcParent) return;
        srcParentArr = srcParent.children;
        srcIdx = srcPath[srcPath.length - 1];
    }
    var srcNode = srcParentArr[srcIdx];
    if (!srcNode) return;
    srcParentArr.splice(srcIdx, 1);

    // 2) 타겟 path 보정 — 소스 제거로 인덱스가 밀린 경우
    var adjusted = targetPath.slice();
    // 같은 부모 안에서 srcIdx 이전 위치 → 그대로, srcIdx 이후 위치 → -1
    if (srcPath.length <= adjusted.length) {
        var sameParent = true;
        for (var i = 0; i < srcPath.length - 1; i++) {
            if (srcPath[i] !== adjusted[i]) { sameParent = false; break; }
        }
        if (sameParent) {
            var srcLastIdx = srcPath[srcPath.length - 1];
            var adjAtLevel = adjusted[srcPath.length - 1];
            if (adjAtLevel > srcLastIdx) adjusted[srcPath.length - 1] = adjAtLevel - 1;
        }
    }

    // 3) 모드별 삽입
    if (mode === "into") {
        var into = getNodeByPath(tree.nodes, adjusted);
        if (!into) {
            // 실패 → 롤백
            srcParentArr.splice(srcIdx, 0, srcNode);
            return;
        }
        if (!into.children) into.children = [];
        into.children.push(srcNode);
    } else {
        // before / after
        var tParentArr, tIdx;
        if (adjusted.length === 1) {
            tParentArr = tree.nodes;
            tIdx = adjusted[0];
        } else {
            var tParent = getNodeByPath(tree.nodes, adjusted.slice(0, -1));
            if (!tParent || !tParent.children) {
                srcParentArr.splice(srcIdx, 0, srcNode);
                return;
            }
            tParentArr = tParent.children;
            tIdx = adjusted[adjusted.length - 1];
        }
        var insertAt = (mode === "before") ? tIdx : tIdx + 1;
        tParentArr.splice(insertAt, 0, srcNode);
    }

    saveTrees(trees);
    renderTreeNodes();
    syncCtxMenu();
}

// 인라인 이름 편집
function startInlineEdit(row, nameSpan, node, path) {
    var input = document.createElement("input");
    input.className = "tree-node-name-input";
    input.value = node.name;
    row.replaceChild(input, nameSpan);
    input.focus();
    input.select();

    var done = false;
    function commit(save) {
        if (done) return;
        done = true;
        if (save) {
            var v = input.value.trim();
            if (v) {
                var trees = getTrees();
                var t = trees[_curTreeIdx];
                var target = getNodeByPath(t.nodes, path);
                if (target) {
                    target.name = v;
                    saveTrees(trees);
                    syncCtxMenu();
                }
            }
        }
        renderTreeNodes();
    }
    input.addEventListener("keydown", function(e) {
        if (isComposingKey(e)) return;
        if (e.key === "Enter") { e.preventDefault(); commit(true); }
        else if (e.key === "Escape") { e.preventDefault(); commit(false); }
    });
    input.addEventListener("blur", function() { commit(true); });
}

// 최상위 폴더 추가
// 노드 확장자 편집
function editNodeExtensions(node, path) {
    var cur = (node.extensions && node.extensions.length) ? node.extensions.join(", ") : "";
    showExtDialog(node.name, cur, function(result) {
        if (result === null) return; // 취소
        // 파싱: 콤마/공백/줄바꿈으로 분리, 정리
        var arr = result.split(/[,\s]+/)
            .map(function(s) { return s.trim().toLowerCase(); })
            .filter(function(s) { return s.length > 0; })
            .map(function(s) {
                // 특수태그가 아니면 앞의 점 제거 (.jpg → jpg)
                if (s.charAt(0) === "[") return s;
                return s.replace(/^\./, "");
            });
        // 중복 제거
        var seen = {};
        var uniq = [];
        for (var i = 0; i < arr.length; i++) {
            if (!seen[arr[i]]) { seen[arr[i]] = 1; uniq.push(arr[i]); }
        }
        var trees = getTrees();
        var t = trees[_curTreeIdx];
        var target = getNodeByPath(t.nodes, path);
        if (!target) return;
        if (uniq.length) target.extensions = uniq;
        else delete target.extensions;
        saveTrees(trees);
        renderTreeNodes();
    });
}

// 확장자 편집 다이얼로그
function showExtDialog(folderName, currentValue, callback) {
    var overlay = document.getElementById("extDialog");
    var field = document.getElementById("extDialogField");
    var okBtn = document.getElementById("extDialogOk");
    var cancelBtn = document.getElementById("extDialogCancel");
    document.getElementById("extDialogTitle").textContent = "'" + folderName + "' 확장자 관리";
    field.value = currentValue || "";
    overlay.style.display = "flex";
    setTimeout(function() { field.focus(); }, 30);

    function cleanup() {
        overlay.style.display = "none";
        okBtn.onclick = null;
        cancelBtn.onclick = null;
        field.onkeydown = null;
    }
    okBtn.onclick = function() { var v = field.value; cleanup(); callback(v); };
    cancelBtn.onclick = function() { cleanup(); callback(null); };
    field.onkeydown = function(e) {
        // Ctrl+Enter로 확정 (그냥 Enter는 줄바꿈 허용)
        if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
            e.preventDefault();
            var v = field.value; cleanup(); callback(v);
        } else if (e.key === "Escape") {
            e.preventDefault();
            cleanup(); callback(null);
        }
    };
}

function addRootFolder() {
    customPrompt("추가할 최상위 폴더 이름:", "새폴더", function(newName) {
        if (!newName) return;
        newName = newName.trim();
        if (!newName) return;
        var trees = getTrees();
        var t = trees[_curTreeIdx];
        t.nodes.push({ name: newName, children: [] });
        saveTrees(trees);
        renderTreeNodes();
        syncCtxMenu();
    });
}

// 기본값 복원
function resetCurrentTree() {
    var trees = getTrees();
    var cur = trees[_curTreeIdx];
    var defaults = defaultTrees();
    var def = null;
    for (var i = 0; i < defaults.length; i++) {
        if (defaults[i].id === cur.id) { def = defaults[i]; break; }
    }
    if (!def) {
        customAlert("이 트리는 사용자가 추가한 트리라 기본값이 없습니다.", function() {});
        return;
    }
    customConfirm("'" + cur.label + "'을(를) 기본값으로 되돌릴까요?", function(ok) {
        if (!ok) return;
        var trees2 = getTrees();
        trees2[_curTreeIdx].nodes = JSON.parse(JSON.stringify(def.nodes));
        saveTrees(trees2);
        renderTreeNodes();
        syncCtxMenu();
    });
}

// 새 트리 추가 (A방식: 타입 먼저 선택)
function addNewTree() {
    showTreeTypeDialog(function(type) {
        if (!type) return;
        customPrompt("새 트리 이름:", type === "ae" ? "새 프로젝트 트리" : "새 로컬 트리", function(label) {
            if (!label) return;
            label = label.trim();
            if (!label) return;
            var trees = getTrees();
            var newId = "custom_" + Date.now();
            trees.push({ id: newId, type: type, label: label, nodes: [] });
            saveTrees(trees);
            _curTreeIdx = trees.length - 1;
            renderTreeSelector();
            syncCtxMenu();
        });
    });
}

// 트리 삭제
function deleteCurrentTree() {
    var trees = getTrees();
    if (trees.length <= 1) {
        customAlert("트리가 하나뿐이라 삭제할 수 없습니다.", function() {});
        return;
    }
    var cur = trees[_curTreeIdx];
    customConfirm("'" + cur.label + "' 트리를 삭제할까요?", function(ok) {
        if (!ok) return;
        var trees2 = getTrees();
        trees2.splice(_curTreeIdx, 1);
        saveTrees(trees2);
        if (_curTreeIdx >= trees2.length) _curTreeIdx = trees2.length - 1;
        renderTreeSelector();
        syncCtxMenu();
    });
}

// 트리 타입 선택 다이얼로그
function showTreeTypeDialog(callback) {    var overlay = document.getElementById("treeTypeDialog");
    overlay.style.display = "flex";
    var aeBtn = document.getElementById("ttdAeBtn");
    var localBtn = document.getElementById("ttdLocalBtn");
    var cancelBtn = document.getElementById("ttdCancelBtn");
    function cleanup() {
        overlay.style.display = "none";
        aeBtn.onclick = null;
        localBtn.onclick = null;
        cancelBtn.onclick = null;
    }
    aeBtn.onclick = function() { cleanup(); callback("ae"); };
    localBtn.onclick = function() { cleanup(); callback("local"); };
    cancelBtn.onclick = function() { cleanup(); callback(null); };
}

// 우클릭 메뉴 동기화 (DOMContentLoaded에서 window.syncCtxMenu로 덮어쓰기)
function syncCtxMenu() {}

// 프로젝트(ae) 폴더트리 생성 (완료 시 onDone(true=성공/false=실패) 호출)
// 성공 여부와 무관하게 후속 작업을 이어갈 수 있도록 콜백을 받는다
function createAeTree(tree, onDone) {
    var nodesJson = JSON.stringify(tree.nodes || []);
    callES('brc_createAEFolderTreeFromNodes(' + q(nodesJson) + ')', function(r) {
        var ok = true;
        if (r && r.indexOf("error") !== -1) {
            ok = false;
            console.error("[BRC] 프로젝트 폴더트리:", r);
            customAlert("프로젝트 폴더트리 생성 실패: " + r, function() {});
        }
        if (typeof onDone === "function") onDone(ok);
    });
}

// 트리 컨텍스트 메뉴에서 실행 (전역)
function runTreeFromCtx(tree) {
    hideCtxMenu();
    if (tree.type === "ae") {
        createAeTree(tree, null);
    } else {
        createLocalTree(tree);
    }
}

// 로컬(디스크) 폴더트리 생성 — 최상위 폴더명 입력 → 디스크 폴더 생성 + 프로젝트 저장
function createLocalTree(tree) {
    var nodesJson = JSON.stringify(tree.nodes || []);
    var basePath = getLocalTreePath();
    function doCreate(path) {
        customPrompt("최상위 폴더 이름을 입력하세요.", todayYYMMDD(), function(topName) {
            if (!topName) return;
            topName = topName.trim();
            if (!topName) return;
            callES('brc_createLocalTreeFromNodes(' + q(path) + ',' + q(topName) + ',' + q(nodesJson) + ')', function(r) {
                if (!r) return;
                var clean = r.replace(/^"|"$/g, "");
                if (clean.indexOf("error") === 0) {
                    console.error("[BRC] 로컬 폴더트리:", clean);
                    customAlert("폴더 생성 실패: " + clean, function() {});
                } else if (clean.indexOf("done:") === 0) {
                    // "done:폴더경로|saved:파일경로" 형태
                    var rest = clean.substring(5);
                    var savedIdx = rest.indexOf("|saved:");
                    var createdPath = savedIdx >= 0 ? rest.substring(0, savedIdx) : rest;
                    saveLastCreatedTreePath(createdPath);
                    // 입력한 폴더명에서 광고주/캠페인/작업내용 등을 패널 필드에 자동 입력
                    fillFieldsFromName(topName);
                    // 폴더트리 생성 과정에서 작업파일(aep/prproj)이 저장됐으면 저장 기록에도 추가
                    if (savedIdx >= 0) {
                        var savedFile = rest.substring(savedIdx + 7); // "|saved:".length === 7
                        if (savedFile) addSaveHistory(savedFile);
                    }
                    // 분류된 소스 파일을 로컬 디스크 트리로 복사 (AE)
                    callES('brc_copyProjectFootageToDisk(' + q(createdPath) + ')', function(rr) {
                        if (rr && rr.indexOf("error") === 0) console.error("[BRC] footage 복사:", rr);
                        else if (rr) console.log("[BRC] footage 복사:", rr);
                    });
                }
            });
        });
    }
    if (!basePath) {
        customConfirm("로컬 폴더트리 생성 위치가 지정되지 않았습니다.\n확인을 누르면 폴더를 선택할 수 있습니다.", function(ok) {
            if (!ok) return;
            callES('brc_browseFolder()', function(p) {
                if (p && p !== "undefined" && p !== "") {
                    p = p.replace(/^"|"$/g, "");
                    saveLocalTreePath(p);
                    var el = document.getElementById("localTreePathInput");
                    if (el) el.value = p;
                    doCreate(p);
                }
            });
        });
        return;
    }
    doCreate(basePath);
}

function runFileImport() {
    hideCtxMenu();
    var importPath = getImportPath();
    if (!importPath) {
        customConfirm("파일 임포트 폴더가 지정되지 않았습니다.\n확인을 누르면 폴더를 선택할 수 있습니다.", function(ok) {
            if (!ok) return;
            callES('brc_browseFolder()', function(path) {
                if (path && path !== "undefined" && path !== "") {
                    path = path.replace(/^"|"$/g, "");
                    saveImportPath(path);
                    var el = document.getElementById("importPathInput");
                    if (el) el.value = path;
                    callES('brc_importFolder(' + q(path) + ')', function(r) {
                        if (r && r.indexOf("premiere not supported") !== -1) { customAlert("파일 임포트(구조 유지)는 After Effects에서만 지원됩니다.", function(){}); return; }
                        if (r && r.indexOf("error") !== -1) console.error("[BRC] 임포트:", r);
                    });
                }
            });
        });
        return;
    }
    callES('brc_importFolder(' + q(importPath) + ')', function(r) {
        if (r && r.indexOf("premiere not supported") !== -1) { customAlert("파일 임포트(구조 유지)는 After Effects에서만 지원됩니다.", function(){}); return; }
        if (r && r.indexOf("error") !== -1) console.error("[BRC] 임포트:", r);
    });
}

// 탐색기를 열어 폴더를 직접 선택해 임포트 (구조 유지)
function runFileImportBrowse() {
    hideCtxMenu();
    callES('brc_browseFolder()', function(path) {
        if (!path || path === "undefined" || path === "") return;
        path = path.replace(/^"|"$/g, "");
        callES('brc_importFolder(' + q(path) + ')', function(r) {
            if (r && r.indexOf("premiere not supported") !== -1) { customAlert("파일 임포트(구조 유지)는 After Effects에서만 지원됩니다.", function(){}); return; }
            if (r && r.indexOf("error") !== -1) console.error("[BRC] 임포트:", r);
        });
    });
}

// 폴더 임포트 + 자동분류 (탐색기로 폴더 선택 → 트리 생성 → 재귀 임포트 → 분류)
function runImportClassify(tree) {
    if (!tree || tree.type !== "ae") {
        customAlert("프로젝트 폴더트리를 선택해주세요.", function() {});
        return;
    }
    var nodesJson = JSON.stringify(tree.nodes || []);
    var localTree = getSelectedLocalTree();
    var localNodesJson = JSON.stringify(localTree && localTree.nodes ? localTree.nodes : []);
    var treePath = getLastCreatedTreePath() || "";
    callES('brc_browseFolder()', function(path) {
        if (!path || path === "undefined" || path === "") return;
        path = path.replace(/^"|"$/g, "");
        callES('brc_importFolderAndClassify(' + q(path) + ',' + q(nodesJson) + ',' + q(treePath) + ',' + q(localNodesJson) + ')', function(r) {
            if (r && r.indexOf("premiere not supported") !== -1) {
                customAlert("폴더 임포트+자동분류는 After Effects에서만 지원됩니다.", function(){});
                return;
            }
            if (r && r.indexOf("error") !== -1) {
                console.error("[BRC] 임포트+분류:", r);
                customAlert("임포트 실패: " + r, function() {});
            }
        });
    });
}

// ── 커스텀 다이얼로그 ────────────────────────────────────────
function customPrompt(title, defaultValue, callback) {
    var overlay = document.getElementById("inputDialog");
    var field = document.getElementById("inputDialogField");
    var okBtn = document.getElementById("inputDialogOk");
    var cancelBtn = document.getElementById("inputDialogCancel");
    document.getElementById("inputDialogTitle").textContent = title;
    field.value = defaultValue || "";
    overlay.style.display = "flex";
    setTimeout(function() { field.focus(); field.select(); }, 30);

    function cleanup() {
        overlay.style.display = "none";
        okBtn.onclick = null;
        cancelBtn.onclick = null;
        field.onkeydown = null;
    }
    function ok() { var v = field.value; cleanup(); callback(v); }
    function cancel() { cleanup(); callback(null); }
    okBtn.onclick = ok;
    cancelBtn.onclick = cancel;
    field.onkeydown = function(e) {
        if (isComposingKey(e)) return;
        if (e.key === "Enter") { e.preventDefault(); ok(); }
        else if (e.key === "Escape") { e.preventDefault(); cancel(); }
    };
}

function customConfirm(title, callback, okLabel, cancelLabel) {
    var overlay = document.getElementById("confirmDialog");
    var okBtn = document.getElementById("confirmDialogOk");
    var cancelBtn = document.getElementById("confirmDialogCancel");
    cancelBtn.style.display = "";  // 알림 모드에서 숨겼을 수 있으니 복원
    document.getElementById("confirmDialogTitle").textContent = title;
    // 버튼 레이블 설정 (지정 안 하면 기본 확인/취소)
    okBtn.textContent = okLabel || "확인";
    cancelBtn.textContent = cancelLabel || "취소";
    overlay.style.display = "flex";

    function cleanup() {
        overlay.style.display = "none";
        okBtn.onclick = null;
        cancelBtn.onclick = null;
        // 다음 사용을 위해 기본 레이블로 복원
        okBtn.textContent = "확인";
        cancelBtn.textContent = "취소";
    }
    okBtn.onclick = function() { cleanup(); callback(true); };
    cancelBtn.onclick = function() { cleanup(); callback(false); };
}

// 단일 확인 버튼 알림 (취소 없음) — 정보성 안내용
function customAlert(title, callback) {
    var overlay = document.getElementById("confirmDialog");
    var okBtn = document.getElementById("confirmDialogOk");
    var cancelBtn = document.getElementById("confirmDialogCancel");
    document.getElementById("confirmDialogTitle").textContent = title;
    okBtn.textContent = "확인";
    cancelBtn.style.display = "none";   // 취소 숨김 → 확인 1개
    overlay.style.display = "flex";
    function cleanup() {
        overlay.style.display = "none";
        okBtn.onclick = null;
        cancelBtn.style.display = "";    // 다음 confirm 위해 복원
        okBtn.textContent = "확인";
    }
    okBtn.onclick = function() { cleanup(); if (typeof callback === "function") callback(); };
}

// 저장 기록 선택 다이얼로그
// 클릭하면 닫히는 알림 (버튼 없음)
function showDismissDialog(message) {
    var overlay = document.getElementById("dismissDialog");
    document.getElementById("dismissDialogTitle").textContent = message;
    overlay.style.display = "flex";
    function cleanup() {
        overlay.style.display = "none";
        overlay.onmousedown = null;
    }
    // 오버레이/박스 어디를 눌러도 닫힘
    overlay.onmousedown = function() { cleanup(); };
}

function showSaveHistoryDialog(callback) {
    var overlay = document.getElementById("histDialog");
    var list = document.getElementById("histList");
    var box = overlay.querySelector(".hist-box");
    list.innerHTML = "";

    var hist = getSaveHistory();
    if (!hist.length) {
        var empty = document.createElement("div");
        empty.className = "hist-empty";
        empty.textContent = "아직 저장 기록이 없습니다.";
        list.appendChild(empty);
    } else {
        hist.forEach(function(fullPath) {
            var item = document.createElement("button");
            item.className = "hist-item";
            item.textContent = basenameFromPath(fullPath);
            bindTooltip(item, fullPath);
            item.addEventListener("click", function() {
                cleanup();
                callback(fullPath);
            });
            list.appendChild(item);
        });
    }

    overlay.style.display = "flex";

    function cleanup() {
        overlay.style.display = "none";
        overlay.onmousedown = null;
    }
    // 오버레이(창 밖) 또는 박스 내 빈 공간 클릭 시 닫기
    overlay.onmousedown = function(e) {
        // 리스트 항목(.hist-item)을 누른 게 아니면 닫기
        if (!e.target.closest(".hist-item")) {
            cleanup();
            callback(null);
        }
    };
}

// 해상도 드롭다운 열림 상태 추적
var _resDropOpen = false;

// ── 데이터 ──────────────────────────────────────────────────
var RES_LIST = ["None",
    "1920x1080 (16:9)", "1080x1080 (1:1)", "1080x1920 (9:16)",
    "1080x1350 (4:5)", "1200x628 (1.91:1)", "1200x1200 (1:1)",
    "1200x1500 (4:5)", "1440x1440 (1:1)", "1440x1800 (4:5)",
    "3840x2160 (16:9)", "2160x3840 (9:16)"];
var TYPE_LIST = ["None","xian","retuch1","vari","sf"];
var JOBKIND_LIST = ["None",
    "@MB: 모션배너","@BC: 배너결합","@SZ: 사이즈배리",
    "@ED: 편집","@AV: AI활용영상","@AB: AI활용배너",
    "@MV: 모션영상","@SH: 촬영","@CP: 용량배리"];

var STORAGE_KEY = "brc_worker";

// ── 유틸 ────────────────────────────────────────────────────
function $(id) { return document.getElementById(id); }

function getTodayYYMMDD() {
    var d = new Date();
    return ("0"+((d.getFullYear()%100))).slice(-2) +
           ("0"+(d.getMonth()+1)).slice(-2) +
           ("0"+d.getDate()).slice(-2);
}

function fillSelect(el, list) {
    el.innerHTML = "";
    list.forEach(function(v) {
        var o = document.createElement("option");
        o.value = o.textContent = v;
        el.appendChild(o);
    });
}

function jobKindCode(label) {
    var i = label.indexOf(":");
    return i !== -1 ? label.substring(0, i) : label;
}

function incrementText(text, isPage) {
    text = text.trim();
    if (!text) return text;
    if (isPage) {
        var n = parseInt(text.replace(/[^0-9]/g, ""), 10);
        return isNaN(n) ? text : String(n + 1);
    }
    var m = text.match(/^(.*?)_(\d+)$/);
    return m ? m[1] + "_" + (parseInt(m[2], 10) + 1) : text + "_1";
}

function sanitize(s) {
    return String(s||"").replace(/[\\\/:\*\?"<>\|]/g,"").replace(/\s+/g," ").trim();
}

// ── ExtendScript 호출 래퍼 ───────────────────────────────────
function callES(script, cb) {
    if (!cs) { console.error("[BRC] cs 없음:", script); return; }
    cs.evalScript(script, function(r) { if (cb) cb(r); });
}

// ── hostscript 로드 ──────────────────────────────────────────
function loadHostScript() {
    try {
        var extPath = cs.getSystemPath(SystemPath.EXTENSION);
        if (!extPath) { console.error("[BRC] Extension path 없음"); return; }
        // 슬래시 정규화
        var jsxPath = extPath.replace(/\\/g, "/") + "/host/hostscript.jsx";
        callES('$.evalFile("' + jsxPath + '")', function(r) {
            console.log("[BRC] hostscript 로드:", r);
        });
    } catch(e) {
        console.error("[BRC] hostscript 로드 실패:", e);
    }
}

// ── IME 한글 입력 처리 ──────────────────────────────────────
// CEP Chromium의 IME 미리보기 문제 우회
// compositionstart/end로 입력 완료 시점을 정확히 감지
// [삭제됨] fixIME() — 위약이었다.
// compositionstart/end 를 듣고 el.composing 플래그를 세팅했지만
//   (1) CEP 패널에서는 composition 이벤트가 아예 발화하지 않고 (실측 0건)
//   (2) el.composing 을 읽는 코드가 저장소 전체에 한 곳도 없었다.
// 게다가 DOMContentLoaded 시점의 input 만 잡아서 동적으로 만드는
// 트리 노드 입력창에는 걸리지도 않았다.
// 한글 입력은 koPrompt() (네이티브 ScriptUI 입력창) 로 해결한다. 파일 하단 참고.

// ── 초기화 ──────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", function() {
    loadHostScript();
    setupFlyoutMenu();
    setSettingsTabIndex(false); // 초기에 설정창 탭 비활성화

    // 뒤로가기 버튼
    document.getElementById("backBtn").addEventListener("click", closeSettings);

    // ── 툴팁 일괄 등록 ──
    (function registerTooltips() {
        function tip(sel, text) {
            var el = typeof sel === "string" ? document.querySelector(sel) : sel;
            if (el) bindTooltip(el, text);
        }
        // 메인 화면 ↻ 버튼들
        tip('.icon-btn[data-field="date"]', "오늘 날짜 적용");
        tip('.icon-btn[data-field="client"]', "광고주명 적용");
        tip('.icon-btn[data-field="resolution"]', "해상도 적용 · Shift+클릭/우클릭: 직접 입력");
        tip('.icon-btn[data-field="worker"]', "작업자 적용");
        tip('.icon-btn[data-field="jobKind"]', "작업종류 적용");
        tip('.icon-btn[data-field="workType"]', "작업구분 적용");
        // 캠페인/페이지/작업내용 ↻ (data-field로 직접 못 잡는 경우 대비)
        var campBtn = document.querySelector('.icon-btn[data-field="campaign"]');
        if (campBtn) bindTooltip(campBtn, "캠페인명 적용 · 다시 누르면 숫자 +1");
        var pageBtn = document.querySelector('.icon-btn[data-field="page"]');
        if (pageBtn) bindTooltip(pageBtn, "페이지 적용 · 다시 누르면 숫자 +1");
        var taskBtn = document.querySelector('.icon-btn[data-field="task"]');
        if (taskBtn) bindTooltip(taskBtn, "작업내용 적용 · 다시 누르면 숫자 +1");
        // 선택변경 ↻
        tip('#replaceBtn', "from → to 텍스트 치환");
        // 하단 버튼들
        tip('#loadBtn', "선택 컴프 이름 불러오기 · 우클릭: 최상단 컴프");
        tip('#clearBtn', "입력 초기화");
        tip('#applyBtn', "전체 조합 이름 적용 · 우클릭: 프로젝트 전체 컴프");
        tip('#folderBtn', "빈 로컬 폴더트리 생성 · 우클릭: 폴더트리 메뉴");
        tip('#saveBtn', "현재 프로젝트를 Ae/Pr 폴더에 다른 이름으로 저장 · 우클릭: 최근 저장 파일 열기");
        tip('#importBtn', "파일 임포트 · 우클릭: 폴더 직접 선택");
        tip('#renderBtn', "선택 컴프 렌더 / 미선택 시 전체 렌더 확인창 · 출력: 00_Master · 우클릭: Master 폴더 열기");
        // 설정 화면
        tip('#resAddBtn', "해상도 추가 · 우클릭: 기본값 복원");
        tip('#localTreeBrowseBtn', "폴더 찾기 · 우클릭: 경로 초기화");
        tip('#importBrowseBtn', "폴더 찾기 · 우클릭: 경로 초기화");
        tip('#exportSettingsBtn', "설정을 JSON 파일로 저장");
        tip('#importSettingsBtn', "JSON 파일에서 설정 불러오기");
        tip('#treeAddRootBtn', "최상위 폴더 추가");
        tip('#treeResetBtn', "기본 트리를 기본값으로 복원");
        tip('#treeAddTreeBtn', "새 트리 만들기 (타입 선택)");
        tip('#treeDelTreeBtn', "현재 트리 삭제");
    })();

    // 가이드 아코디언
    var guideHeads = document.querySelectorAll(".guide-head");
    for (var gi = 0; gi < guideHeads.length; gi++) {
        guideHeads[gi].addEventListener("click", function() {
            var item = this.parentElement;
            item.classList.toggle("open");
        });
    }

    // 툴팁 전역 on/off 토글
    var tooltipToggle = document.getElementById("tooltipToggle");
    if (tooltipToggle) {
        tooltipToggle.checked = tooltipsEnabled();
        tooltipToggle.addEventListener("change", function() {
            setTooltipsEnabled(this.checked);
            if (!this.checked) hideTooltip();
        });
    }

    // 자동 렌더 출력 토글
    var autoRenderToggle = document.getElementById("autoRenderToggle");
    if (autoRenderToggle) {
        autoRenderToggle.checked = autoRenderEnabled();
        autoRenderToggle.addEventListener("change", function() {
            setAutoRenderEnabled(this.checked);
        });
    }

    // 트리 셀렉터 ◀▶ + 드롭다운
    document.getElementById("treeSelect").addEventListener("change", function() {
        _curTreeIdx = parseInt(this.value);
        renderTreeSelector();
    });

    // 트리 액션 버튼
    document.getElementById("treeAddRootBtn").addEventListener("click", addRootFolder);
    document.getElementById("treeResetBtn").addEventListener("click", resetCurrentTree);
    document.getElementById("treeAddTreeBtn").addEventListener("click", addNewTree);
    document.getElementById("treeDelTreeBtn").addEventListener("click", deleteCurrentTree);

    // 해상도 프리셋 추가
    document.getElementById("resAddBtn").addEventListener("click", function() {
        var val = document.getElementById("resAddInput").value.trim().replace(/X/g, "x");
        if (!val) return;
        // 화면비 자동 계산
        var label = val;
        var m = val.match(/^(\d+)x(\d+)$/i);
        if (m) {
            var w = parseInt(m[1]), h = parseInt(m[2]);
            function gcd(a, b) { return b === 0 ? a : gcd(b, a % b); }
            var g = gcd(w, h);
            var rw = w / g, rh = h / g;
            var ratio;
            if (rw > 20 || rh > 20) {
                // 분수가 너무 크면 소수점으로
                ratio = (w / h).toFixed(2) + ":1";
            } else {
                ratio = rw + ":" + rh;
            }
            label = val + " (" + ratio + ")";
        }
        var presets = getResPresets();
        // 이미 같은 해상도 코드가 있으면 추가 안 함
        var exists = presets.some(function(p) {
            return p.replace(/\s*\(.*\)$/, "") === val;
        });
        if (!exists) {
            presets.push(label);
            saveResPresets(presets);
            renderResPresets();
            document.getElementById("resAddInput").value = "";
        }
    });
    document.getElementById("resAddInput").addEventListener("keydown", function(e) {
        if (isComposingKey(e)) return;
        if (e.key === "Enter") document.getElementById("resAddBtn").click();
    });
    // 해상도 추가 버튼 우클릭 → 기본값 복원
    document.getElementById("resAddBtn").addEventListener("contextmenu", function(e) {
        e.preventDefault();
        e.stopPropagation();
        customConfirm("해상도 프리셋을 기본값으로 되돌릴까요?", function(ok) {
            if (!ok) return;
            saveResPresets(RES_LIST.slice(1));
            renderResPresets();
            applyResPresets();
        });
    });

    // 임포트 폴더 찾기
    document.getElementById("importBrowseBtn").addEventListener("click", function() {
        callES('brc_browseFolder()', function(path) {
            if (path && path !== "undefined" && path !== "") {
                path = path.replace(/^"|"$/g, "");
                document.getElementById("importPathInput").value = path;
                saveImportPath(path);
            }
        });
    });
    // 경로 직접 편집 시 저장
    document.getElementById("importPathInput").addEventListener("blur", function() {
        saveImportPath(this.value.trim());
    });
    // 찾기 버튼 우클릭 → 경로 초기화
    document.getElementById("importBrowseBtn").addEventListener("contextmenu", function(e) {
        e.preventDefault();
        e.stopPropagation();
        document.getElementById("importPathInput").value = "";
        saveImportPath("");
    });

    // 로컬 폴더트리 경로 찾기
    document.getElementById("localTreeBrowseBtn").addEventListener("click", function() {
        callES('brc_browseFolder()', function(path) {
            if (path && path !== "undefined" && path !== "") {
                path = path.replace(/^"|"$/g, "");
                document.getElementById("localTreePathInput").value = path;
                saveLocalTreePath(path);
            }
        });
    });
    document.getElementById("localTreePathInput").addEventListener("blur", function() {
        saveLocalTreePath(this.value.trim());
    });
    document.getElementById("localTreeBrowseBtn").addEventListener("contextmenu", function(e) {
        e.preventDefault();
        e.stopPropagation();
        document.getElementById("localTreePathInput").value = "";
        saveLocalTreePath("");
    });

    // 컨텍스트 메뉴 항목
    // 컨텍스트 메뉴 동적 빌드 (트리 목록 + 파일 임포트)
    // runTreeFromCtx, runFileImport은 전역 함수로 정의됨 (window 스코프)

    // 컨텍스트 메뉴 재구성 (트리 변경 시 호출)
    window.syncCtxMenu = function() {
        var menu = document.getElementById("ctxMenu");
        menu.innerHTML = "";
        var trees = getTrees();
        var aeTrees = trees.filter(function(t) { return t.type === "ae"; });
        var localTrees = trees.filter(function(t) { return t.type === "local"; });

        function addDivider() {
            var d = document.createElement("div");
            d.className = "ctx-divider";
            menu.appendChild(d);
        }
        function addLabel(text) {
            var l = document.createElement("div");
            l.className = "ctx-group-label";
            l.textContent = text;
            menu.appendChild(l);
        }
        function makeBtn(html, cls, tip, fn) {
            var b = document.createElement("button");
            b.className = "ctx-mini-btn" + (cls ? " " + cls : "");
            b.innerHTML = html;
            if (tip) bindTooltip(b, tip);
            b.addEventListener("click", function(e) {
                e.stopPropagation();
                fn();
            });
            return b;
        }

        // ── 프로젝트 폴더트리 행 ──
        addLabel("프로젝트 폴더트리");
        var aeRow = document.createElement("div");
        aeRow.className = "ctx-tree-row";
        var aeSel = document.createElement("select");
        aeSel.className = "ctx-tree-select";
        aeTrees.forEach(function(t) {
            var opt = document.createElement("option");
            opt.value = t.id;
            opt.textContent = t.label;
            if (t.id === getSelectedAeTreeId()) opt.selected = true;
            aeSel.appendChild(opt);
        });
        // 저장된 선택이 없으면 첫 항목을 기본 선택으로 저장
        if (!getSelectedAeTreeId() && aeTrees.length) setSelectedAeTreeId(aeTrees[0].id);
        aeSel.addEventListener("click", function(e) { e.stopPropagation(); });
        aeSel.addEventListener("change", function(e) {
            e.stopPropagation();
            setSelectedAeTreeId(this.value);
        });
        // + : 빈 폴더트리 생성
        var aeAdd = makeBtn('<svg><use href="#ico-plus"/></svg>', "", "빈 폴더트리 생성", function() {
            hideCtxMenu();
            var t = getTreeByIdLocal(aeSel.value);
            if (t) runTreeFromCtx(t);
        });
        // ⬇ : 폴더 임포트 + 자동분류
        var aeImport = makeBtn('<svg><use href="#ico-download"/></svg>', "", "폴더 임포트 + 자동 분류 (디스크 트리로 이동, _Master/_Ae/_Pr 폴더 제외)", function() {
            hideCtxMenu();
            var t = getTreeByIdLocal(aeSel.value);
            if (t) runImportClassify(t);
        });
        aeRow.appendChild(aeSel);
        aeRow.appendChild(aeAdd);
        aeRow.appendChild(aeImport);
        menu.appendChild(aeRow);

        addDivider();

        // ── 로컬 폴더트리 행 ──
        addLabel("로컬 폴더트리");
        var localRow = document.createElement("div");
        localRow.className = "ctx-tree-row";
        var localSel = document.createElement("select");
        localSel.className = "ctx-tree-select";
        localTrees.forEach(function(t) {
            var opt = document.createElement("option");
            opt.value = t.id;
            opt.textContent = t.label;
            localSel.appendChild(opt);
        });
        localSel.addEventListener("click", function(e) { e.stopPropagation(); });
        // 저장된 선택 로컬 트리를 드롭다운 초기값으로
        (function() {
            var selId = getSelectedLocalTreeId();
            if (selId) {
                for (var i = 0; i < localSel.options.length; i++) {
                    if (localSel.options[i].value === selId) { localSel.selectedIndex = i; break; }
                }
            }
        })();
        // 로컬은 선택 시 즉시 실행
        localSel.addEventListener("change", function(e) {
            e.stopPropagation();
            setSelectedLocalTreeId(this.value);
            var t = getTreeByIdLocal(this.value);
            hideCtxMenu();
            if (t) runTreeFromCtx(t);
        });
        var localAdd = makeBtn('<svg><use href="#ico-plus"/></svg>', "", "빈 로컬 폴더트리 생성", function() {
            hideCtxMenu();
            setSelectedLocalTreeId(localSel.value);
            var t = getTreeByIdLocal(localSel.value);
            if (t) runTreeFromCtx(t);
        });
        var localOpen = makeBtn('<svg><use href="#ico-folder-open"/></svg>', "", "마지막으로 만든 폴더 열기", function() {
            hideCtxMenu();
            // 1순위: 마지막으로 생성한 폴더
            var lastPath = getLastCreatedTreePath();
            if (lastPath) {
                callES('brc_openLocalFolder(' + q(lastPath) + ')', function(r) {
                    if (r && r.indexOf("error") !== -1) {
                        // 마지막 폴더가 삭제/이동됐으면 베이스 경로로 폴백
                        openBaseLocalPath();
                    }
                });
                return;
            }
            openBaseLocalPath();
        });
        function openBaseLocalPath() {
            var p = getLocalTreePath();
            if (!p) {
                customConfirm("아직 만든 로컬 폴더트리가 없습니다.\n확인을 누르면 폴더를 선택할 수 있습니다.", function(ok) {
                    if (!ok) return;
                    callES('brc_browseFolder()', function(path) {
                        if (path && path !== "undefined" && path !== "") {
                            path = path.replace(/^"|"$/g, "");
                            saveLocalTreePath(path);
                            var el = document.getElementById("localTreePathInput");
                            if (el) el.value = path;
                            callES('brc_openLocalFolder(' + q(path) + ')');
                        }
                    });
                });
                return;
            }
            callES('brc_openLocalFolder(' + q(p) + ')', function(r) {
                if (r && r.indexOf("error") !== -1) {
                    customAlert("폴더를 열 수 없습니다: " + r, function() {});
                }
            });
        }
        localRow.appendChild(localSel);
        localRow.appendChild(localAdd);
        localRow.appendChild(localOpen);
        menu.appendChild(localRow);
    };

    function getTreeByIdLocal(id) {
        var trees = getTrees();
        for (var i = 0; i < trees.length; i++) if (trees[i].id === id) return trees[i];
        return null;
    }
    // 초기 빌드
    window.syncCtxMenu();

    // 설정 내보내기
    document.getElementById("exportSettingsBtn").addEventListener("click", function() {
        var settings = {
            resPresets: getResPresets(),
            importPath: getImportPath(),
            localTreePath: getLocalTreePath(),
            folderTrees: getTrees()
        };
        var jsonStr = JSON.stringify(settings, null, 2);
        callES('brc_exportSettings(' + q(jsonStr) + ')', function(r) {
            if (r === "cancel") return;
            if (r && r.indexOf("error") !== -1) console.error("[BRC] 내보내기 실패:", r);
        });
    });

    // 설정 가져오기
    document.getElementById("importSettingsBtn").addEventListener("click", function() {
        callES('brc_importSettings()', function(content) {
            if (!content || content === "" || content.indexOf("error") === 0) return;
            content = content.replace(/^"|"$/g, "");
            try {
                var settings = JSON.parse(content);
                if (settings.resPresets && Array.isArray(settings.resPresets)) {
                    saveResPresets(settings.resPresets);
                    renderResPresets();
                    applyResPresets();
                }
                if (settings.importPath) {
                    saveImportPath(settings.importPath);
                    document.getElementById("importPathInput").value = settings.importPath;
                }
                if (settings.localTreePath) {
                    saveLocalTreePath(settings.localTreePath);
                    document.getElementById("localTreePathInput").value = settings.localTreePath;
                }
                if (settings.folderTrees && Array.isArray(settings.folderTrees) && settings.folderTrees.length) {
                    saveTrees(settings.folderTrees);
                    _curTreeIdx = 0;
                    if (typeof renderTreeSelector === "function") renderTreeSelector();
                    if (typeof renderTreeNodes === "function") renderTreeNodes();
                    if (typeof window.syncCtxMenu === "function") window.syncCtxMenu();
                }
            } catch(e) {
                console.error("[BRC] 설정 파싱 실패:", e);
            }
        });
    });
    document.getElementById("folderBtn").addEventListener("contextmenu", function(e) {
        e.preventDefault();
        e.stopPropagation();
        showCtxMenu(e.clientX, e.clientY);
    });  // IME 한글 입력 처리

    fillSelect($("resolution"), RES_LIST);
    fillSelect($("jobKind"),    JOBKIND_LIST);
    fillSelect($("workType"),   TYPE_LIST);

    // 저장된 프리셋으로 해상도 드롭다운 덮어쓰기
    applyResPresets();

    $("date").value   = getTodayYYMMDD();
    $("worker").value = localStorage.getItem(STORAGE_KEY) || "";

    // 작업자 대문자 자동변환 (포커스 잃을 때)
    $("worker").addEventListener("blur", function() {
        this.value = this.value.trim().toUpperCase();
        localStorage.setItem(STORAGE_KEY, this.value);
    });

    // 페이지 숫자만 허용
    $("page").addEventListener("blur", function() {
        this.value = this.value.replace(/[^0-9]/g, "");
    });

    // 해상도/작업종류/작업구분: change 후 Enter → 적용
    function bindSelectEnter(id, field, nextId) {
        var changed = false;
        $(id).addEventListener("change", function() { changed = true; });
        $(id).addEventListener("keydown", function(e) {
            if (isComposingKey(e)) return;
            if (e.key === "Enter" || e.keyCode === 13) {
                if (changed) {
                    e.preventDefault();
                    e.stopPropagation();
                    changed = false;
                    applyField(field, false);
                    if (nextId) setTimeout(function() { $(nextId).focus(); }, 50);
                }
            } else if (e.key === "Escape" || e.keyCode === 27) {
                changed = false;
            }
        });
        $(id).addEventListener("blur", function() { changed = false; });
    }
    bindSelectEnter("resolution", "resolution", "worker");
    bindSelectEnter("jobKind",    "jobKind",    "workType");
    bindSelectEnter("workType",   "workType",   "replaceFrom");

    // 하단 버튼 Enter 동작 (preventDefault로 타임라인 재생 차단)
    $("loadBtn").addEventListener("keydown", function(e) {
        if (isComposingKey(e)) return;
        if (e.key === "Enter" || e.keyCode === 13) {
            e.preventDefault();
            e.stopPropagation();
            loadFromComp();
        }
    });
    $("clearBtn").addEventListener("keydown", function(e) {
        if (isComposingKey(e)) return;
        if (e.key === "Enter" || e.keyCode === 13) {
            e.preventDefault();
            e.stopPropagation();
            $("clearBtn").click();
        }
    });
    $("applyBtn").addEventListener("keydown", function(e) {
        if (isComposingKey(e)) return;
        if (e.key === "Enter" || e.keyCode === 13) {
            e.preventDefault();
            e.stopPropagation();
            $("applyBtn").click();
        }
    });
    $("folderBtn").addEventListener("keydown", function(e) {
        if (isComposingKey(e)) return;
        if (e.key === "Enter" || e.keyCode === 13) {
            e.preventDefault();
            e.stopPropagation();
            $("folderBtn").click();
        }
    });

    // Enter키로 즉시 적용
    var enterFields = [
        { id: "date",     field: "date",     increment: false },
        { id: "client",   field: "client",   increment: false },
        { id: "campaign", field: "campaign", increment: true  },
        { id: "page",     field: "page",     increment: true  },
        { id: "task",     field: "task",     increment: true  },
        { id: "worker",   field: "worker",   increment: false },
    ];
    enterFields.forEach(function(item) {
        $(item.id).addEventListener("keydown", function(e) {
            if (isComposingKey(e)) return;
            if (e.key === "Enter" || e.keyCode === 13) {
                e.preventDefault();
                e.stopPropagation();
                applyField(item.field, item.increment);
            }
        });
    });

    // 선택변경 Enter키
    $("replaceFrom").addEventListener("keydown", function(e) {
        if (isComposingKey(e)) return;
        if (e.key === "Enter" || e.keyCode === 13) {
            e.preventDefault();
            e.stopPropagation();
            $("replaceTo").focus();
        }
    });
    $("replaceTo").addEventListener("keydown", function(e) {
        if (isComposingKey(e)) return;
        if (e.key === "Enter" || e.keyCode === 13) {
            e.preventDefault();
            e.stopPropagation();
            var from = $("replaceFrom").value.trim();
            var to   = $("replaceTo").value.trim();
            if (!from) return;
            callES('brc_replaceText(' + q(from) + ',' + q(to) + ')');
        }
    });

    bindEvents();
});

// ── 이벤트 바인딩 ────────────────────────────────────────────
function bindEvents() {

    // 해상도 ↻ 버튼 - Shift+클릭: 커스텀 직접 입력 모드
    var resBtn = document.querySelector('.icon-btn[data-field="resolution"]');
    var resSel = $("resolution");
    var resCustom = $("resCustom");

    function toggleResCustom() {
        if (resSel.style.display === "none") {
            resSel.style.display = "";
            resCustom.style.display = "none";
        } else {
            resSel.style.display = "none";
            resCustom.style.display = "";
            resCustom.value = "";
            resCustom.focus();
        }
    }

    resBtn.addEventListener("click", function(e) {
        if (_shiftHeld) {
            toggleResCustom();
        } else {
            applyField("resolution", false);
        }
    });
    resBtn.addEventListener("contextmenu", function(e) {
        e.preventDefault();
        e.stopPropagation();
        toggleResCustom();
    });

    // 커스텀 입력 - Enter: 적용 후 드롭다운으로 복귀
    resCustom.addEventListener("keydown", function(e) {
        if (isComposingKey(e)) return;
        if (e.key === "Enter" || e.keyCode === 13) {
            var v = sanitize(this.value.trim()).replace(/X/g, "x");
            if (v) {
                callES('brc_applyField("resolution",' + q(v) + ')');
            }
            resSel.style.display = "";
            resCustom.style.display = "none";
        } else if (e.key === "Escape" || e.keyCode === 27) {
            // ESC: 취소하고 복귀
            resSel.style.display = "";
            resCustom.style.display = "none";
        }
    });

    // 포커스 잃으면 복귀
    resCustom.addEventListener("blur", function() {
        setTimeout(function() {
            resSel.style.display = "";
            resCustom.style.display = "none";
        }, 150);
    });
    document.querySelectorAll(".icon-btn[data-field]").forEach(function(btn) {
        if (btn.getAttribute("data-field") === "resolution") return;
        btn.addEventListener("click", function() {
            var field = this.getAttribute("data-field");
            var isIncrement = this.classList.contains("increment");
            applyField(field, isIncrement);
        });
    });

    // 선택변경
    $("replaceBtn").addEventListener("click", function() {
        var from = $("replaceFrom").value.trim();
        var to   = $("replaceTo").value.trim();
        if (!from) return;
        callES('brc_replaceText(' + q(from) + ',' + q(to) + ')');
    });

    // 불러오기
    $("loadBtn").addEventListener("click", function() { loadFromComp(false); });
    // 우클릭: 프로젝트 최상단 컴프에서 불러오기
    $("loadBtn").addEventListener("contextmenu", function(e) {
        e.preventDefault();
        e.stopPropagation();
        loadFromComp(true);
    });

    // 초기화
    $("clearBtn").addEventListener("click", function() {
        ["client","campaign","page","task","replaceFrom","replaceTo"].forEach(function(id) { $(id).value = ""; });
        $("resolution").selectedIndex = 0;
        $("jobKind").selectedIndex    = 0;
        $("workType").selectedIndex   = 0;
    });

    // 폴더트리 생성
    $("folderBtn").addEventListener("click", function(e) {
        // 좌클릭: 프로젝트(ae) 폴더트리 생성 → 완료 후 로컬 폴더트리(디스크 폴더) 생성
        var aeTree = getSelectedAeTree();
        var localTree = getSelectedLocalTree();
        if (!aeTree && !localTree) {
            customAlert("폴더트리가 없습니다. 설정에서 먼저 만들어주세요.", function() {});
            return;
        }
        // 1) 프로젝트(ae) 폴더트리 먼저 (있을 때만) → 2) 그 다음 로컬 폴더트리
        if (aeTree) {
            createAeTree(aeTree, function() {
                // ae 생성 성공/실패와 무관하게 로컬 트리로 진행
                if (localTree) createLocalTree(localTree);
            });
        } else {
            // ae 트리가 없으면 로컬만
            createLocalTree(localTree);
        }
    });

    // 메인 적용
    $("applyBtn").addEventListener("click", function() {
        var name = buildName();
        if (!name) return;
        callES('brc_renameAll(' + q(name) + ')');
    });
    // 우클릭: 프로젝트 전체 컴프 이름 변경
    $("applyBtn").addEventListener("contextmenu", function(e) {
        e.preventDefault();
        e.stopPropagation();
        var name = buildName();
        if (!name) return;
        // 선택된 컴프가 있으면 선택된 것만 변경 (팝업 없음)
        callES('brc_renameSelectedComps(' + q(name) + ')', function(rs) {
            var cleanS = (rs || "").replace(/^"|"$/g, "");
            if (cleanS.indexOf("done:") === 0) {
                // 선택 컴프 변경 완료 — 팝업 없이 조용히
                return;
            }
            if (cleanS.indexOf("error") === 0) {
                console.error("[BRC] 선택 이름 변경 실패:", cleanS);
                return;
            }
            // "none" → 선택된 컴프 없음 → 전체 변경 (확인 팝업)
            customConfirm("\uD504\uB85C\uC81D\uD2B8\uC758 \uBAA8\uB4E0 \uCEF4\uD3EC\uC758 \uC774\uB984\uC744 \uBCC0\uACBD\uD560\uAE4C\uC694?", function(ok) {
                if (!ok) return;
                callES('brc_renameAllInProject(' + q(name) + ')', function(r) {
                    if (r && r.indexOf("error") !== -1) {
                        console.error("[BRC] 전체 이름 변경 실패:", r);
                    }
                });
            });
        });
    });

    // 저장 버튼: 현재 프로젝트를 지정 트리의 Ae/Pr 폴더에 다른 이름으로 저장
    $("saveBtn").addEventListener("click", function() {
        // 트리 경로는 폴백용 (hostscript가 현재 프로젝트 파일 기준을 우선 사용)
        var treePath = getLastCreatedTreePath() || "";
        // 현재 프로젝트 기본 이름 가져오기
        callES('brc_getProjectBaseName()', function(baseName) {
            baseName = (baseName || "").replace(/^"|"$/g, "");
            customPrompt("저장할 파일 이름:", baseName || todayYYMMDD(), function(saveName) {
                if (!saveName) return;
                saveName = saveName.trim();
                if (!saveName) return;
                callES('brc_saveProjectToTree(' + q(treePath) + ',' + q(saveName) + ')', function(r) {
                    if (!r) return;
                    var clean = r.replace(/^"|"$/g, "");
                    if (clean.indexOf("error") === 0) {
                        console.error("[BRC] 저장 실패:", clean);
                        if (clean.indexOf("no tree path") !== -1) {
                            customAlert("저장 위치를 찾을 수 없습니다.\n현재 프로젝트가 폴더트리 안에 저장돼 있지 않다면,\n먼저 로컬 폴더트리를 만들거나 폴더트리 안에 저장해주세요.", function() {});
                        } else {
                            customAlert("저장 실패: " + clean, function() {});
                        }
                    } else if (clean.indexOf("done:") === 0) {
                        var savedFull = clean.substring(5);
                        addSaveHistory(savedFull);
                    }
                });
            });
        });
    });

    // 저장 버튼 우클릭: 최근 저장 기록에서 선택해 파일 열기
    $("saveBtn").addEventListener("contextmenu", function(e) {
        e.preventDefault();
        e.stopPropagation();
        function openHistory() {
            showSaveHistoryDialog(function(fullPath) {
                if (!fullPath) return;
                callES('brc_openProjectFile(' + q(fullPath) + ')', function(r) {
                    if (!r) return;
                    var clean = r.replace(/^"|"$/g, "");
                    if (clean.indexOf("error") === 0) {
                        console.error("[BRC] 파일 열기 실패:", clean);
                        // 비우기: 이 항목을 기록에서 제거하고 리스트 다시 표시
                        // 닫기: 창만 닫기
                        customConfirm(
                            "파일을 열 수 없습니다.\n파일이 이동되거나 삭제되었을 수 있습니다.",
                            function(doClear) {
                                if (doClear) {
                                    removeSaveHistory(fullPath);
                                    openHistory(); // 갱신된 리스트 다시 표시
                                }
                            },
                            "비우기", "닫기"
                        );
                    }
                });
            });
        }
        openHistory();
    });

    // 파일 임포트 버튼 (구조 유지 임포트 — 폴더 우클릭 메뉴에서 분리)
    $("importBtn").addEventListener("click", function() {
        runFileImport();
    });
    // 우클릭: 탐색기를 열어 폴더를 직접 선택해 임포트
    $("importBtn").addEventListener("contextmenu", function(e) {
        e.preventDefault();
        e.stopPropagation();
        runFileImportBrowse();
    });

    // 렌더 버튼: 선택 컴프(없으면 전체) 렌더 큐 추가 / 자동출력 ON이면 즉시 렌더+이동
    $("renderBtn").addEventListener("click", function() {
        // 트리 경로는 폴백용 (hostscript가 현재 프로젝트 파일 기준 00_Master를 우선 사용)
        var treePath = getLastCreatedTreePath() || "";
        var auto = autoRenderEnabled() ? "1" : "0";
        function doRender() {
        callES('brc_renderComps(' + q(treePath) + ',' + q(auto) + ')', function(r) {
            if (!r) return;
            var clean = r.replace(/^"|"$/g, "");
            if (clean.indexOf("error") === 0) {
                console.error("[BRC] 렌더:", clean);
                var msg;
                if (clean.indexOf("premiere not supported") !== -1) msg = "렌더 기능은 After Effects에서만 지원됩니다.";
                else if (clean.indexOf("no comps") !== -1) msg = "렌더할 컴프가 없습니다.";
                else if (clean.indexOf("no master") !== -1) msg = "00_Master 폴더를 찾거나 만들 수 없습니다.\n현재 프로젝트가 저장돼 있는지 확인해주세요.";
                else if (clean.indexOf("temp path not ascii") !== -1) msg = "임시 렌더 폴더 경로에 한글이 포함되어 렌더할 수 없습니다.\n(After Effects는 한글 출력 경로를 지원하지 않습니다)\n자동 출력을 끄고 렌더 큐에서 직접 출력 위치를 지정해주세요.";
                else if (clean.indexOf("no temp folder") !== -1) msg = "임시 렌더 폴더를 만들 수 없습니다.\n자동 출력을 끄고 렌더 큐에서 직접 출력 위치를 지정해주세요.";
                else if (clean.indexOf("render failed") !== -1) msg = "렌더 중 오류가 발생했습니다.\n렌더 큐 설정을 확인해주세요.";
                else msg = "렌더 실패: " + clean;
                customAlert(msg, function() {});
            } else if (clean.indexOf("queued:") === 0) {
                // 자동출력 OFF: 팝업 없이 조용히 큐에만 추가
            } else if (clean.indexOf("rendered:") === 0) {
                // 렌더 완료 알림 표시 안 함
            }
        });
        }
        // 렌더 전 대상 확인: 선택된 컴프가 있으면 즉시 렌더, 없으면(=전체) 개수 확인창
        callES('brc_getRenderPlan()', function(pr) {
            var plan = null;
            try { plan = JSON.parse((pr || "").replace(/^"|"$/g, "")); } catch(e) { plan = null; }
            if (!plan) { doRender(); return; }
            // 프리미어는 렌더 미지원. 호스트가 pr 플래그를 실어 보내므로 여기서 걸러야 한다.
            // 안 그러면 sel=0/total=0 이라 아래 else 로 떨어져 "렌더할 컴프가 없습니다"라는
            // 거짓 안내가 뜨고, brc_renderComps 의 미지원 메시지에는 영영 도달하지 못한다.
            if (plan.pr) { customAlert("렌더 기능은 After Effects에서만 지원됩니다.", function() {}); return; }
            if (plan.sel > 0) {
                doRender();
            } else if (plan.total > 0) {
                customConfirm("선택된 컴프가 없습니다.\n프로젝트의 모든 컴프 " + plan.total + "개를 렌더합니다.\n계속할까요?", function(ok) { if (ok) doRender(); }, "전체 렌더", "취소");
            } else {
                customAlert("렌더할 컴프가 없습니다.", function() {});
            }
        });
    });
    // 우클릭: _master 폴더를 탐색기로 열기
    $("renderBtn").addEventListener("contextmenu", function(e) {
        e.preventDefault();
        e.stopPropagation();
        var treePath = getLastCreatedTreePath() || "";
        callES('brc_openMasterFolder(' + q(treePath) + ')', function(r) {
            if (r && r.indexOf("error") !== -1) {
                customAlert("00_Master 폴더를 찾을 수 없습니다.\n현재 프로젝트가 폴더트리 안에 저장돼 있는지 확인해주세요.", function() {});
            }
        });
    });
}

// ── 개별 필드 적용 ───────────────────────────────────────────
function applyField(field, isIncrement) {
    var value;

    if (field === "resolution") {
        // "1920X1080 (16:9)" → "1920X1080"
        value = $("resolution").value.replace(/\s*\(.*\)$/, "");
        if (value === "None") return;
    } else if (field === "jobKind") {
        value = jobKindCode($("jobKind").value);
        if (value === "None") return;
    } else if (field === "workType") {
        value = $("workType").value;
        if (value === "None") return;
    } else if (field === "worker") {
        value = $("worker").value.trim().toUpperCase();
        if (!value) return;
    } else if (field === "page") {
        var raw = $("page").value.replace(/[^0-9]/g, "");
        if (!raw) return;
        if (isIncrement) {
            var lastPage = $("page").getAttribute("data-last-applied");
            if (lastPage === raw) {
                var next = incrementText(raw, true);
                callES('brc_applyField("page",' + q(next) + ')');
                $("page").value = next;
                $("page").setAttribute("data-last-applied", next);
            } else {
                callES('brc_applyField("page",' + q(raw) + ')');
                $("page").setAttribute("data-last-applied", raw);
            }
        } else {
            callES('brc_applyField("page",' + q(raw) + ')');
        }
        return;
    } else if (field === "campaign") {
        var v = sanitize($(field).value);
        if (!v) return;
        if (isIncrement) {
            var lastCamp = $(field).getAttribute("data-last-applied");
            if (lastCamp === v) {
                var nextC = incrementText(v, false);
                callES('brc_applyField("campaign",' + q(nextC) + ')');
                $(field).value = nextC;
                $(field).setAttribute("data-last-applied", nextC);
            } else {
                callES('brc_applyField("campaign",' + q(v) + ')');
                $(field).setAttribute("data-last-applied", v);
            }
        } else {
            callES('brc_applyField("campaign",' + q(v) + ')');
        }
        return;
    } else if (field === "task") {
        var v = sanitize($("task").value);
        if (!v) return;
        if (isIncrement) {
            var lastTask = $("task").getAttribute("data-last-applied");
            if (lastTask === v) {
                // 같은 값 = 두 번째 이후 클릭 → 증가
                var nextV = incrementText(v, false);
                callES('brc_applyField("task",' + q(nextV) + ',' + q(v) + ')');
                $("task").value = nextV;
                $("task").setAttribute("data-last-applied", nextV);
            } else {
                // 다른 값 = 첫 클릭 → 컴프에서 실제 현재 task를 파싱해 oldVal로 사용
                var fv = v;
                callES('brc_getFirstSelectedName()', function(name) {
                    name = (name || "").replace(/^"|"$/g, "");
                    callES('brc_parseCompName(' + q(name) + ')', function(json) {
                        var oldTask = "";
                        try {
                            json = json.replace(/^"|"$/g, "");
                            oldTask = JSON.parse(json).task || "";
                        } catch(e) {}
                        callES('brc_applyField("task",' + q(fv) + ',' + q(oldTask) + ')');
                    });
                });
                $("task").setAttribute("data-last-applied", v);
            }
        } else {
            callES('brc_applyField("task",' + q(v) + ',' + q(v) + ')');
        }
        return;
    } else {
        value = sanitize($(field).value);
        if (!value) return;
    }

    callES('brc_applyField(' + q(field) + ',' + q(value) + ')');
}

// ── 이름 문자열 → 패널 필드 자동 입력 (값이 있는 필드만 채움) ──
function fillFieldsFromName(name) {
    if (!name) return;
    callES('brc_parseCompName(' + q(name) + ')', function(json) {
        try {
            json = json.replace(/^"|"$/g, "");
            var r = JSON.parse(json);
            if (r.client)     $("client").value   = r.client;
            if (r.campaign)   $("campaign").value = r.campaign;
            if (r.page)       $("page").value     = r.page;
            if (r.task)       $("task").value     = r.task;
            if (r.resolution) setSelect("resolution", r.resolution);
            if (r.jobKind)    setSelect("jobKind",    r.jobKind);
            if (r.workType)   setSelect("workType",   r.workType);
        } catch(e) {
            console.error("[BRC] fillFieldsFromName 파싱 실패:", e, json);
        }
    });
}

// ── 불러오기 ─────────────────────────────────────────────────
function loadFromComp(useTopComp) {
    var apiCall = useTopComp ? 'brc_getTopCompName()' : 'brc_getFirstSelectedName()';
    callES(apiCall, function(name) {
        if (!name || name === "undefined") return;
        name = name.replace(/^"|"$/g, "");
        if (!name) return;

        callES('brc_parseCompName(' + q(name) + ')', function(json) {
            try {
                json = json.replace(/^"|"$/g, "");
                var r = JSON.parse(json);
                $("client").value   = r.client   || "";
                $("campaign").value = r.campaign  || "";
                $("page").value     = r.page      || "";
                $("task").value     = r.task      || "";
                setSelect("resolution", r.resolution);
                setSelect("jobKind",    r.jobKind);
                setSelect("workType",   r.workType);
            } catch(e) {
                console.error("[BRC] parseCompName 파싱 실패:", e, json);
            }
        });
    });
}

function setSelect(id, value) {
    if (!value) { $(id).selectedIndex = 0; return; }
    var el = $(id);
    for (var i = 0; i < el.options.length; i++) {
        var text = el.options[i].text;
        // 해상도는 "1920X1080 (16:9)" 형태이므로 화면비 제거 후 비교
        var textCode = text.replace(/\s*\(.*\)$/, "");
        if (textCode === value || text === value || jobKindCode(text) === value) {
            el.selectedIndex = i; return;
        }
    }
    el.selectedIndex = 0;
}

// ── 이름 조합 ────────────────────────────────────────────────
function buildName() {
    var parts = [];
    var date     = sanitize($("date").value);
    var client   = sanitize($("client").value);
    var campaign = sanitize($("campaign").value);
    var page     = $("page").value.replace(/[^0-9]/g, "");
    var task     = sanitize($("task").value);
    var res      = $("resolution").value.replace(/\s*\(.*\)$/, "");
    var worker   = $("worker").value.trim().toUpperCase();
    var jk       = jobKindCode($("jobKind").value);
    var wt       = $("workType").value;

    if (date)          parts.push(date);
    if (client)        parts.push(client);
    if (campaign)      parts.push(campaign);
    if (page)          parts.push(page + "p");
    if (task)          parts.push(task);
    if (res !== "None") parts.push(res);
    if (worker)        parts.push(worker);
    if (jk !== "None") parts.push(jk);
    if (wt !== "None") parts.push(wt);

    return parts.join("_");
}

// ── 헬퍼: 한글 조합 확정용 Enter 인가 ──────────────────────────
// 조합 중 누른 Enter 는 "글자를 확정하라"는 뜻이지 "실행하라"가 아니다.
// 이걸 안 거르면 "롯데렌터카" 마지막 글자를 확정하려는 Enter 가 동시에
// 이름변경을 실행시켜 미완성 값으로 컴프 이름이 바뀐다.
// 지금 이 환경에서는 조합 이벤트 자체가 안 와서 항상 false 지만,
// Adobe 가 CEP-3029 를 고치는 순간 바로 필요해진다. keyCode 229 는 이중 안전망.
function isComposingKey(e) { return !!(e.isComposing || e.keyCode === 229); }

// ── 헬퍼: JS 문자열 → ExtendScript 안전 문자열 ──────────────
// 백슬래시를 가장 먼저 처리한 뒤 따옴표·제어문자(개행/캐리지리턴/탭)를 이스케이프.
// Windows에서 복사된 경로/텍스트의 \r\n 이 ExtendScript 문자열을 깨뜨리는 것을 방지.
function q(s) {
    return '"' + String(s||"")
        .replace(/\\/g,"\\\\")
        .replace(/"/g,'\\"')
        .replace(/\r/g,"\\r")
        .replace(/\n/g,"\\n")
        .replace(/\t/g,"\\t") + '"';
}

// ============================================================
// 네이티브 한글 입력 (CEP IME 우회) - 현재 배선하지 않음
// ------------------------------------------------------------
// [상태] 동작은 검증됐지만 UI 일관성 때문에 켜지 않았다.
//   ScriptUI 다이얼로그는 AE 의 Adobe Clean 12pt 고정으로 그려지고,
//   폰트 패밀리도 크기도 코드로 바꿀 수 없다(7가지 방식 전부 무시됨,
//   newFont 객체에는 size 가 반영되는데 렌더 단계에서 버려진다).
//   Windows 150% 배율에서 패널은 1.5배로 그려지는데 ScriptUI 는 1배라,
//   패널에서 창으로 넘어가는 순간 글자가 확 작아진다.
//   "한글은 제대로 쳐지지만 룩이 깨진다"는 맞바꿈이라 보류했다.
//
// [켜는 법] 아래 두 줄을 DOMContentLoaded 에서 호출하면 된다.
//   1) KO_FIELDS/KO_FIELDS_EXTRA 각 입력창에 F2 keydown 핸들러 -> koPrompt
//   2) customPrompt 를 koPrompt 로 감싸기 (호출부 5곳이 전부 한글인데 무수정)
//   호스트 쪽 brc_promptKo 는 hostscript.jsx 에 이미 들어 있다.
//   실기 검증 완료: 다이얼로그에서 친 한글이 패널까지 온전히 돌아온다.
// ------------------------------------------------------------
// CEP 패널은 한글 인라인 조합이 깨진다. 실측 결과 composition 이벤트가
// 단 한 건도 오지 않고(입력창·textarea·contenteditable 전부 동일),
// 조합은 화면 좌상단 OS 기본 창에서 일어난 뒤 확정 글자만 도착한다.
// Adobe 가 CEP-3029 로 추적 중이며 CSS/DOM 으로는 손댈 수 없다.
// ScriptUI 는 호스트 앱 네이티브 위젯이라 조합이 정상이므로 거기서 받아온다.
// ============================================================

// fields: [{ id:"client", label:"광고주명", value:"(생략 시 현재 입력값)" }, ...]
// cb(map)  — map[id] = 입력값. 취소하면 cb(null).
// onFail() — 호스트 호출 자체가 실패했을 때. 없으면 cb(null).
function koPrompt(title, fields, cb, onFail) {
    var spec = { title: title, fields: [] }, i, el;
    for (i = 0; i < fields.length; i++) {
        el = document.getElementById(fields[i].id);
        spec.fields.push({
            id: fields[i].id,
            label: fields[i].label,
            value: fields[i].value !== undefined ? fields[i].value : (el ? el.value : "")
        });
    }
    callES('brc_promptKo(' + q(JSON.stringify(spec)) + ')', function(r) {
        var clean = String(r || "").replace(/^"|"$/g, "");
        // 빈 문자열 = 호스트 오류(미로드 포함). 취소('{"ok":0}')와 구분해야
        // hostscript 가 안 떠 있을 때 아무 반응 없이 끝나는 상황을 막는다.
        if (!clean) { if (onFail) onFail(); else if (cb) cb(null); return; }
        var res;
        try { res = JSON.parse(clean); }
        catch (e) { if (onFail) onFail(); else if (cb) cb(null); return; }
        if (!res.ok) { if (cb) cb(null); return; }
        var map = {}, j;
        for (j = 0; j < res.values.length; j++) map[res.values[j].id] = res.values[j].value;
        if (cb) cb(map);
    });
}

// 한글이 실제로 들어가는 칸만 (날짜·페이지·해상도 등 영숫자 칸은 제외)
var KO_FIELDS = [
    { id: "client",   label: "광고주명" },
    { id: "campaign", label: "캠페인명" },
    { id: "task",     label: "작업내용" }
];
var KO_FIELDS_EXTRA = [
    { id: "replaceFrom", label: "찾을 말" },
    { id: "replaceTo",   label: "바꿀 말" }
];

function koFillFields(map) {
    if (!map) return;
    for (var k in map) {
        if (!map.hasOwnProperty(k)) continue;
        var el = document.getElementById(k);
        if (!el) continue;
        el.value = map[k];
        el.dispatchEvent(new Event("input", { bubbles: true }));
    }
}

// 세 칸을 한 창에서 한 번에. 실사용 빈도가 가장 높은 경로다.
function openKoBatch() {
    koPrompt("한글 입력", KO_FIELDS, koFillFields, function() {
        customAlert("한글 입력창을 열지 못했습니다.\n스크립트 엔진이 로드되지 않았을 수 있습니다.", function() {});
    });
}
window.openKoBatch = openKoBatch;
