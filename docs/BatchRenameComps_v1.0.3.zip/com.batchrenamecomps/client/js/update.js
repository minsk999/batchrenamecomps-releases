// ============================================================
// BatchRenameComps - update.js
// 업데이트 확인 + 원클릭 설치
//   · 하루 1회 조용히 확인 (실패는 전부 무시)
//   · 설치: 내려받기 → 백업(.bak) → 압축 해제 → 파일 교체
//   · 실패 시 백업에서 자동 롤백
// ============================================================
(function () {
    "use strict";

    var VERSION_URL = "https://raw.githubusercontent.com/minsk999/batchrenamecomps-releases/main/docs/version.json";
    var SITE_URL    = "https://minsk999.github.io/batchrenamecomps-releases/";
    var K_LAST = "brc_upd_last_check";
    var K_SKIP = "brc_upd_skip";
    // 설치 패키지는 이 주소 아래에서만 받는다.
    var ZIP_ORIGIN = "https://raw.githubusercontent.com/minsk999/batchrenamecomps-releases/";

    // Node 는 이 패널에 없다(실측). readText 폴백용으로만 남겨둔다 — 다른 CEP 버전 대비.
    var fs = null;
    try { fs = require("fs"); } catch (e) {}

    var band = null, inner = null, hint = null;
    var info = null;      // version.json
    var busy = false;
    var curView = null;   // paint() 가 방금 붙인 노드. 아래 q() 참고

    function $(id) { return document.getElementById(id); }
    function warn(m, e) { try { console.warn("[BRC-UPD] " + m, e || ""); } catch (x) {} }
    function esc(s) {
        return String(s == null ? "" : s)
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    // ── 버전 비교 ────────────────────────────────────────────
    // 예전엔 3자리만 보고 NaN 을 0 으로 삼켰다. 그래서
    //   "v1.0.4" vs "1.0.3" -> -1 (배너 안 뜸)        ← 태그가 v 형식이라 실수하기 쉽다
    //   "1.0.3.1" vs "1.0.3" -> 0  (핫픽스 전달 불가)
    //   "1.0.4-beta" vs "1.0.3" -> 1 (프리릴리스가 전 팀에 배포)
    // 지금은 선행 v 를 벗기고, 순수 숫자·점 형식이 아니면 비교를 포기한다.
    // 비교 포기 = 0 = "업데이트 없음" 이므로 안전한 쪽으로 넘어진다.
    function cmpVer(a, b) {
        function norm(v) {
            v = String(v == null ? "" : v).replace(/^[vV]/, "");
            return /^\d+(\.\d+)*$/.test(v) ? v.split(".") : null;
        }
        var A = norm(a), B = norm(b);
        if (!A || !B) return 0;
        var n = Math.max(A.length, B.length), i, x, y;
        for (i = 0; i < n; i++) {
            x = parseInt(A[i], 10); if (isNaN(x)) x = 0;
            y = parseInt(B[i], 10); if (isNaN(y)) y = 0;
            if (x !== y) return x > y ? 1 : -1;
        }
        return 0;
    }

    // ── 경로 · 현재 버전 ─────────────────────────────────────
    function extRoot() {
        try {
            var p = cs.getSystemPath("extension");
            return p ? String(p).replace(/[\\\/]+$/, "") : "";
        } catch (e) { return ""; }
    }
    // 텍스트 파일 읽기.
    // Node 를 먼저 쓰지 않는다 — 매니페스트에 --enable-nodejs / --mixed-context 가
    // 켜져 있는데도 실제 패널에서는 require·Buffer·process 가 전부 undefined 다
    // (AE 2026 / CEP 12.0.1 / Chromium 99 에서 CDP 로 실측). CEP 자체 API 인
    // cep.fs 는 정상 동작하므로 이쪽을 우선한다. Node 는 폴백으로만 남긴다.
    function readText(p) {
        try {
            if (window.cep && cep.fs && cep.fs.readFile) {
                var r = cep.fs.readFile(p);
                if (r && r.err === 0) return r.data;
            }
        } catch (e) { warn("cep.fs 읽기 실패", e); }
        try { if (fs) return fs.readFileSync(p, "utf8"); } catch (e) { warn("fs 읽기 실패", e); }
        return "";
    }
    function localVersion() {
        var t = readText(extRoot() + "/CSXS/manifest.xml");
        if (!t) { warn("매니페스트를 읽지 못했습니다"); return ""; }
        var m = /ExtensionBundleVersion\s*=\s*"([^"]+)"/.exec(t);
        return m ? m[1] : "";
    }

    // ── 파일 입출력 (cep.fs) ─────────────────────────────────
    // Node 를 쓰지 않는다. 매니페스트에 --enable-nodejs / --mixed-context 가
    // 켜져 있는데도 실제 패널에는 require·Buffer·process 가 전부 없다
    // (AE 2026 / CEP 12.0.1 / Chromium 99 에서 CDP 로 실측).
    // cep.fs 는 정상 동작하며 Base64 로 바이너리 왕복도 정확하다.
    // 단 폴더 삭제 API 는 없다(deleteFile 은 디렉터리에 err=8). 아래 설계는 그걸 전제한다.
    var CEPFS = (function () {
        try { return (window.cep && cep.fs && cep.fs.readFile) ? cep.fs : null; }
        catch (e) { return null; }
    })();

    function u8ToB64(u8) {
        var s = "", CH = 0x8000, i;
        for (i = 0; i < u8.length; i += CH) {
            s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
        }
        return btoa(s);
    }
    function b64ToU8(b64) {
        var bin = atob(b64), u8 = new Uint8Array(bin.length), i;
        for (i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
        return u8;
    }
    function dirOf(p) { return p.replace(/[\/\\][^\/\\]*$/, ""); }

    function fsExists(p) { try { return !!CEPFS && CEPFS.stat(p).err === 0; } catch (e) { return false; } }
    function fsMkdirp(p) {
        if (!p || fsExists(p)) return fsExists(p);
        var parent = dirOf(p);
        if (parent && parent !== p) fsMkdirp(parent);
        try { CEPFS.makedir(p); } catch (e) {}
        return fsExists(p);
    }
    function fsReadBin(p) {
        try {
            var r = CEPFS.readFile(p, cep.encoding.Base64);
            return r.err === 0 ? b64ToU8(r.data) : null;
        } catch (e) { return null; }
    }
    function fsWriteBin(p, u8) {
        try {
            if (!fsMkdirp(dirOf(p))) return false;
            return CEPFS.writeFile(p, u8ToB64(u8), cep.encoding.Base64).err === 0;
        } catch (e) { return false; }
    }
    function fsDelete(p) {
        try { return CEPFS.deleteFile(p).err === 0; } catch (e) { return false; }
    }

    // 백업은 extensions 폴더 **밖**에 둔다.
    // 예전처럼 <extensions>/com.batchrenamecomps.bak 에 두면 같은 ExtensionBundleId 를
    // 가진 두 번째 확장이 되어 CEP 가 패널을 두 번 띄우거나 구버전을 로드한다.
    function bakRoot() {
        try {
            var u = cs.getSystemPath("userData");
            return u ? String(u).replace(/[\\\/]+$/, "") + "/Adobe/CEP/BRC_backup" : "";
        } catch (e) { return ""; }
    }

    // 무결성 검증. Node crypto 가 없으므로 SubtleCrypto 를 쓴다.
    // file:// 은 secure context 로 취급돼 crypto.subtle 이 살아 있다(실측).
    function sha256Hex(u8, cb) {
        try {
            window.crypto.subtle.digest("SHA-256", u8).then(function (buf) {
                var a = new Uint8Array(buf), s = "", i;
                for (i = 0; i < a.length; i++) s += ("0" + a[i].toString(16)).slice(-2);
                cb(s);
            }, function () { cb(null); });
        } catch (e) { cb(null); }
    }

    // zip 엔트리 -> 확장 폴더 기준 상대경로. 조금이라도 수상하면 null.
    // 예전엔 prefix 문자열 검사만 해서 "com.batchrenamecomps/../../evil.bat" 이
    // 통과한 뒤 join 이 정규화하며 확장 폴더 밖에 쓰였다.
    var PREFIX = "com.batchrenamecomps/";
    var MANIFEST_REL = "CSXS/manifest.xml";
    var MARKER_REL = ".brc_installing";
    function safeRel(key) {
        if (key.indexOf(PREFIX) !== 0) return null;
        var rel = key.substring(PREFIX.length);
        if (!rel || /\/$/.test(rel)) return null;
        if (rel.charAt(0) === "/" || /^[A-Za-z]:/.test(rel)) return null;
        if (rel.indexOf("\\") !== -1) return null;
        var parts = rel.split("/"), i;
        for (i = 0; i < parts.length; i++) {
            if (parts[i] === "" || parts[i] === "." || parts[i] === "..") return null;
        }
        return rel;
    }

    // ── 배너 높이 애니메이션 ─────────────────────────────────
    function fit() {
        if (!band || !inner) return;
        var h = 0;
        for (var i = 0; i < inner.children.length; i++) {
            var k = inner.children[i];
            if (k.style.position !== "absolute" && k.offsetHeight > h) h = k.offsetHeight;
        }
        if (band.style.height === "auto") band.style.height = band.offsetHeight + "px";
        band.style.height = h + "px";
    }
    function paint(html) {
        if (!band || !inner) return;
        if (band.style.height === "auto") {
            band.style.height = band.offsetHeight + "px";
            void band.offsetHeight;
        }
        // 남아 있는 화면을 **전부** 내보낸다. firstElementChild 하나만 처리하면
        // 280ms 제거 대기 중에 또 paint 가 오는 경우(예: 로컬/캐시 응답으로 다운로드가
        // 순식간에 끝나 설치중 -> 실패가 연달아 뜨는 경우) 직전 화면이 안 지워지고 쌓인다.
        // 실측으로 확인: 확인 -> 설치중 -> 실패가 300ms 안에 일어나면 세 장이 겹쳤다.
        var olds = Array.prototype.slice.call(inner.children), oi;
        for (oi = 0; oi < olds.length; oi++) {
            (function (old) {
                old.style.position = "absolute";
                old.style.top = "0"; old.style.left = "0"; old.style.right = "0";
                old.style.opacity = "0";
                old.style.transform = "translateY(-4px)";
                old.style.pointerEvents = "none";   // 사라지는 동안 새 버튼을 가리지 않게
                setTimeout(function () { if (old.parentNode) old.parentNode.removeChild(old); }, 280);
            })(olds[oi]);
        }
        if (html) {
            var n = document.createElement("div");
            n.innerHTML = html;
            n.style.opacity = "0";
            n.style.transform = "translateY(4px)";
            n.style.transition = "opacity 0.25s ease, transform 0.25s ease";
            inner.appendChild(n);
            curView = n;
            fit();
            setTimeout(function () { n.style.opacity = "1"; n.style.transform = "translateY(0)"; }, 16);
        } else {
            curView = null;
            band.style.height = "0px";
        }
    }

    // 방금 그린 화면 안에서만 찾는다.
    // document.getElementById 를 쓰면 안 된다 — paint() 가 이전 화면 노드를 280ms 동안
    // 남겨두는데 그 안에 같은 id 가 들어 있으면 문서 순서상 옛 노드가 먼저 잡힌다.
    // 그러면 화면에 보이는 새 버튼이 아니라 곧 사라질 버튼에 핸들러가 붙어서,
    // 두 번째로 띄운 순간부터 버튼이 전부 먹통이 된다.
    function q(id) {
        return curView ? curView.querySelector("#" + id) : $(id);
    }

    // 배너는 #mainScreen 안에 있어서 설정 화면이 열려 있으면 오버레이에 가린다.
    // 사용자가 직접 '업데이트 확인'을 눌렀다면 결과를 볼 수 있는 곳으로 데려가야 한다.
    function ensureVisible() {
        try {
            var s = document.getElementById("settingsScreen");
            if (s && s.classList.contains("slide-in") && typeof closeSettings === "function") {
                closeSettings();
            }
            var m = $("mainScreen");
            if (m) m.scrollTop = 0;
        } catch (e) { warn("화면 전환 실패", e); }
    }
    function showHint(on) { if (hint) hint.style.display = on ? "block" : "none"; }

    // ── 화면 ─────────────────────────────────────────────────
    function notesHtml() {
        var n = (info && info.notes) || [];
        var s = "";
        for (var i = 0; i < n.length && i < 3; i++) s += (s ? "<br>" : "") + "· " + esc(n[i]);
        return s;
    }
    // 패널 안에서 파일 교체가 가능한 환경인가.
    // 불가능한 환경에서 '지금 설치'를 내밀면 눌러도 실패만 하므로
    // 그 자리에 '사이트에서 받기'를 대신 세운다.
    function canInstall() { return !!CEPFS; }

    function viewFound() {
        var act = canInstall()
            ? '<button class="upd-btn primary" id="updGo">지금 설치</button>'
            : '<button class="upd-btn primary" id="updSite">사이트에서 받기</button>';
        paint(
            '<div class="upd info"><span class="upd-ic">&#9650;</span><div class="upd-body">' +
            '<div class="upd-title">새 버전 v' + esc(info.version) + ' 이 있어요</div>' +
            '<div class="upd-note">' + notesHtml() + '</div>' +
            '<div class="upd-acts">' + act +
            '<button class="upd-btn" id="updLater">나중에</button>' +
            '<button class="upd-link" id="updSkip">건너뛰기</button>' +
            '</div></div></div>'
        );
        showHint(true);
        if (canInstall()) bind("updGo", install); else bind("updSite", openSite);
        bind("updLater", function () { paint(""); showHint(true); });
        bind("updSkip", function () {
            try { localStorage.setItem(K_SKIP, info.version); } catch (e) {}
            paint(""); showHint(false);
        });
    }
    var STEPS = ["설치 파일 받는 중", "현재 버전 백업", "압축 푸는 중", "파일 교체"];
    function stepsHtml(cur) {
        var s = "";
        for (var i = 0; i < STEPS.length; i++) {
            var c = i < cur ? "st-done" : (i === cur ? "st-cur" : "st-wait");
            var m = i < cur ? "&#10003;" : (i === cur ? "&#9679;" : "&#9675;");
            s += '<div class="' + c + '"><span class="st-m">' + m + '</span>' + STEPS[i] + '</div>';
        }
        return s;
    }
    function viewInstall() {
        paint(
            '<div class="upd info"><div class="upd-body">' +
            '<div class="upd-title">v' + esc(info.version) + ' 설치 중</div>' +
            '<div class="upd-bar"><i id="updBar"></i></div>' +
            '<div class="upd-steps" id="updSteps">' + stepsHtml(0) + '</div>' +
            '</div></div>'
        );
        showHint(true);
    }
    function setBar(r) {
        var b = q("updBar");
        if (b) b.style.width = Math.round(Math.max(0, Math.min(1, r)) * 100) + "%";
    }
    function setStep(i) {
        var s = q("updSteps");
        if (s) { s.innerHTML = stepsHtml(i); fit(); }
    }
    function viewDone() {
        paint(
            '<div class="upd ok"><span class="upd-ic">&#10003;</span><div class="upd-body">' +
            // 성공하면 백업을 지우므로 "보관해뒀어요"라고 하면 안 된다.
            // 되돌릴 수단은 사이트에서 이전 버전을 받는 것뿐이다.
            '<div class="upd-title">v' + esc(info.version) + ' 설치 완료</div>' +
            '<div class="upd-note">애프터이펙트를 재시작하면 적용돼요.</div>' +
            '<div class="upd-acts"><button class="upd-btn primary" id="updOk">확인</button></div>' +
            '</div></div>'
        );
        showHint(false);
        bind("updOk", function () { paint(""); });
    }
    // ── 실패 화면 ────────────────────────────────────────────
    // 실패에는 두 종류가 있고, 사용자가 해야 할 일이 서로 다르다.
    //   · 확인 실패 — 설치를 시작하지도 않았다. 파일은 손도 안 댔다.
    //   · 설치 실패 — 파일을 건드렸을 수 있다. 되돌렸는지까지 알려줘야 한다.
    // 예전엔 둘이 같은 화면을 써서, 서버가 404 를 준 것뿐인데도
    // "이전 버전으로 되돌렸어요"라고 말했다. 그러면 진짜 파손과
    // 단순 네트워크 오류를 화면에서 구분할 방법이 없다.
    function viewCheckFail(msg) {
        paint(
            '<div class="upd warn"><span class="upd-ic">!</span><div class="upd-body">' +
            '<div class="upd-title">업데이트를 확인하지 못했어요</div>' +
            '<div class="upd-note">지금은 서버에 연결할 수 없어요. 패널은 그대로 쓰시면 돼요.' +
            (msg ? '<br><span class="upd-dim">' + esc(msg) + '</span>' : '') + '</div>' +
            '<div class="upd-acts">' +
            '<button class="upd-btn primary" id="updRecheck">다시 확인</button>' +
            '<button class="upd-btn" id="updSite">사이트에서 받기</button>' +
            '<button class="upd-link" id="updClose">닫기</button>' +
            '</div></div></div>'
        );
        showHint(false);   // 새 버전이 있다는 신호가 아니므로 띠를 켜지 않는다
        bind("updRecheck", function () { check(true); });
        bind("updSite", openSite);
        bind("updClose", function () { paint(""); });
    }

    // state — "nochange": 파일을 건드리기 전에 멈춤 / "rolled": 되돌림 / "broken": 되돌리기도 실패
    function viewFail(msg, state) {
        var head = "설치하지 못했어요", note, retry = true;
        if (state === "broken") {
            head = "설치가 중간에 멈췄어요";
            note = "되돌리기도 실패했어요. 패널이 정상이 아닐 수 있어요.<br>사이트에서 받아 다시 설치해주세요.";
            retry = false;   // 오염된 상태로 재시도하면 마지막 백업까지 덮어쓴다
        } else if (state === "rolled") {
            note = "이전 버전으로 되돌렸어요. 패널은 그대로 쓰시면 돼요.";
        } else {
            note = "아무것도 바꾸지 않았어요. 패널은 그대로 쓰시면 돼요.";
        }
        paint(
            '<div class="upd warn"><span class="upd-ic">!</span><div class="upd-body">' +
            '<div class="upd-title">' + head + '</div>' +
            '<div class="upd-note">' + note +
            (msg ? '<br><span class="upd-dim">' + esc(msg) + '</span>' : '') + '</div>' +
            '<div class="upd-acts">' +
            '<button class="upd-btn primary" id="updSite">사이트에서 받기</button>' +
            (retry ? '<button class="upd-btn" id="updRetry">다시 시도</button>' : '') +
            '</div></div></div>'
        );
        showHint(true);
        bind("updSite", openSite);
        if (retry) bind("updRetry", install);
    }
    function viewLatest() {
        paint('<div class="upd ok"><span class="upd-ic">&#10003;</span><div class="upd-body">' +
              '<div class="upd-title">최신 버전을 쓰고 계세요</div></div></div>');
        setTimeout(function () { paint(""); }, 2200);
    }
    function bind(id, fn) { var e = q(id); if (e) e.onclick = fn; }

    function openSite() {
        try {
            if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) {
                window.cep.util.openURLInDefaultBrowser(SITE_URL);
                return;
            }
        } catch (e) {}
        // Node 폴백은 없앴다 — 이 패널에는 require 도 process 도 없다.
        warn("사이트를 열지 못했습니다. 주소: " + SITE_URL);
    }

    // ── 내려받기 ─────────────────────────────────────────────
    function download(url, onProg, cb) {
        var x = new XMLHttpRequest();
        x.open("GET", url + (url.indexOf("?") >= 0 ? "&" : "?") + "t=" + Date.now(), true);
        x.responseType = "arraybuffer";
        x.timeout = 90000;
        x.onprogress = function (e) { if (e.lengthComputable && onProg) onProg(e.loaded / e.total); };
        x.onload = function () {
            if (x.status >= 200 && x.status < 300 && x.response) cb(null, new Uint8Array(x.response));
            else cb(new Error("HTTP " + x.status));
        };
        x.onerror   = function () { cb(new Error("네트워크 오류")); };
        x.ontimeout = function () { cb(new Error("응답 시간 초과")); };
        x.send();
    }

    // ── 설치 ─────────────────────────────────────────────────
    // 순서가 곧 안전장치다.
    //   1) 내려받기          - 아직 아무것도 안 건드림
    //   2) 해시 검증         - 틀리면 여기서 멈춘다. 파일은 그대로
    //   3) 압축 해제·경로 검증 - 수상한 엔트리가 하나라도 있으면 중단
    //   4) 덮어쓸 파일만 백업  - 폴더 삭제 API 가 없으므로 평면 파일로 저장
    //   5) 쓰기 (manifest 는 맨 마지막)
    //   6) 실패하면 되돌리고, 되돌리기까지 실패했는지를 화면에 정직하게 알림
    function install() {
        if (busy) return;
        if (!CEPFS) { viewFail("이 환경에서는 파일을 쓸 수 없습니다", "nochange"); return; }
        if (!info || !info.zip) { viewFail("배포 정보 없음", "nochange"); return; }

        // zip 주소가 배포 저장소를 가리키는지 확인한다.
        // version.json 이 조작되면 임의 서버의 zip 을 Node 권한 확장 폴더에 풀게 된다.
        if (String(info.zip).indexOf(ZIP_ORIGIN) !== 0) {
            viewFail("배포 주소가 올바르지 않습니다", "nochange");
            return;
        }
        var root = extRoot();
        if (!root) { viewFail("확장 경로 확인 실패", "nochange"); return; }
        var bak = bakRoot();
        if (!bak || !fsMkdirp(bak)) { viewFail("백업 폴더를 만들지 못했습니다", "nochange"); return; }

        busy = true;
        viewInstall();

        function fail(msg, state) {
            busy = false;
            warn("설치 실패: " + msg);
            viewFail(msg, state || "nochange");
        }

        download(info.zip, function (p) { setBar(p * 0.5); }, function (err, data) {
            if (err) return fail(err && err.message ? err.message : String(err), "nochange");
            setBar(0.55);
            sha256Hex(data, function (hex) {
                if (info.sha256) {
                    if (!hex) return fail("무결성을 확인할 수 없습니다", "nochange");
                    if (hex !== String(info.sha256).toLowerCase()) {
                        return fail("내려받은 파일이 배포본과 다릅니다", "nochange");
                    }
                }
                setStep(1); setBar(0.6);
                setTimeout(function () { applyPackage(root, bak, data, fail); }, 40);
            });
        });
    }

    function applyPackage(root, bak, data, fail) {
        var files;
        try { files = fflate.unzipSync(data); }
        catch (e) { return fail("압축을 풀지 못했습니다", "nochange"); }

        // 설치 대상 수집 + 경로 검증
        var plan = [], k, rel, hasManifest = false;
        for (k in files) {
            if (!files.hasOwnProperty(k)) continue;
            if (k.indexOf(PREFIX) !== 0) continue;      // 확장 밖 파일(설치안내.txt 등)은 대상이 아니다
            if (/\/$/.test(k)) continue;                // 디렉터리 엔트리
            rel = safeRel(k);
            if (rel === null) return fail("패키지에 잘못된 경로가 있습니다", "nochange");
            if (rel === MARKER_REL) continue;
            if (rel === MANIFEST_REL) hasManifest = true;
            plan.push({ rel: rel, data: files[k] });
        }
        if (!plan.length || !hasManifest) return fail("패키지 형식 오류", "nochange");

        // manifest 를 맨 뒤로 보낸다.
        // 앞쪽 쓰기가 실패했는데 버전 표식만 새 것이 되면 localVersion() 이 신버전을 읽어
        // 배너가 영영 안 뜬다. 신기능은 없는데 도구는 "최신"이라고 말하는, 자동 복구가
        // 불가능한 유일한 상태다.
        plan.sort(function (a, b) {
            if (a.rel === MANIFEST_REL) return 1;
            if (b.rel === MANIFEST_REL) return -1;
            return 0;
        });

        setStep(2); setBar(0.7);

        // 덮어쓸 파일만 백업한다. 폴더 삭제 API 가 없으므로 평면 이름으로 저장하고,
        // 다음 설치 때는 같은 이름을 덮어쓴다 — 폴더를 비울 필요가 없는 구조다.
        var saved = [], i, cur, bp;
        for (i = 0; i < plan.length; i++) {
            cur = fsReadBin(root + "/" + plan[i].rel);
            if (cur === null) { saved.push({ rel: plan[i].rel, bak: null }); continue; }
            bp = bak + "/" + plan[i].rel.replace(/\//g, "__");
            if (!fsWriteBin(bp, cur)) return fail("백업하지 못했습니다", "nochange");
            saved.push({ rel: plan[i].rel, bak: bp });
        }

        setStep(3); setBar(0.82);

        // 진행 마커 — 중간에 죽어도 다음 부팅 때 알아챌 수 있다
        var marker = root + "/" + MARKER_REL;
        fsWriteBin(marker, new Uint8Array([49]));

        function rollback() {
            var ok = true, j, s2, b;
            for (j = 0; j < saved.length; j++) {
                s2 = saved[j];
                if (s2.bak) {
                    b = fsReadBin(s2.bak);
                    if (b === null || !fsWriteBin(root + "/" + s2.rel, b)) ok = false;
                } else if (fsExists(root + "/" + s2.rel)) {
                    // 이 버전에서 새로 생긴 파일. 되돌린다는 건 지운다는 뜻이다.
                    if (!fsDelete(root + "/" + s2.rel)) ok = false;
                }
            }
            return ok;
        }

        for (i = 0; i < plan.length; i++) {
            if (!fsWriteBin(root + "/" + plan[i].rel, plan[i].data)) {
                var restored = rollback();
                fsDelete(marker);
                return fail("파일을 쓰지 못했습니다 (" + plan[i].rel + ")",
                            restored ? "rolled" : "broken");
            }
        }

        fsDelete(marker);
        for (i = 0; i < saved.length; i++) if (saved[i].bak) fsDelete(saved[i].bak);

        setBar(1); setStep(4);
        busy = false;
        setTimeout(viewDone, 600);
    }

    // ── 확인 ─────────────────────────────────────────────────
    function check(manual) {
        var today = new Date().toISOString().slice(0, 10);
        if (!manual) {
            try { if (localStorage.getItem(K_LAST) === today) return; } catch (e) {}
        }
        try { localStorage.setItem(K_LAST, today); } catch (e) {}

        // 직접 누른 확인은 반드시 결과가 보여야 한다. 설정 화면에 있으면 배너가 가려지므로
        // 요청을 보내는 시점에 메인으로 돌려보낸다.
        if (manual) ensureVisible();

        var x = new XMLHttpRequest();
        x.open("GET", VERSION_URL + "?t=" + Date.now(), true);
        x.timeout = 15000;
        x.onload = function () {
            if (x.status < 200 || x.status >= 300) { if (manual) viewCheckFail("서버 응답 " + x.status); return; }
            try { info = JSON.parse(x.responseText); }
            catch (e) { if (manual) viewCheckFail("정보 해석 실패"); return; }
            if (!info || !info.version) { if (manual) viewCheckFail("정보 형식 오류"); return; }
            var cur = localVersion();
            if (cur && cmpVer(info.version, cur) <= 0) { if (manual) viewLatest(); return; }
            if (!manual) {
                try { if (localStorage.getItem(K_SKIP) === info.version) return; } catch (e) {}
            }
            viewFound();
        };
        x.onerror   = function () { if (manual) viewCheckFail("네트워크 오류"); };
        x.ontimeout = function () { if (manual) viewCheckFail("응답 시간 초과"); };
        x.send();
    }

    // ── 초기화 ───────────────────────────────────────────────
    // 설정 화면 제목 옆 버전 표기. 매니페스트를 읽는 곳이 여기뿐이라 같이 채운다.
    // 읽기에 실패하면 빈 채로 둔다 — 틀린 버전을 보여주는 것보다 안 보여주는 쪽이 낫다.
    function paintVersion() {
        var el = $("settingsVer");
        if (!el) return;
        var v = localVersion();
        el.textContent = v ? "v" + v : "";
    }

    // 지난 설치가 파일을 쓰다 말고 끝났는지 확인한다.
    // 마커가 남아 있으면 확장이 반쪽 상태일 수 있으므로 사용자에게 알린다.
    function checkUnfinished() {
        var root = extRoot();
        if (!root || !CEPFS) return false;
        if (!fsExists(root + "/" + MARKER_REL)) return false;
        paint(
            '<div class="upd warn"><span class="upd-ic">!</span><div class="upd-body">' +
            '<div class="upd-title">지난 설치가 끝나지 않았어요</div>' +
            '<div class="upd-note">파일을 쓰다 중단된 흔적이 있어요. 패널이 정상이 아닐 수 있으니 ' +
            '사이트에서 받아 다시 설치해주세요.</div>' +
            '<div class="upd-acts">' +
            '<button class="upd-btn primary" id="updSite">사이트에서 받기</button>' +
            '<button class="upd-link" id="updClose">닫기</button>' +
            '</div></div></div>'
        );
        showHint(true);
        bind("updSite", openSite);
        bind("updClose", function () {
            fsDelete(root + "/" + MARKER_REL);   // 확인했으면 다시 묻지 않는다
            paint(""); showHint(false);
        });
        return true;
    }

    document.addEventListener("DOMContentLoaded", function () {
        paintVersion();
        band  = $("updBand");
        inner = $("updInner");
        hint  = $("updHint");
        if (!band || !inner) return;
        band.addEventListener("transitionend", function (e) {
            if (e.propertyName === "height" && band.style.height !== "0px") band.style.height = "auto";
        });
        if (hint) hint.onclick = function () {
            try { $("mainScreen").scrollTop = 0; } catch (err) {}
            if (!inner.firstElementChild && info) viewFound();
        };
        // 미완료 설치가 있으면 그것부터 알린다. 업데이트 확인은 건너뛴다.
        if (checkUnfinished()) return;
        setTimeout(function () { try { check(false); } catch (e) { warn("확인 실패", e); } }, 1500);
    });

    window.brcCheckUpdate = function () { try { check(true); } catch (e) { warn("수동 확인 실패", e); } };
})();
