﻿// ============================================================
// BatchRenameComps - ExtendScript Host
// AE / Premiere Pro
// ============================================================

var IS_PREMIERE = (typeof BridgeTalk !== "undefined" &&
    BridgeTalk.appName.toLowerCase().indexOf("premierepro") !== -1);

// -- Data --
var _RES_LIST = ["1920x1080","1080x1080","1080x1920","1080x1350",
                 "1200x628","1200x1200","1200x1500",
                 "1440x1440","1440x1800","3840x2160","2160x3840"];
var _JOBKIND_CODES = ["@MB","@BC","@SZ","@ED","@AV","@AB","@MV","@SH","@CP"];

// ══════════════════════════════════════════════════════════════
// 팀원 이니셜 목록 — 팀원 입·퇴사 시 이 배열만 수정하면 됩니다.
// ══════════════════════════════════════════════════════════════
var _WORKER_LIST = ["KMS","HYC","JJH","PNJ","KBH","GJH"];
function _isWorkerInitial(p) {
    p = String(p||"").toUpperCase();
    for (var i=0;i<_WORKER_LIST.length;i++) if (p===_WORKER_LIST[i]) return true;
    return false;
}

// -- Util --
function _trim(s) { return String(s==null?"":s).replace(/^\s+|\s+$/g,""); }
function _sanitize(s) {
    return String(s==null?"":s).replace(/[\\\/:\*\?"<>\|]/g,"").replace(/\s+/g," ");
}
// 폴더/파일 이름의 퍼센트 인코딩을 안전하게 디코드 (실패 시 원본 반환)
function _decodeName(s) {
    try { return decodeURIComponent(String(s)); } catch(e) { return String(s); }
}
// 경로에 비ASCII(한글 등) 문자가 있는지 검사 — om.file 한글 버그 회피 판단용
function _isAsciiPath(p) {
    return /^[\x00-\x7F]*$/.test(String(p));
}
// 렌더용 ASCII 임시 루트 폴더 확보 (om.file setter가 멀티바이트 경로를 깨뜨리므로
// 사용자명이 한글이어도 안전하도록 순수 ASCII 경로를 찾는다)
// 후보를 순서대로: 환경변수 TEMP/TMP → C:\ProgramData → 드라이브 루트들 → (최후) Folder.temp/userData
function _getAsciiTempRoot() {
    var candidates = [];
    try {
        // Windows 시스템 임시 경로 환경변수 (보통 ASCII지만 사용자명 한글이면 %TEMP%도 한글일 수 있음)
        var envTmp = ($.getenv ? ($.getenv("TEMP") || $.getenv("TMP")) : null);
        if (envTmp) candidates.push(envTmp);
    } catch(_) {}
    var isWin = ($.os.indexOf("Windows") !== -1);
    if (isWin) {
        try {
            var sysDrive = ($.getenv ? $.getenv("SystemDrive") : null) || "C:";
            candidates.push(sysDrive + "\\ProgramData");
            candidates.push(sysDrive + "\\Temp");
            candidates.push(sysDrive + "\\");
        } catch(_) {
            candidates.push("C:\\ProgramData");
            candidates.push("C:\\Temp");
            candidates.push("C:\\");
        }
    } else {
        // macOS / 기타: /tmp, /private/tmp, /Users/Shared
        candidates.push("/tmp");
        candidates.push("/private/tmp");
        candidates.push("/Users/Shared");
    }
    // 후보 중 ASCII이고 생성/쓰기 가능한 첫 번째를 채택
    for (var i = 0; i < candidates.length; i++) {
        var base = candidates[i];
        if (!base || !_isAsciiPath(base)) continue;
        try {
            var root = new Folder(base + "/brc_render_temp");
            if (!root.exists) root.create();
            if (root.exists && _isAsciiPath(root.fsName)) {
                // 쓰기 가능 여부 확인 (테스트 파일 생성/삭제)
                var testF = new File(root.fsName + "/.brc_write_test");
                var ok = false;
                try {
                    testF.open("w"); testF.write("1"); testF.close();
                    if (testF.exists) { ok = true; testF.remove(); }
                } catch(_) { ok = false; }
                if (ok) return root;
            }
        } catch(_) {}
    }
    // 최후 폴백: Folder.temp → userData (ASCII 보장 못 하지만 없는 것보단 나음)
    try {
        if (Folder.temp && Folder.temp.exists) {
            var ft = new Folder(Folder.temp.fsName + "/brc_render_temp");
            if (!ft.exists) ft.create();
            if (ft.exists) return ft;
        }
    } catch(_) {}
    var ud = new Folder(Folder.userData.fsName + "/brc_render_temp");
    if (!ud.exists) ud.create();
    return ud;
}
// 폴더 안에 Sc(소스) 분류 폴더가 있는지 (디스크 트리 루트 판별용)
function _hasScFolder(parentFolder) {
    try {
        if (!parentFolder || !parentFolder.exists) return false;
        var subs = parentFolder.getFiles(function(f){ return f instanceof Folder; });
        for (var i = 0; i < subs.length; i++) {
            var nm = _decodeName(subs[i].name).toLowerCase();
            // "02_sc", "05_sc" 등 _sc로 끝나거나 정확히 sc
            if (nm === "sc" || /[_\- ]sc$/.test(nm)) return true;
        }
    } catch(e) {}
    return false;
}

// 폴더 안에 이름이 특정 태그(ae/pr/master)로 끝나거나 일치하는 하위 폴더가 있는지
function _hasTagFolder(parentFolder, tag) {
    try {
        if (!parentFolder || !parentFolder.exists) return false;
        var t = String(tag).toLowerCase();
        var re = new RegExp("[_\\- ]" + t + "$");
        var subs = parentFolder.getFiles(function(f){ return f instanceof Folder; });
        for (var i = 0; i < subs.length; i++) {
            var nm = _decodeName(subs[i].name).toLowerCase();
            if (nm === t || re.test(nm) ||
                (nm.length >= 2 && nm.substring(nm.length - 2) === t)) return true;
        }
    } catch(e) {}
    return false;
}
function _jobKindCode(label) {
    label = String(label||"");
    var i = label.indexOf(":");
    return i !== -1 ? label.substring(0, i) : label;
}

// -- Item Access --
function _getSelectedItems() {
    var result = [];
    try {
        if (IS_PREMIERE) {
            // Premiere: selected sequences in project panel
            try {
                var sel = app.project.rootItem.children;
                if (sel && sel.numItems > 0) {
                    for (var i = 0; i < sel.numItems; i++) {
                        var item = sel[i];
                        // type 1 = sequence
                        if (item && item.type === 1 && item.selected) {
                            result.push(item);
                        }
                    }
                }
            } catch(e) {}
            // fallback to activeSequence
            if (!result.length && app.project.activeSequence) {
                result.push(app.project.activeSequence);
            }
        } else {
            // AE
            var sel = app.project.selection;
            if (!sel || !sel.length) return result;
            for (var i = 0; i < sel.length; i++) {
                if (!sel[i]) continue;
                if (typeof CompItem !== "undefined" && sel[i] instanceof CompItem)
                    result.push(sel[i]);
            }
        }
    } catch(e) {}
    return result;
}
function _getName(item) { try { return String(item.name||""); } catch(e) { return ""; } }
function _setName(item, name) { try { item.name = name; } catch(e) {} }
function _withUndo(label, fn) {
    if (IS_PREMIERE) {
        // Premiere does not support beginUndoGroup
        try { fn(); } catch(e) {}
    } else {
        try { app.beginUndoGroup(label); } catch(e) {}
        try { fn(); } catch(e) {}
        try { app.endUndoGroup(); } catch(e) {}
    }
}

// -- Token Detection --
function _stripNum(name) { return String(name||"").replace(/\s+\d+$/,""); }
function _isDate(p) { return /^\d{6}$/.test(String(p)); }
function _isRes(p) {
    // 목록 기반 + 패턴 기반 (커스텀 해상도 포함)
    if (/^\d{3,4}[xX]\d{3,4}$/.test(String(p))) return true;
    for (var i=0;i<_RES_LIST.length;i++) if (p===_RES_LIST[i]) return true;
    return false;
}
function _isWorkType(p) {
    p = String(p||"");
    return p==="xian"||p==="vari"||p==="sf"||/^retuch\d+$/.test(p);
}
function _isJobKind(p) {
    p = String(p||"");
    for (var i=0;i<_JOBKIND_CODES.length;i++) if (p===_JOBKIND_CODES[i]) return true;
    return false;
}
function _isSpecial(p) {
    return _isDate(p)||_isRes(p)||_isWorkType(p)||_isJobKind(p)||/^\d+p$/.test(p);
}

// Worker: uppercase token just before @jobKind
// excluded from _isSpecial to avoid generic index confusion

// merge _number suffix with previous token
function _smartSplit(name) {
    var raw = _stripNum(name).split("_");
    var merged = [];
    var i = 0;
    while (i < raw.length) {
        var p = raw[i];
        if (i+1 < raw.length && /^\d+$/.test(raw[i+1]) && !_isSpecial(p)) {
            merged.push(p + "_" + raw[i+1]);
            i += 2;
        } else {
            merged.push(p);
            i += 1;
        }
    }
    return merged;
}

// -- Name Manipulation --
function _applyDate(name, v) {
    var parts = _stripNum(name).split("_");
    if (parts.length > 0 && _isDate(parts[0])) parts[0] = v;
    else parts.unshift(v);
    return parts.join("_");
}
function _applyRes(name, v) {
    var parts = _stripNum(name).split("_");
    // replace existing resolution
    for (var i=0;i<parts.length;i++) {
        if (_isRes(parts[i])) { parts[i]=v; return parts.join("_"); }
    }
    var insertIdx = parts.length;
    // 1순위: @작업종류 바로 앞 대문자(작업자) 앞에 삽입
    for (var j=1;j<parts.length;j++) {
        if (_isJobKind(parts[j]) && /^[A-Z]{2,5}$/.test(parts[j-1])) {
            insertIdx = j - 1;
            break;
        }
    }
    // 2순위: @작업종류 앞에 삽입
    if (insertIdx === parts.length) {
        for (var k=0;k<parts.length;k++) {
            if (_isJobKind(parts[k])) { insertIdx = k; break; }
        }
    }
    // 3순위: @작업종류 없으면 마지막 대문자 토큰(작업자) 앞에 삽입
    if (insertIdx === parts.length) {
        for (var m=parts.length-1;m>=0;m--) {
            if (/^[A-Z]{2,5}$/.test(parts[m])) { insertIdx = m; break; }
        }
    }
    parts.splice(insertIdx, 0, v);
    return parts.join("_");
}
function _applyJobKind(name, v) {
    var parts = _stripNum(name).split("_");
    for (var i=0;i<parts.length;i++) {
        if (_isJobKind(parts[i])) { parts[i]=v; return parts.join("_"); }
    }
    var idx = (parts.length>=1&&_isWorkType(parts[parts.length-1]))?parts.length-1:parts.length;
    parts.splice(idx,0,v);
    return parts.join("_");
}
function _applyWorkType(name, v) {
    var parts = _stripNum(name).split("_");
    var isRetuch = /^retuch\d+$/.test(v);
    for (var i=0;i<parts.length;i++) {
        if (_isWorkType(parts[i])) {
            if (isRetuch && /^retuch(\d+)$/.test(parts[i])) {
                var m = parts[i].match(/^retuch(\d+)$/);
                parts[i] = "retuch" + (parseInt(m[1],10)+1);
            } else {
                parts[i] = v;
            }
            return parts.join("_");
        }
    }
    parts.push(v);
    return parts.join("_");
}
function _applyWorker(name, v) {
    var parts = _stripNum(name).split("_");
    // replace uppercase token just before @jobKind
    for (var i=1;i<parts.length;i++) {
        if (_isJobKind(parts[i]) && /^[A-Z]{2,5}$/.test(parts[i-1])) {
            parts[i-1] = v;
            return parts.join("_");
        }
    }
    // no @jobKind, replace last uppercase token
    for (var j=parts.length-1;j>=0;j--) {
        if (/^[A-Z]{2,5}$/.test(parts[j]) && !_isJobKind(parts[j])) {
            parts[j] = v;
            return parts.join("_");
        }
    }
    // insert before @jobKind
    var idx = parts.length;
    for (var k=0;k<parts.length;k++) {
        if (_isJobKind(parts[k])) { idx = k; break; }
    }
    parts.splice(idx, 0, v);
    return parts.join("_");
}
function _applyPage(name, v) {
    var parts = _stripNum(name).split("_");
    var token = v + "p";
    // 이미 페이지 있으면 교체
    for (var i=0;i<parts.length;i++) {
        if (/^\d+p$/.test(parts[i])) { parts[i]=token; return parts.join("_"); }
    }
    // 없으면 generic[2] 앞(캠페인명 다음, 작업내용 앞)에 삽입
    var genericCount = 0;
    for (var j=0;j<parts.length;j++) {
        if (!_isSpecial(parts[j])) {
            genericCount++;
            if (genericCount === 2) {
                // generic[1] 다음 위치 = generic[2] 앞
                parts.splice(j+1, 0, token);
                return parts.join("_");
            }
        }
    }
    // generic이 2개 미만이면 끝에 삽입
    parts.push(token);
    return parts.join("_");
}
function _applyGeneric(name, v, idx) {
    var parts = _smartSplit(name);
    var count = 0;
    for (var i=0;i<parts.length;i++) {
        if (!_isSpecial(parts[i])) {
            if (count===idx) { parts[i]=v; return parts.join("_"); }
            count++;
        }
    }
    // 해당 인덱스의 generic이 없으면 끝에 추가
    parts.push(v);
    return parts.join("_");
}

// task 적용: oldVal의 연속 토큰들을 찾아 newVal 단일 토큰으로 교체
function _applyTask(name, oldVal, newVal) {
    var parts = _smartSplit(name);

    if (oldVal) {
        // oldVal도 smartSplit으로 분리 (숫자 접미사가 앞 토큰에 합쳐짐)
        var oldParts = _smartSplit(oldVal);
        var oldLen = oldParts.length;

        for (var i = 0; i <= parts.length - oldLen; i++) {
            var match = true;
            for (var j = 0; j < oldLen; j++) {
                if (parts[i+j] !== oldParts[j]) { match = false; break; }
            }
            if (match) {
                var newParts = [];
                for (var k = 0; k < i; k++) newParts.push(parts[k]);
                newParts.push(newVal);
                for (var m = i + oldLen; m < parts.length; m++) newParts.push(parts[m]);
                return newParts.join("_");
            }
        }
    }

    // 못 찾으면 generic[2] 위치에 적용
    return _applyGeneric(name, newVal, 2);
}

// -- Comp Name Parsing --
function _parseCompName(name) {
    var result = { client:"",campaign:"",page:"",task:"",resolution:"",jobKind:"",workType:"" };
    if (!name) return result;
    var parts = _smartSplit(name);
    var generic = [];

    // find worker index first
    var workerIdx = -1;
    for (var i=1;i<parts.length;i++) {
        if (_isJobKind(parts[i]) && /^[A-Z]{2,5}$/.test(parts[i-1])) {
            workerIdx = i-1;
            break;
        }
    }
    // 작업종류(@XX)가 없는 이름의 작업자 판별
    if (workerIdx < 0) {
        var gIdx = [];
        for (var g=0; g<parts.length; g++) {
            if (parts[g] && !_isSpecial(parts[g])) gIdx.push(g);
        }
        // 1순위: 팀원 이니셜 목록(_WORKER_LIST)에 있는 토큰 — 뒤에서부터, 광고주 자리는 제외
        for (var q=gIdx.length-1; q>=1; q--) {
            if (_isWorkerInitial(parts[gIdx[q]])) { workerIdx = gIdx[q]; break; }
        }
        // 2순위: 목록에 없어도 마지막 일반 토큰이 대문자 2~5자면 작업자로 간주
        //        (광고주/캠페인이 남는 경우에만 적용)
        if (workerIdx < 0 && gIdx.length >= 3) {
            var lastG = gIdx[gIdx.length-1];
            if (/^[A-Z]{2,5}$/.test(parts[lastG])) workerIdx = lastG;
        }
    }

    for (var j=0;j<parts.length;j++) {
        var p = parts[j];
        if (!p) continue;
        if (_isDate(p)) continue;
        if (_isRes(p))      { result.resolution = p.replace(/X/g, "x"); continue; }
        if (_isWorkType(p)) { result.workType = /^retuch\d+$/.test(p) ? "retuch1" : p; continue; }
        if (_isJobKind(p))  { result.jobKind = p; continue; }
        if (/^\d+p$/.test(p)) { result.page = p.replace(/p$/,""); continue; }
        if (j === workerIdx) continue; // skip worker
        generic.push(p);
    }

    if (generic.length>0) result.client   = generic[0];
    if (generic.length>1) result.campaign = generic[1];
    if (generic.length>2) result.task     = generic.slice(2).join("_");
    return result;
}

// ══════════════════════════════════════════════════════════════
// Public API
// ══════════════════════════════════════════════════════════════

$.global.brc_getFirstSelectedName = function() {
    var items = _getSelectedItems();
    return items.length ? _getName(items[0]) : "";
};

$.global.brc_parseCompName = function(name) {
    var r = _parseCompName(name);
    return JSON.stringify(r);
};

$.global.brc_applyField = function(field, value, oldVal) {
    var items = _getSelectedItems();
    if (!items.length || value==null || value==="") return;
    var fn;
    var label = "Apply " + field;
    if      (field==="date")       fn = _applyDate;
    else if (field==="resolution") fn = _applyRes;
    else if (field==="jobKind")    fn = function(n,v){ return _applyJobKind(n,_jobKindCode(v)); };
    else if (field==="workType")   fn = _applyWorkType;
    else if (field==="worker")     fn = _applyWorker;
    else if (field==="page")       fn = _applyPage;
    else if (field==="client")     fn = function(n,v){ return _applyGeneric(n,v,0); };
    else if (field==="campaign")   fn = function(n,v){ return _applyGeneric(n,v,1); };
    else if (field==="task")       fn = function(n,v){ return _applyTask(n,oldVal,v); };
    else return;
    _withUndo(label, function() {
        for (var i=0;i<items.length;i++) _setName(items[i], fn(_getName(items[i]), value));
    });
};

$.global.brc_renameAll = function(newName) {
    var items = _getSelectedItems();
    if (!items.length || !newName) return;
    _withUndo("Batch Rename", function() {
        if (items.length === 1) {
            _setName(items[0], newName);
            return;
        }
        // 다중 선택: 2단계 리네임으로 동일 이름 충돌 방지
        var stamp = (new Date()).getTime();
        for (var i=0;i<items.length;i++) _setName(items[i], "__brc_tmp_" + i + "_" + stamp);
        for (var k=0;k<items.length;k++) _setName(items[k], newName);
    });
};

$.global.brc_replaceText = function(from, to) {
    var items = _getSelectedItems();
    if (!items.length || !from) return;
    _withUndo("Replace Text", function() {
        for (var i=0;i<items.length;i++)
            _setName(items[i], String(_getName(items[i])).split(from).join(to));
    });
};

// Public API - Get top-most comp/sequence name in project (이름순 오름차순 첫 번째)
$.global.brc_getTopCompName = function() {
    try {
        var IS_PR = IS_PREMIERE;
        if (IS_PR) {
            // 프리미어: 모든 시퀀스 수집 후 이름순 정렬
            var seqNames = [];
            function collectSeq(parent) {
                for (var i = 0; i < parent.children.numItems; i++) {
                    var c = parent.children[i];
                    if (c.type === 2) {
                        collectSeq(c);
                    } else if (c.isSequence && c.isSequence()) {
                        seqNames.push(c.name);
                    }
                }
            }
            collectSeq(app.project.rootItem);
            if (!seqNames.length) return "";
            seqNames.sort();
            return seqNames[0];
        }
        // AE: 모든 CompItem 수집 후 이름순 정렬
        var names = [];
        var proj = app.project;
        for (var j = 1; j <= proj.numItems; j++) {
            var item = proj.item(j);
            if (item instanceof CompItem) names.push(item.name);
        }
        if (!names.length) return "";
        names.sort();
        return names[0];
    } catch(e) {
        return "";
    }
};

// Public API - Rename ALL comps/sequences in project
// 전체 이름변경 시: baseName(새 이름)을 기준으로 하되,
// oldName에 페이지(\d+p) / 작업구분(_isWorkType: xian/vari/sf/retuchN)이 있으면
// 그 기존 값을 유지하도록 baseName의 해당 토큰을 교체한다.
function _mergeKeepFields(baseName, oldName) {
    var baseParts = _smartSplit(baseName);
    var oldParts  = _smartSplit(oldName);

    // 기존 컴프의 페이지/작업구분 원본 토큰 추출
    var oldPage = null, oldWork = null;
    for (var i = 0; i < oldParts.length; i++) {
        var op = oldParts[i];
        if (oldPage === null && /^\d+p$/.test(op)) { oldPage = op; }
        if (oldWork === null && _isWorkType(op))   { oldWork = op; }
    }

    // baseName에서 페이지/작업구분 토큰을 기존 값으로 치환 (있을 때만)
    var hasBasePage = false, hasBaseWork = false;
    for (var j = 0; j < baseParts.length; j++) {
        if (/^\d+p$/.test(baseParts[j])) {
            hasBasePage = true;
            if (oldPage !== null) baseParts[j] = oldPage;
        }
        if (_isWorkType(baseParts[j])) {
            hasBaseWork = true;
            if (oldWork !== null) baseParts[j] = oldWork;
        }
    }

    // baseName에 페이지 토큰이 없는데 기존 페이지가 있으면 추가하지 않음
    // (구조 유지: 새 이름에 페이지 자리가 없으면 그대로 둠)
    // 단, 기존 작업구분이 있는데 baseName에 없으면 끝에 붙임 (작업구분은 항상 보존 우선)
    if (oldWork !== null && !hasBaseWork) {
        baseParts.push(oldWork);
    }

    return baseParts.join("_");
}

$.global.brc_renameAllInProject = function(newName) {
    try {
        if (!newName) return "error: no name";
        var IS_PR = IS_PREMIERE;
        var count = 0;

        if (IS_PR) {
            // 프리미어: 모든 시퀀스
            var prTargets = [];
            function collectSeq(parent) {
                for (var i = 0; i < parent.children.numItems; i++) {
                    var c = parent.children[i];
                    if (c.type === 2) {
                        collectSeq(c);
                    } else if (c.isSequence && c.isSequence()) {
                        prTargets.push(c);
                    }
                }
            }
            collectSeq(app.project.rootItem);
            // 각 시퀀스 최종 이름 계산
            var prFinal = [];
            for (var pf = 0; pf < prTargets.length; pf++) {
                prFinal.push(_mergeKeepFields(newName, prTargets[pf].name));
            }
            // 1단계: 임시 이름
            for (var pt = 0; pt < prTargets.length; pt++) {
                try { prTargets[pt].name = "__brc_tmp_" + pt + "_" + (new Date()).getTime(); } catch(_) {}
            }
            // 2단계: 계산된 최종 이름
            for (var pt2 = 0; pt2 < prTargets.length; pt2++) {
                try { prTargets[pt2].name = prFinal[pt2]; count++; } catch(_) {}
            }
            return "done:" + count;
        }

        // AE: 모든 CompItem
        var proj = app.project;
        app.beginUndoGroup("Rename All Comps");
        try {
            // 대상 컴프 수집 + 각 컴프의 최종 이름 계산 (페이지/작업구분 유지)
            var targets = [];
            var finalNames = [];
            for (var j = 1; j <= proj.numItems; j++) {
                var item = proj.item(j);
                if (item instanceof CompItem) {
                    targets.push(item);
                    finalNames.push(_mergeKeepFields(newName, item.name));
                }
            }
            // 1단계: 임시 고유 이름으로 변경 (동일 이름 충돌 회피)
            for (var t = 0; t < targets.length; t++) {
                try { targets[t].name = "__brc_tmp_" + t + "_" + (new Date()).getTime(); } catch(_) {}
            }
            // 2단계: 계산된 최종 이름으로 변경
            for (var t2 = 0; t2 < targets.length; t2++) {
                try { targets[t2].name = finalNames[t2]; count++; } catch(_) {}
            }
        } finally {
            app.endUndoGroup();
        }
        return "done:" + count;
    } catch(e) {
        return "error: " + e.toString();
    }
};

// Public API - 선택된 컴프(시퀀스)만 이름변경 (페이지/작업구분 유지)
$.global.brc_renameSelectedComps = function(newName) {
    try {
        if (!newName) return "error: no name";
        var IS_PR = IS_PREMIERE;
        var count = 0;

        var sel = _getSelectedItems();
        if (!sel || !sel.length) return "none"; // 선택된 게 없음

        if (IS_PR) {
            var prFinal = [];
            for (var pf = 0; pf < sel.length; pf++) {
                prFinal.push(_mergeKeepFields(newName, sel[pf].name));
            }
            for (var pt = 0; pt < sel.length; pt++) {
                try { sel[pt].name = "__brc_tmp_" + pt + "_" + (new Date()).getTime(); } catch(_) {}
            }
            for (var pt2 = 0; pt2 < sel.length; pt2++) {
                try { sel[pt2].name = prFinal[pt2]; count++; } catch(_) {}
            }
            return "done:" + count;
        }

        // AE
        app.beginUndoGroup("Rename Selected Comps");
        try {
            var finalNames = [];
            for (var s = 0; s < sel.length; s++) {
                finalNames.push(_mergeKeepFields(newName, sel[s].name));
            }
            for (var t = 0; t < sel.length; t++) {
                try { sel[t].name = "__brc_tmp_" + t + "_" + (new Date()).getTime(); } catch(_) {}
            }
            for (var t2 = 0; t2 < sel.length; t2++) {
                try { sel[t2].name = finalNames[t2]; count++; } catch(_) {}
            }
        } finally {
            app.endUndoGroup();
        }
        return "done:" + count;
    } catch(e) {
        return "error: " + e.toString();
    }
};



// Public API - Export Settings
$.global.brc_exportSettings = function(jsonStr) {
    try {
        var defaultFile = new File("BatchRenameComps_Settings.json");
        var saveFile = defaultFile.saveDlg("설정 내보내기");
        if (!saveFile) return "cancel";
        // 확장자 강제
        var path = saveFile.fsName;
        if (path.indexOf(".json") === -1) path += ".json";
        var f = new File(path);
        f.encoding = "UTF-8";
        f.open("w");
        f.write(jsonStr);
        f.close();
        return "done";
    } catch(e) {
        return "error: " + e.toString();
    }
};

// Public API - Import Settings
$.global.brc_importSettings = function() {
    try {
        // 파일선택 필터: Windows는 문자열 마스크, Mac은 콜백 함수 (openDlg 필터 규약이 OS별로 다름)
        var isWin = ($.os.indexOf("Windows") !== -1);
        var openFile;
        if (isWin) {
            openFile = File.openDialog("설정 가져오기", "JSON 설정 파일:*.json", false);
        } else {
            openFile = File.openDialog("설정 가져오기", function(f) {
                return (f instanceof Folder) || /\.json$/i.test(f.name);
            }, false);
        }
        if (!openFile) return "";
        openFile.encoding = "UTF-8";
        openFile.open("r");
        var content = openFile.read();
        openFile.close();
        return content;
    } catch(e) {
        return "error: " + e.toString();
    }
};
$.global.brc_browseFolder = function() {
    try {
        var isWindows = $.os.indexOf("Windows") !== -1;
        if (isWindows) {
            var defaultFile = new File("폴더를 선택하고 저장 버튼을 누르세요");
            var saveFile = defaultFile.saveDlg("임포트 폴더 선택");
            if (saveFile) return saveFile.parent.fsName;
            return "";
        } else {
            var folder = Folder.selectDialog("Select Import Folder");
            if (!folder) return "";
            return folder.fsName;
        }
    } catch(e) {
        return "";
    }
};

// Public API - Open a folder in OS file explorer
$.global.brc_openLocalFolder = function(folderPath) {
    try {
        if (!folderPath) return "error: no path";
        var f = new Folder(folderPath);
        if (!f.exists) return "error: not found";

        // Folder.execute()는 유니코드(한글) 경로를 정확히 처리하고
        // 해당 폴더를 OS 탐색기에서 엶
        var ok = f.execute();
        if (ok) return "done";

        // execute 실패 시 폴백: system.callSystem (영문 경로용)
        var isWindows = $.os.indexOf("Windows") !== -1;
        if (isWindows) {
            system.callSystem('explorer.exe "' + f.fsName + '"');
        } else {
            system.callSystem('open "' + f.fsName + '"');
        }
        return "done";
    } catch(e) {
        return "error: " + e.toString();
    }
};

// Public API - Import Folder (recursive)
$.global.brc_importFolder = function(folderPath) {
    try {
        if (IS_PREMIERE) return "error: premiere not supported";
        var proj = app.project;
        var srcFolder = new Folder(folderPath);
        if (!srcFolder.exists) return "error: folder not found";

        var validExt = {
            "aep":1,"aet":1,"ae":1,
            "psd":1,"psb":1,"ai":1,"eps":1,"pdf":1,
            "jpg":1,"jpeg":1,"png":1,"gif":1,"bmp":1,
            "tif":1,"tiff":1,"tga":1,"exr":1,"hdr":1,"dpx":1,"cin":1,
            "mp4":1,"mov":1,"avi":1,"mkv":1,"mxf":1,"r3d":1,"braw":1,
            "mp3":1,"wav":1,"aif":1,"aiff":1,"svg":1
        };

        // 대상 폴더 탐색: 02_Sc (루트 직속 또는 어디든)
        var destBase = null;
        for (var i = 1; i <= proj.numItems; i++) {
            var item = proj.item(i);
            if (!(item instanceof FolderItem)) continue;
            if (item.name === "02_Sc") {
                destBase = item; break;
            }
        }
        // 02_Sc 없으면 루트에 임포트 (destBase = null)

        // 재귀적으로 폴더 임포트
        function importFolderRecursive(srcDir, parentFolderItem) {
            // 한글 폴더명 URL 디코딩
            var folderName = _decodeName(srcDir.name);
            var destFolderItem = proj.items.addFolder(folderName);
            if (parentFolderItem) destFolderItem.parentFolder = parentFolderItem;

            var items = srcDir.getFiles();
            var importOpts = new ImportOptions();

            for (var j = 0; j < items.length; j++) {
                var f = items[j];
                if (f instanceof Folder) {
                    // 하위 폴더 재귀
                    importFolderRecursive(f, destFolderItem);
                } else if (f instanceof File) {
                    var ext = f.name.split(".").pop().toLowerCase();
                    if (!validExt[ext]) continue;
                    try {
                        importOpts.file = f;
                        var imported = proj.importFile(importOpts);
                        imported.parentFolder = destFolderItem;
                    } catch(e) {}
                }
            }
            return destFolderItem;
        }

        // 루트 임포트 위치 결정
        var rootDest = destBase || null;
        importFolderRecursive(srcFolder, rootDest);

        return "done";
    } catch(e) {
        return "error: " + e.toString();
    }
};

// Public API - Create AE Folder Tree from custom nodes JSON
$.global.brc_createAEFolderTreeFromNodes = function(nodesJson) {
    try {
        var nodes = null;
        try { nodes = JSON.parse(nodesJson); } catch(_) { return "error: invalid json"; }
        if (!nodes || !nodes.length) return "error: empty tree";

        var proj = app.project;
        var IS_PR = IS_PREMIERE;

        function getExt(filename) {
            return (filename.lastIndexOf(".") >= 0
                ? filename.substring(filename.lastIndexOf(".") + 1)
                : "").toLowerCase();
        }

        // 트리 노드에서 이름이 일치하는 실제 폴더 찾기 (대소문자 무시)
        function findFolderByName(targetName, parentFolder) {
            if (IS_PR) {
                var p = parentFolder || proj.rootItem;
                for (var i = 0; i < p.children.numItems; i++) {
                    var c = p.children[i];
                    if (c.type === 2 && c.name.toLowerCase() === targetName.toLowerCase()) return c;
                }
                return null;
            } else {
                var pf = parentFolder || proj.rootFolder;
                for (var i = 1; i <= proj.numItems; i++) {
                    var it = proj.item(i);
                    if (it instanceof FolderItem && it.parentFolder === pf
                        && it.name.toLowerCase() === targetName.toLowerCase()) return it;
                }
                return null;
            }
        }

        // 노드 경로(인덱스 배열)로 실제 폴더 찾기
        function resolveNodePath(nodePathNames) {
            var cur = null;
            for (var i = 0; i < nodePathNames.length; i++) {
                var found = findFolderByName(nodePathNames[i], cur);
                if (!found) return null;
                cur = found;
            }
            return cur;
        }

        // ── 확장자/태그 → 노드 경로(이름배열) 매핑 테이블 빌드 ──
        // 트리를 깊이우선 순회. 먼저 매핑된 폴더가 우선 (위에서부터)
        var extMap = {};   // "jpg" → ["02_Sc","Image","Rester"]
        var tagMap = {};   // "[comp]" → ["01_Comp","_Main"]
        function buildMap(arr, pathNames) {
            for (var i = 0; i < arr.length; i++) {
                var n = arr[i];
                var curPath = pathNames.concat(n.name);
                if (n.extensions && n.extensions.length) {
                    for (var e = 0; e < n.extensions.length; e++) {
                        var key = n.extensions[e];
                        if (key.charAt(0) === "[") {
                            if (!tagMap[key]) tagMap[key] = curPath;
                        } else {
                            if (!extMap[key]) extMap[key] = curPath;
                        }
                    }
                }
                if (n.children && n.children.length) buildMap(n.children, curPath);
            }
        }
        buildMap(nodes, []);

        // 아이템 → 목적지 폴더 (없으면 null)
        function getDestForExt(ext) {
            if (extMap[ext]) return resolveNodePath(extMap[ext]);
            return null;
        }
        function getDestForTag(tag) {
            if (tagMap[tag]) return resolveNodePath(tagMap[tag]);
            return null;
        }
        // 트리 nodes에서 특정 이름(대소문자 무시)의 노드를 찾아 경로 배열 반환 (없으면 null)
        function findNodePathByName(targetName) {
            var tnLower = String(targetName).toLowerCase();
            var result = null;
            function walk(arr, pathNames) {
                for (var i = 0; i < arr.length; i++) {
                    var n = arr[i];
                    var curPath = pathNames.concat(n.name);
                    if (String(n.name).toLowerCase() === tnLower) { result = curPath; return true; }
                    if (n.children && n.children.length) {
                        if (walk(n.children, curPath)) return true;
                    }
                }
                return false;
            }
            walk(nodes, []);
            return result;
        }
        // 이름으로 목적지 폴더(실제 AE FolderItem/Bin) 직접 반환 (트리에 그 이름 노드가 있어야 함)
        function getDestByNodeName(name) {
            var np = findNodePathByName(name);
            return np ? resolveNodePath(np) : null;
        }
        // Overlord / TweiNa 연동 폴더 판별 (대소문자 무시, 이름에 포함되면 true)
        // → 이미지 소스 연동 폴더라 구조를 유지하여 통째로 Image 로 옮긴다
        function _isSpecialName(name) {
            var l = String(name == null ? "" : name).toLowerCase();
            return (l.indexOf("overlord") !== -1 || l.indexOf("tweina") !== -1);
        }

        if (IS_PR) {
            // 프리미어 분기
            function mkBin(name, parent) {
                var p = parent || proj.rootItem;
                for (var i = 0; i < p.children.numItems; i++) {
                    var c = p.children[i];
                    if (c.name === name && c.type === 2) return c;
                }
                return p.createBin(name);
            }
            function recPR(arr, parent) {
                for (var i = 0; i < arr.length; i++) {
                    var n = arr[i];
                    var b = mkBin(n.name, parent);
                    if (n.children && n.children.length) recPR(n.children, b);
                }
            }
            recPR(nodes, null);

            var prItems = [];
            for (var i = 0; i < proj.rootItem.children.numItems; i++) {
                var ch = proj.rootItem.children[i];
                if (ch.type === 2) continue;
                prItems.push(ch);
            }
            var prStock = null;
            for (var pi = 0; pi < prItems.length; pi++) {
                var item = prItems[pi];
                var dest = null;
                if (item.isSequence && item.isSequence()) {
                    dest = getDestForTag("[comp]") || getDestForTag("[seq]");
                } else {
                    dest = getDestForExt(getExt(item.name));
                }
                if (!dest) {
                    if (!prStock) prStock = mkBin("Stock");
                    dest = prStock;
                }
                try { item.moveBin(dest); } catch(_) {}
            }
            return "done";
        }

        // AE 분기
        function mkFolder(name, parent) {
            var pf = parent || proj.rootFolder;
            for (var i = 1; i <= proj.numItems; i++) {
                var it = proj.item(i);
                if (it.name === name && it instanceof FolderItem && it.parentFolder === pf)
                    return it;
            }
            var f = proj.items.addFolder(name);
            if (parent) f.parentFolder = parent;
            return f;
        }
        function recAE(arr, parent) {
            for (var i = 0; i < arr.length; i++) {
                var n = arr[i];
                var f = mkFolder(n.name, parent);
                if (n.children && n.children.length) recAE(n.children, f);
            }
        }

        // 1) 기존 아이템 수집
        //    - 특수 폴더(Overlord/TweiNa)와 그 하위는 통째 이동 대상이므로 따로 모은다
        //    - 그 외 푸티지/컴프는 개별 분류 대상
        //    - 기존 폴더 목록은 나중에 빈 폴더 삭제용
        var allFootageComp = [];
        var existingFolders = [];
        var specialFolders = [];   // 최상위든 어디든, 이름에 overlord/tweina 든 FolderItem

        // 어떤 폴더가 특수 폴더이거나 그 자손인지 (parentFolder 체인을 거슬러 검사)
        function isUnderSpecial(item) {
            var cur = item;
            var guard = 0;
            while (cur && cur !== proj.rootFolder && guard < 100) {
                guard++;
                if ((cur instanceof FolderItem) && _isSpecialName(cur.name)) return true;
                cur = cur.parentFolder;
            }
            return false;
        }

        for (var j = 1; j <= proj.numItems; j++) {
            var it0 = proj.item(j);
            if (it0 instanceof FolderItem) {
                existingFolders.push(it0);
                if (_isSpecialName(it0.name)) specialFolders.push(it0);
            } else if ((it0 instanceof CompItem) || (it0 instanceof FootageItem)) {
                allFootageComp.push(it0);
            }
        }

        // 중첩된 특수 폴더는 가장 바깥 것만 옮기면 되므로, 다른 특수 폴더의 자손인 특수 폴더는 제외
        var topSpecialFolders = [];
        for (var sf = 0; sf < specialFolders.length; sf++) {
            var spf = specialFolders[sf];
            var nestedUnderOther = false;
            var cur = spf.parentFolder;
            var g2 = 0;
            while (cur && cur !== proj.rootFolder && g2 < 100) {
                g2++;
                if ((cur instanceof FolderItem) && _isSpecialName(cur.name)) { nestedUnderOther = true; break; }
                cur = cur.parentFolder;
            }
            if (!nestedUnderOther) topSpecialFolders.push(spf);
        }

        // 2) 새 폴더트리 생성
        recAE(nodes, null);

        // 새로 만든 트리의 최상위 폴더 이름 집합
        var newTreeNames = {};
        for (var tn = 0; tn < nodes.length; tn++) {
            newTreeNames[nodes[tn].name.toLowerCase()] = true;
        }

        // 3) 분류
        //  3-a) 특수 폴더(Overlord/TweiNa)는 구조 유지하여 통째로 Image 로 이동
        var imageDest = getDestByNodeName("Image");
        for (var spi = 0; spi < topSpecialFolders.length; spi++) {
            var moveFolder = topSpecialFolders[spi];
            if (imageDest) {
                try { moveFolder.parentFolder = imageDest; } catch(_) {}
            }
            // imageDest 가 없으면(트리에 Image 노드 없음) 폴더를 그대로 둔다 (구조 보존)
        }

        //  3-b) 나머지 푸티지/컴프 개별 분류
        //       (특수 폴더 자손은 위에서 통째 이동했으므로 제외)
        //       컴프 이름에 overlord/tweina 가 들어가면 Etc 로
        var aeStock = null;
        for (var k = 0; k < allFootageComp.length; k++) {
            var it = allFootageComp[k];
            if (isUnderSpecial(it)) continue; // 특수 폴더와 함께 이미 이동됨
            var dest = null;
            if (it instanceof CompItem) {
                if (_isSpecialName(it.name)) {
                    dest = getDestByNodeName("Etc");
                    if (!dest) dest = getDestForTag("[comp]"); // Etc 노드 없으면 일반 컴프 위치로 폴백
                } else {
                    dest = getDestForTag("[comp]");
                }
            } else if (it instanceof FootageItem) {
                if (it.mainSource && it.mainSource.file) {
                    dest = getDestForExt(getExt(it.mainSource.file.name));
                }
            }
            if (!dest) {
                if (!aeStock) aeStock = mkFolder("Stock");
                dest = aeStock;
            }
            try { it.parentFolder = dest; } catch(_) {}
        }

        // 4) 기존 폴더 중, 새 트리에 속하지 않고 비어있는 것 삭제
        //    (깊은 폴더부터 삭제해야 하므로 역순 처리 반복)
        function isInsideNewTree(folder) {
            // 최상위까지 거슬러 올라가며 새 트리 최상위 이름에 닿으면 true
            var cur = folder;
            var g = 0;
            while (cur && cur !== proj.rootFolder && g < 100) {
                g++;
                if (cur.parentFolder === proj.rootFolder) {
                    return !!newTreeNames[cur.name.toLowerCase()];
                }
                cur = cur.parentFolder;
            }
            return false;
        }
        // 여러 번 반복하여 안쪽 빈 폴더부터 정리
        var removedAny = true;
        var guard = 0;
        while (removedAny && guard < 20) {
            removedAny = false;
            guard++;
            for (var ef = existingFolders.length - 1; ef >= 0; ef--) {
                var fol = existingFolders[ef];
                if (!fol) continue;
                // 이미 삭제됐는지 체크
                var stillExists = false;
                try { stillExists = (fol.numItems >= 0); } catch(_) { stillExists = false; }
                if (!stillExists) { existingFolders[ef] = null; continue; }
                // Stock은 보존, 새 트리 폴더도 보존
                if (fol.name === "Stock") continue;
                if (isInsideNewTree(fol)) continue;
                // 특수 폴더(Overlord/TweiNa)와 그 자손은 구조 보존을 위해 비어 있어도 삭제하지 않음
                if (isUnderSpecial(fol)) continue;
                // 비어있으면 삭제
                if (fol.numItems === 0) {
                    try { fol.remove(); removedAny = true; } catch(_) {}
                    existingFolders[ef] = null;
                }
            }
        }
        return "done";
    } catch(e) {
        return "error: " + e.toString();
    }
};

// Public API - Import folder recursively + auto-classify into project folder tree
$.global.brc_importFolderAndClassify = function(folderPath, nodesJson, treePath, localNodesJson) {
    try {
        if (!folderPath) return "error: no folder path";
        var nodes = null;
        try { nodes = JSON.parse(nodesJson); } catch(_) { return "error: invalid json"; }
        if (!nodes || !nodes.length) return "error: empty tree";

        var srcFolder = new Folder(folderPath);
        if (!srcFolder.exists) return "error: folder not found";

        var proj = app.project;
        var IS_PR = IS_PREMIERE;

        if (IS_PR) {
            return "error: premiere not supported for import";
        }

        // 현재 프로젝트 기준 디스크 트리 루트
        // 작업파일이 트리 최상위 바로 안(parent) 또는 Ae 폴더 안(parent.parent)에 있을 수 있음.
        // 02_Sc 등 분류 대상 폴더가 실제로 있는 쪽을 트리 루트로 본다.
        var diskRoot = null;
        // 우선: 패널이 저장한 "마지막 생성 로컬 트리 경로"를 디스크 루트로 사용 (가장 신뢰도 높음)
        try {
            if (treePath) {
                var trf = new Folder(treePath);
                if (trf.exists) diskRoot = trf;
            }
        } catch(_) {}
        // 없으면: 현재 프로젝트 파일 위치로 추정
        try {
            if (!diskRoot && proj.file) {
                var p1 = proj.file.parent;
                if (p1 && p1.exists && _hasScFolder(p1)) {
                    diskRoot = p1;
                } else if (p1 && p1.parent && p1.parent.exists && _hasScFolder(p1.parent)) {
                    diskRoot = p1.parent;
                } else if (p1 && p1.exists) {
                    diskRoot = p1; // 기본: 한 단계 위
                }
            }
        } catch(_) {}

        function getExt(filename) {
            return (filename.lastIndexOf(".") >= 0
                ? filename.substring(filename.lastIndexOf(".") + 1)
                : "").toLowerCase();
        }
        function findFolderByName(targetName, parentFolder) {
            var pf = parentFolder || proj.rootFolder;
            for (var i = 1; i <= proj.numItems; i++) {
                var it = proj.item(i);
                if (it instanceof FolderItem && it.parentFolder === pf
                    && it.name.toLowerCase() === targetName.toLowerCase()) return it;
            }
            return null;
        }
        function resolveNodePath(nodePathNames) {
            var cur = null;
            for (var i = 0; i < nodePathNames.length; i++) {
                var found = findFolderByName(nodePathNames[i], cur);
                if (!found) return null;
                cur = found;
            }
            return cur;
        }
        // 확장자/태그 매핑 빌드
        var extMap = {};
        function buildMap(arr, pathNames) {
            for (var i = 0; i < arr.length; i++) {
                var n = arr[i];
                var curPath = pathNames.concat(n.name);
                if (n.extensions && n.extensions.length) {
                    for (var e = 0; e < n.extensions.length; e++) {
                        var key = n.extensions[e];
                        if (key.charAt(0) !== "[" && !extMap[key]) extMap[key] = curPath;
                    }
                }
                if (n.children && n.children.length) buildMap(n.children, curPath);
            }
        }
        buildMap(nodes, []);

        // AE 분류 경로 → 디스크 트리 대응 폴더
        // (숫자 접두사 무시 02_Sc↔05_Sc, 포함관계, 한 글자 오타 Rester↔Raster 흡수, 최하단까지만 매칭되면 그 폴더로 폴백)
        function _normSeg(s){ return String(s).toLowerCase().replace(/^[0-9]+[ _-]*/, "").replace(/[ _-]+/g, ""); }
        function _edit1(a, b){ if (a.length !== b.length || !a.length) return false; var d = 0; for (var i = 0; i < a.length; i++) { if (a.charAt(i) !== b.charAt(i)) { d++; if (d > 1) return false; } } return d === 1; }
        function resolveDiskFromAePath(aePath) {
            if (!diskRoot || !aePath || !aePath.length) return null;
            var cur = diskRoot, matched = 0;
            for (var i = 0; i < aePath.length; i++) {
                var target = _normSeg(aePath[i]);
                if (!target || target.charAt(0) === "[") continue;
                var subs = cur.getFiles(function(f){ return f instanceof Folder; });
                var found = null, contains = null, fuzzy = null;
                for (var j = 0; j < subs.length; j++) {
                    var dn = _normSeg(_decodeName(subs[j].name));
                    if (dn === target) { found = subs[j]; break; }
                    if (!contains && dn.length > 1 && (dn.indexOf(target) !== -1 || target.indexOf(dn) !== -1)) contains = subs[j];
                    if (!fuzzy && _edit1(dn, target)) fuzzy = subs[j];
                }
                found = found || contains || fuzzy;
                if (!found) break;
                cur = found; matched = i + 1;
            }
            return matched > 0 ? cur : null;
        }
        // 디스크 대상 파일 경로: 같은 이름이 있으면 그 경로를 그대로 반환(덮어쓰기)
        function diskTargetFile(folderPath, fullName) {
            return new File(folderPath + "/" + fullName);
        }

        // 이미 프로젝트에 같은 경로로 임포트된 FootageItem이 있으면 반환 (중복 방지)
        function findExistingFootage(fileObj) {
            try {
                var target = fileObj.fsName;
                for (var i = 1; i <= proj.numItems; i++) {
                    var it = proj.item(i);
                    if (it instanceof FootageItem && it.mainSource &&
                        it.mainSource.file) {
                        if (it.mainSource.file.fsName === target) return it;
                    }
                }
            } catch(_) {}
            return null;
        }

        // 폴더(하위 포함) 안 파일들의 대표 확장자 → 목적지 노드 경로 결정
        // 가장 많이 등장한 확장자의 nodePath를 반환 (없으면 null)
        // nodes 트리에서 특정 이름(대소문자 무시)의 노드를 찾아 그 경로 배열 반환
        function findNodePathByName(targetName) {
            var tnLower = String(targetName).toLowerCase();
            var result = null;
            function walk(arr, pathNames) {
                for (var i = 0; i < arr.length; i++) {
                    var n = arr[i];
                    var curPath = pathNames.concat(n.name);
                    if (String(n.name).toLowerCase() === tnLower) { result = curPath; return true; }
                    if (n.children && n.children.length) {
                        if (walk(n.children, curPath)) return true;
                    }
                }
                return false;
            }
            walk(nodes, []);
            return result;
        }

        function getFolderDestNodePath(folder) {
            var counts = {};
            function walk(d) {
                var es = d.getFiles();
                for (var i = 0; i < es.length; i++) {
                    if (es[i] instanceof Folder) { walk(es[i]); }
                    else if (es[i] instanceof File) {
                        var e = getExt(es[i].name);
                        if (extMap[e]) {
                            var key = extMap[e].join("/");
                            counts[key] = (counts[key] || 0) + 1;
                        }
                    }
                }
            }
            walk(folder);
            var bestKey = null, bestN = 0;
            for (var k in counts) {
                if (counts.hasOwnProperty(k) && counts[k] > bestN) { bestN = counts[k]; bestKey = k; }
            }
            if (!bestKey) return null;
            // key(문자열) → 노드경로 배열 복원
            return bestKey.split("/");
        }


        // 폴더 재귀 복사 (ExtendScript Folder엔 copy가 없으므로 직접 구현)
        function copyFolderRecursive(srcF, destF) {
            if (!destF.exists) destF.create();
            var es = srcF.getFiles();
            for (var i = 0; i < es.length; i++) {
                var e = es[i];
                var nm = _decodeName(e.name);
                if (e instanceof Folder) {
                    copyFolderRecursive(e, new Folder(destF.fsName + "/" + nm));
                } else if (e instanceof File) {
                    var df = new File(destF.fsName + "/" + nm);
                    if (df.exists) { try { df.remove(); } catch(_) {} } // 덮어쓰기
                    try { e.copy(df); } catch(_) {}
                }
            }
        }
        // 폴더 재귀 삭제
        function removeFolderRecursive(folder) {
            try {
                var es = folder.getFiles();
                for (var i = 0; i < es.length; i++) {
                    if (es[i] instanceof Folder) removeFolderRecursive(es[i]);
                    else { try { es[i].remove(); } catch(_) {} }
                }
                folder.remove();
            } catch(_) {}
        }
        // 폴더 통째 이동 (대상에 같은 이름 폴더 있으면 그 안으로 병합/덮어쓰기)
        function moveFolderInto(srcF, destParent) {
            var nm = _decodeName(srcF.name);
            var target = new Folder(destParent.fsName + "/" + nm);
            if (srcF.fsName === target.fsName) return target; // 이미 제자리
            // 자기 자신(또는 그 하위)으로의 이동 금지 - 재귀 복사로 폴더가 파괴되는 것 방지
            var sp = srcF.fsName, dp = destParent.fsName;
            if (dp.indexOf(sp) === 0 && (dp.length === sp.length ||
                dp.charAt(sp.length) === "/" || dp.charAt(sp.length) === "\\")) {
                return srcF;
            }
            copyFolderRecursive(srcF, target);
            removeFolderRecursive(srcF);
            return target;
        }

        function mkFolder(name, parent) {
            var pf = parent || proj.rootFolder;
            for (var i = 1; i <= proj.numItems; i++) {
                var it = proj.item(i);
                if (it.name === name && it instanceof FolderItem && it.parentFolder === pf)
                    return it;
            }
            var f = proj.items.addFolder(name);
            if (parent) f.parentFolder = parent;
            return f;
        }
        function recAE(arr, parent) {
            for (var i = 0; i < arr.length; i++) {
                var n = arr[i];
                var f = mkFolder(n.name, parent);
                if (n.children && n.children.length) recAE(n.children, f);
            }
        }

        // 임포트 가능 확장자
        var validExt = {
            aep:1,aet:1,
            psd:1,psb:1,ai:1,eps:1,pdf:1,svg:1,
            jpg:1,jpeg:1,png:1,gif:1,bmp:1,tif:1,tiff:1,tga:1,exr:1,hdr:1,dpx:1,cin:1,
            mp4:1,mov:1,avi:1,wmv:1,mkv:1,mxf:1,r3d:1,braw:1,m4v:1,m2v:1,webm:1,
            mp3:1,wma:1,wav:1,aif:1,aiff:1,m4a:1,flac:1,ogg:1,aac:1
        };

        app.beginUndoGroup("Import Folder & Classify");
        try {
            // 1) 폴더트리 생성
            recAE(nodes, null);

            // 2) 재귀로 모든 파일 임포트 (구조 무시, 평평하게)
            var aeStock = null;
            var importOpts = new ImportOptions();
            var imported = 0;

            // 단일 파일 처리: 디스크 분류 이동(덮어쓰기) + AE 임포트(중복방지) + 분류
            function handleLooseFile(f) {
                var ext = getExt(f.name);
                if (!validExt[ext]) return;
                try {
                    var nodePath = extMap[ext] || null;
                    var fileToImport = f;
                    if (diskRoot) {
                        // 디스크 목적지: AE 분류 경로를 디스크 트리에 이름 대응으로 매핑 (로컬 트리에 확장자 태그가 없어도 동작)
                        var diskDest = nodePath ? resolveDiskFromAePath(nodePath) : null;
                        if (diskDest && diskDest.exists) {
                            var moved = diskTargetFile(diskDest.fsName, _decodeName(f.name));
                            if (moved.fsName !== f.fsName) {
                                if (moved.exists) { try { moved.remove(); } catch(_) {} }
                                var ok = false;
                                try { ok = f.copy(moved); } catch(_) { ok = false; }
                                if (ok) { try { f.remove(); } catch(_) {} fileToImport = moved; }
                            } else { fileToImport = moved; }
                        }
                    }
                    var item = findExistingFootage(fileToImport);
                    if (!item) {
                        importOpts.file = fileToImport;
                        item = proj.importFile(importOpts);
                        imported++;
                    }
                    var dest = null;
                    if (nodePath) dest = resolveNodePath(nodePath);
                    if (!dest) { if (!aeStock) aeStock = mkFolder("Stock"); dest = aeStock; }
                    try { item.parentFolder = dest; } catch(_) {}
                } catch(_) {}
            }

            // 디스크 폴더(이동된 위치)를 AE에 구조 유지하여 임포트
            // aeParent 아래에 같은 이름의 FolderItem을 만들고 그 안에 재귀 임포트
            function importFolderTreeToAE(diskFolder, aeParent) {
                var folderName = _decodeName(diskFolder.name);
                var aeFolder = mkFolder(folderName, aeParent);
                var es = diskFolder.getFiles();
                for (var i = 0; i < es.length; i++) {
                    var e = es[i];
                    if (e instanceof Folder) {
                        importFolderTreeToAE(e, aeFolder);
                    } else if (e instanceof File) {
                        var ex = getExt(e.name);
                        if (!validExt[ex]) continue;
                        try {
                            var existing = findExistingFootage(e);
                            var it;
                            if (existing) { it = existing; }
                            else {
                                importOpts.file = e;
                                it = proj.importFile(importOpts);
                                imported++;
                            }
                            try { it.parentFolder = aeFolder; } catch(_) {}
                        } catch(_) {}
                    }
                }
                return aeFolder;
            }

            // 트리 구조 폴더 제자리 임포트: 디스크 구조를 노드 구조에 매핑해
            // 파일은 대응 AE 폴더로, 노드에 없는 폴더는 구조 유지로 그 아래에. 디스크 이동 없음.
            function importTreeFolderInPlace(diskFolder, nodeObj, aeFolder) {
                var es = diskFolder.getFiles();
                for (var i = 0; i < es.length; i++) {
                    var e = es[i];
                    if (e instanceof Folder) {
                        var nmLow = _decodeName(e.name).toLowerCase();
                        var kids = (nodeObj && nodeObj.children) ? nodeObj.children : [];
                        var childNode = null;
                        for (var c = 0; c < kids.length; c++) {
                            if (String(kids[c].name).toLowerCase() === nmLow) { childNode = kids[c]; break; }
                        }
                        if (childNode) {
                            importTreeFolderInPlace(e, childNode, mkFolder(childNode.name, aeFolder));
                        } else {
                            try { importFolderTreeToAE(e, aeFolder); } catch(_) {}
                        }
                    } else if (e instanceof File) {
                        var ex2 = getExt(e.name);
                        if (!validExt[ex2]) continue;
                        try {
                            var it2 = findExistingFootage(e);
                            if (!it2) {
                                importOpts.file = e;
                                it2 = proj.importFile(importOpts);
                                imported++;
                            }
                            try { it2.parentFolder = aeFolder; } catch(_) {}
                        } catch(_) {}
                    }
                }
            }

            // 최상위 항목 순회: 폴더는 통째로, 낱개 파일은 개별 분류
            var topEntries = srcFolder.getFiles();
            for (var t = 0; t < topEntries.length; t++) {
                var entry = topEntries[t];
                if (entry instanceof Folder) {
                    // _Master / _Ae / _Pr 로 끝나는 폴더는 제외
                    var enLower = _decodeName(entry.name).toLowerCase();
                    if (/_master$/.test(enLower) || /_ae$/.test(enLower) || /_pr$/.test(enLower)) {
                        continue;
                    }
                    // 트리 구조 폴더(최상위 노드와 같은 이름)는 분류/이동에서 제외하고
                    // 내용물만 대응 AE 폴더로 제자리 임포트 (빈 폴더도 그대로 보존)
                    var structNode = null;
                    for (var sn = 0; sn < nodes.length; sn++) {
                        if (String(nodes[sn].name).toLowerCase() === enLower) { structNode = nodes[sn]; break; }
                    }
                    if (structNode) {
                        try { importTreeFolderInPlace(entry, structNode, mkFolder(structNode.name, null)); } catch(_) {}
                        continue;
                    }
                    if (enLower === "stock") {
                        if (!aeStock) aeStock = mkFolder("Stock");
                        try { importTreeFolderInPlace(entry, { name: "Stock", children: [] }, aeStock); } catch(_) {}
                        continue;
                    }
                    // 폴더 대표 확장자로 목적지 결정
                    // 예외: Overlord / TweiNa PS Folder 는 구조 유지하여 무조건 _Sc/Image 로
                    // (폴더명에 해당 키워드가 포함되면 매칭 — 대소문자/공백 변형 대응)
                    var folderNodePath;
                    var rawName = _decodeName(entry.name);
                    var rawLower = rawName.toLowerCase();
                    if (rawLower.indexOf("overlord") !== -1 || rawLower.indexOf("tweina") !== -1) {
                        folderNodePath = findNodePathByName("Image");
                        if (!folderNodePath) folderNodePath = getFolderDestNodePath(entry);
                    } else {
                        folderNodePath = getFolderDestNodePath(entry);
                    }

                    // 디스크: AE 분류 경로(folderNodePath)를 디스크 트리에 매핑해 통째 이동 (없으면 제자리)
                    var movedFolder = entry;
                    if (diskRoot && folderNodePath) {
                        var diskDestParent = resolveDiskFromAePath(folderNodePath);
                        if (diskDestParent && diskDestParent.exists) {
                            try { movedFolder = moveFolderInto(entry, diskDestParent); } catch(_) {}
                        }
                    }

                    // AE: 폴더 구조 유지하여 임포트 (목적지 AE 노드 폴더 아래에)
                    var aeParent = folderNodePath ? resolveNodePath(folderNodePath) : null;
                    if (!aeParent) { if (!aeStock) aeStock = mkFolder("Stock"); aeParent = aeStock; }
                    try { importFolderTreeToAE(movedFolder, aeParent); } catch(_) {}

                } else if (entry instanceof File) {
                    handleLooseFile(entry);
                }
            }
        } finally {
            app.endUndoGroup();
        }
        return "done:" + imported;
    } catch(e) {
        return "error: " + e.toString();
    }
};

// Public API - Create Local Folder Tree from custom nodes JSON
$.global.brc_createLocalTreeFromNodes = function(basePath, topName, nodesJson) {
    try {
        if (!basePath || !topName) return "error: missing path or name";
        var nodes = null;
        try { nodes = JSON.parse(nodesJson); } catch(_) { return "error: invalid json"; }
        if (!nodes) return "error: empty tree";

        var baseFolder = new Folder(basePath);
        if (!baseFolder.exists) return "error: base path not found";

        function mk(path) {
            var f = new Folder(path);
            if (!f.exists) f.create();
            return f;
        }
        var rootPath = basePath + "/" + topName;
        var rootFolderObj = mk(rootPath);
        function rec(arr, parentPath) {
            for (var i = 0; i < arr.length; i++) {
                var n = arr[i];
                var p = parentPath + "/" + n.name;
                mk(p);
                if (n.children && n.children.length) rec(n.children, p);
            }
        }
        rec(nodes, rootPath);

        // ── 현재 프로젝트 자동 저장 ──
        // AE 실행: aep를 폴더명에 "Ae" 포함된 폴더에
        // Premiere 실행: prproj를 폴더명에 "Pr" 포함된 폴더에
        var IS_PR = IS_PREMIERE;
        var saveTag = IS_PR ? "pr" : "ae";

        // 중복 시 _1, _2 ... 증가하는 파일 객체 생성
        function uniqueFile(folderPath, baseName, ext) {
            var candidate = new File(folderPath + "/" + baseName + "." + ext);
            if (!candidate.exists) return candidate;
            var idx = 1;
            while (true) {
                var c = new File(folderPath + "/" + baseName + "_" + idx + "." + ext);
                if (!c.exists) return c;
                idx++;
                if (idx > 999) return c; // 안전장치
            }
        }

        // 트리 노드에서 saveTag 포함 폴더의 실제 경로 찾기 (깊이우선 첫 매칭)
        // 매칭 우선순위: "_ae"/"_pr"로 끝남 > 정확히 "ae"/"pr" > 이름에 포함
        var targetFolderPath = null;
        function matchScore(name) {
            var lower = name.toLowerCase();
            if (lower === saveTag) return 3;
            // _ae, _pr 또는 -ae 등 구분자 뒤에 오는 경우
            var re = new RegExp("[_\\- ]" + saveTag + "$");
            if (re.test(lower)) return 3;
            // 끝이 ae/pr (예: 03ae)
            if (lower.length >= 2 && lower.substring(lower.length - 2) === saveTag
                && /\d/.test(lower.charAt(lower.length - 3) || "")) return 2;
            return 0;
        }
        var bestScore = 0;
        function findTagFolder(arr, parentPath) {
            for (var i = 0; i < arr.length; i++) {
                var n = arr[i];
                var p = parentPath + "/" + n.name;
                var s = matchScore(n.name);
                if (s > bestScore) {
                    bestScore = s;
                    targetFolderPath = p;
                }
                if (n.children && n.children.length) findTagFolder(n.children, p);
            }
        }
        findTagFolder(nodes, rootPath);

        var savedPath = "";
        if (targetFolderPath) {
            try {
                if (IS_PR) {
                    // 프리미어: 현재 프로젝트를 다른 이름으로 저장
                    var prFile = uniqueFile(targetFolderPath, topName, "prproj");
                    if (prFile && app.project) {
                        app.project.saveAs(prFile.fsName);
                        savedPath = prFile.fsName;
                    }
                } else {
                    // AE: 현재 프로젝트를 다른 이름으로 저장
                    var aeFile = uniqueFile(targetFolderPath, topName, "aep");
                    if (aeFile && app.project) {
                        app.project.save(aeFile);
                        savedPath = aeFile.fsName;
                    }
                }
            } catch(saveErr) {
                // 저장 실패해도 폴더 생성은 성공으로 처리
            }
        }

        // 중복 시 _1, _2 ... 증가하는 파일 객체 생성 (위에서 정의됨)

        // fsName: OS 정규 경로 (한글 경로 열기에 안전)
        return "done:" + rootFolderObj.fsName + (savedPath ? ("|saved:" + savedPath) : "");
    } catch(e) {
        return "error: " + e.toString();
    }
};

// Public API - 현재 프로젝트의 기본 저장 이름 (확장자 없이)
$.global.brc_getProjectBaseName = function() {
    try {
        var IS_PR = IS_PREMIERE;
        var name = "";
        if (IS_PR) {
            if (app.project && app.project.name) name = app.project.name;
        } else {
            if (app.project && app.project.file) {
                name = app.project.file.name;
            } else if (app.project && app.project.name) {
                name = app.project.name;
            }
        }
        if (!name) return "";
        // File.name은 한글을 URL 인코딩(%EC..)으로 반환하므로 디코딩
        name = _decodeName(name);
        // 확장자 제거
        name = name.replace(/\.(aep|aet|prproj)$/i, "");
        return name;
    } catch(e) {
        return "";
    }
};

// Public API - 지정한 트리 경로의 Ae/Pr 폴더에 다른 이름으로 저장
// baseTreePath: 마지막 생성 로컬 폴더트리 루트 경로 (디스크)
// saveName: 저장할 파일 이름 (확장자 없이)
$.global.brc_saveProjectToTree = function(baseTreePath, saveName) {
    try {
        if (!saveName) return "error: no name";
        var IS_PR = IS_PREMIERE;
        var saveTag = IS_PR ? "pr" : "ae";
        var ext = IS_PR ? "prproj" : "aep";

        // 트리 루트 결정:
        // 1순위) 현재 열린 프로젝트 파일 기준. 작업파일이
        //        트리 최상위 바로 안(parent)에 있거나 Ae/Pr 폴더 안(parent.parent)에 있을 수 있음.
        //        해당 위치에 Ae/Pr 폴더가 실제로 있는 쪽을 트리 루트로 본다.
        // 2순위) 넘어온 baseTreePath (마지막 생성 트리)
        var rootF = null;
        try {
            if (app.project && app.project.file) {
                var p1 = app.project.file.parent;       // 한 단계 위
                if (p1 && p1.exists && _hasTagFolder(p1, saveTag)) {
                    rootF = p1;
                } else if (p1 && p1.parent && p1.parent.exists && _hasTagFolder(p1.parent, saveTag)) {
                    rootF = p1.parent;                  // 두 단계 위
                } else if (p1 && p1.exists) {
                    rootF = p1;                          // 태그 폴더 못 찾으면 한 단계 위를 기본
                }
            }
        } catch(_) {}
        if (!rootF || !rootF.exists) {
            if (!baseTreePath) return "error: no tree path";
            rootF = new Folder(baseTreePath);
        }
        if (!rootF.exists) return "error: tree not found";

        // 트리 루트 안에서 Ae/Pr 폴더 찾기 (이름에 태그 포함, _ae/_pr 우선)
        function scoreName(nm) {
            var lower = nm.toLowerCase();
            if (lower === saveTag) return 3;
            var re = new RegExp("[_\\- ]" + saveTag + "$");
            if (re.test(lower)) return 3;
            if (lower.length >= 2 && lower.substring(lower.length-2) === saveTag) return 2;
            if (lower.indexOf(saveTag) !== -1) return 1;
            return 0;
        }
        var subs = rootF.getFiles(function(f){ return f instanceof Folder; });
        var best = null, bestScore = 0;
        for (var i = 0; i < subs.length; i++) {
            var s = scoreName(_decodeName(subs[i].name));
            if (s > bestScore) { bestScore = s; best = subs[i]; }
        }
        var targetFolder = best || rootF;

        // 중복 시 _1, _2 ...
        function uniqueFile(folderPath, baseName, e) {
            var c = new File(folderPath + "/" + baseName + "." + e);
            if (!c.exists) return c;
            var idx = 1;
            while (true) {
                var c2 = new File(folderPath + "/" + baseName + "_" + idx + "." + e);
                if (!c2.exists) return c2;
                idx++;
                if (idx > 999) return c2;
            }
        }
        var outFile = uniqueFile(targetFolder.fsName, saveName, ext);

        if (IS_PR) {
            if (app.project) { app.project.saveAs(outFile.fsName); }
        } else {
            if (app.project) { app.project.save(outFile); }
        }
        return "done:" + outFile.fsName;
    } catch(e) {
        return "error: " + e.toString();
    }
};

// Public API - 프로젝트 파일 열기
$.global.brc_openProjectFile = function(filePath) {
    try {
        if (!filePath) return "error: no path";
        var f = new File(filePath);
        if (!f.exists) return "error: not found";
        var IS_PR = IS_PREMIERE;
        if (IS_PR) {
            app.openDocument(f.fsName);
        } else {
            app.open(f);
        }
        return "done";
    } catch(e) {
        return "error: " + e.toString();
    }
};

// Public API - 렌더 대상 계획 조회: 선택된 컴프 수 / 전체 컴프 수
// (패널이 렌더 전 '전체 렌더' 확인창을 띄울지 판단)
$.global.brc_getRenderPlan = function() {
    try {
        if (IS_PREMIERE) return '{"sel":0,"total":0,"pr":1}';
        var proj = app.project;
        if (!proj) return '{"sel":0,"total":0}';
        var selN = 0, totalN = 0;
        var sel = proj.selection;
        if (sel && sel.length) {
            for (var si = 0; si < sel.length; si++) {
                if (sel[si] instanceof CompItem) selN++;
            }
        }
        for (var pi = 1; pi <= proj.numItems; pi++) {
            if (proj.item(pi) instanceof CompItem) totalN++;
        }
        return '{"sel":' + selN + ',"total":' + totalN + '}';
    } catch(e) {
        return '{"sel":0,"total":0,"err":1}';
    }
};

// Public API - 선택 컴프(없으면 전체)를 렌더 큐에 추가, 출력경로=트리의 _master 폴더
// baseTreePath: 마지막 생성 로컬 폴더트리 루트, autoRender: "1"이면 즉시 렌더 시작
$.global.brc_renderComps = function(baseTreePath, autoRender) {
    try {
        var IS_PR = IS_PREMIERE;
        if (IS_PR) return "error: premiere not supported";

        var proj = app.project;
        if (!proj) return "error: no project";

        var doAuto = (autoRender === "1" || autoRender === 1 || autoRender === true);

        // _master 폴더 찾기
        function scoreName(nm) {
            var lower = nm.toLowerCase();
            if (lower === "master") return 3;
            var re = /[_\- ]master$/;
            if (re.test(lower)) return 3;
            if (lower.indexOf("master") !== -1) return 1;
            return 0;
        }
        function findMasterIn(parentFolder) {
            if (!parentFolder || !parentFolder.exists) return null;
            var subs = parentFolder.getFiles(function(f){ return f instanceof Folder; });
            var best = null, bestScore = 0;
            for (var i = 0; i < subs.length; i++) {
                var nm = subs[i].name;
                nm = _decodeName(nm);
                var s = scoreName(nm);
                if (s > bestScore) { bestScore = s; best = subs[i]; }
            }
            return best;
        }

        var masterFolder = null;
        // 현재 프로젝트 파일이 있으면 "프로젝트 기준"을 항상 우선한다.
        // (마지막 만든 폴더 baseTreePath보다 우선)
        var projParent = null;
        if (proj.file) {
            try {
                var p1 = proj.file.parent;            // 한 단계 위
                projParent = p1;
                // 1) 한 단계 위에서 _master 찾기
                if (p1) masterFolder = findMasterIn(p1);
                // 2) 두 단계 위에서 _master 찾기
                if (!masterFolder && p1 && p1.parent) {
                    masterFolder = findMasterIn(p1.parent);
                }
                // 3) 둘 다 없으면 프로젝트 폴더에 00_Master 새로 생성
                if (!masterFolder && p1 && p1.exists) {
                    var newMaster = new Folder(p1.fsName + "/00_Master");
                    try {
                        if (!newMaster.exists) newMaster.create();
                        if (newMaster.exists) masterFolder = newMaster;
                    } catch(_) {}
                }
            } catch(_) {}
        }
        // 최후 폴백: 프로젝트가 저장 안 된 경우에만 baseTreePath(마지막 만든 폴더) 사용
        if (!masterFolder && baseTreePath) {
            masterFolder = findMasterIn(new Folder(baseTreePath));
        }
        if (masterFolder && !masterFolder.exists) {
            try { masterFolder.create(); } catch(_) {}
        }

        // 렌더 대상 컴프 수집: 선택된 컴프 우선, 없으면 전체
        var comps = [];
        var sel = proj.selection;
        if (sel && sel.length) {
            for (var si = 0; si < sel.length; si++) {
                if (sel[si] instanceof CompItem) comps.push(sel[si]);
            }
        }
        if (!comps.length) {
            for (var pi = 1; pi <= proj.numItems; pi++) {
                var it = proj.item(pi);
                if (it instanceof CompItem) comps.push(it);
            }
        }
        if (!comps.length) return "error: no comps";

        var rq = proj.renderQueue;

        // ── 모드 분기 ──
        if (!doAuto) {
            // [자동 출력 OFF] 큐에 추가만 (출력 경로 미설정)
            var addedCount = 0;
            for (var ci = 0; ci < comps.length; ci++) {
                try { rq.items.add(comps[ci]); addedCount++; } catch(_) {}
            }
            if (addedCount === 0) return "error: nothing added";
            return "queued:" + addedCount;
        }

        // [자동 출력 ON] 영문 임시 폴더로 렌더 → 완료 후 _master로 이동
        if (!masterFolder || !masterFolder.exists) {
            return "error: no master folder";
        }

        // ASCII 임시 폴더 확보 (om.file이 멀티바이트 경로를 깨뜨리므로,
        // 사용자명이 한글이어도 안전하도록 순수 ASCII 경로를 찾는다)
        var tempRoot = _getAsciiTempRoot();
        if (!tempRoot || !tempRoot.exists) {
            return "error: no temp folder";
        }
        // 임시 루트 경로에 한글이 섞이면 om.file이 깨지므로 사용자에게 알림
        if (!_isAsciiPath(tempRoot.fsName)) {
            return "error: temp path not ascii - " + tempRoot.fsName;
        }
        var stamp = "" + (new Date()).getTime();
        var tempFolder = new Folder(tempRoot.fsName + "/r" + stamp);
        if (!tempFolder.exists) tempFolder.create();

        // 기존 렌더 큐 항목들은 렌더 대상에서 제외 (render 플래그 off)
        // (완료/대기 항목도 끌 수 있어 remove보다 안전)
        try {
            for (var rqi = 1; rqi <= rq.numItems; rqi++) {
                try { rq.item(rqi).render = false; } catch(_) {}
            }
        } catch(_) {}

        // 렌더 큐에 추가 + 임시 경로로 출력 설정 (임시 폴더는 영문이라 om.file 정상)
        var jobs = [];
        for (var c2 = 0; c2 < comps.length; c2++) {
            var comp = comps[c2];
            try {
                var rqItem = rq.items.add(comp);
                rqItem.render = true; // 새로 추가한 항목만 렌더 대상
                var om = rqItem.outputModule(1);
                // 끝에 "_" 구분자를 둬 render_1 이 render_10 의 접두사가 되는 충돌 방지
                // (동영상: render_0_.mov / 시퀀스: render_0_00000.png — 둘 다 "render_0_"로 시작)
                var tempName = "render_" + c2 + "_";
                om.file = new File(tempFolder.fsName + "/" + tempName);
                jobs.push({ jobIndex: c2, tempBase: tempName, compName: comp.name });
            } catch(_) {}
        }
        if (!jobs.length) { try { tempFolder.remove(); } catch(_){} return "error: nothing added"; }

        // 렌더 실행 (완료까지 블록)
        try {
            rq.render();
        } catch(rerr) {
            return "error: render failed - " + rerr.toString();
        }

        // 렌더 결과 파일을 _master로 이동
        var moved = 0;
        var produced = tempFolder.getFiles();
        for (var p = 0; p < produced.length; p++) {
            var pf = produced[p];
            if (!(pf instanceof File)) continue;
            var pfName = pf.name;
            pfName = _decodeName(pfName);
            // 파일명 앞부분의 "render_<숫자>_" 를 정확히 추출 (render_1_ 과 render_10_ 을 혼동하지 않음)
            var idxMatch = pfName.match(/^render_(\d+)_/);
            if (!idxMatch) continue;
            var jobIdx = parseInt(idxMatch[1], 10);
            for (var j = 0; j < jobs.length; j++) {
                if (jobs[j].jobIndex === jobIdx) {
                    var ext = "";
                    var dot = pfName.lastIndexOf(".");
                    if (dot >= 0) ext = pfName.substring(dot);
                    var destName = jobs[j].compName + ext;
                    var destFile = new File(masterFolder.fsName + "/" + destName);
                    if (destFile.exists) {
                        var idx = 1;
                        while (true) {
                            var alt = new File(masterFolder.fsName + "/" + jobs[j].compName + "_" + idx + ext);
                            if (!alt.exists) { destFile = alt; break; }
                            idx++;
                            if (idx > 999) break;
                        }
                    }
                    try {
                        if (pf.copy(destFile)) { moved++; }
                    } catch(_) {}
                    break;
                }
            }
        }

        // 임시 폴더 정리
        try {
            var leftover = tempFolder.getFiles();
            for (var lf = 0; lf < leftover.length; lf++) {
                try { leftover[lf].remove(); } catch(_) {}
            }
            tempFolder.remove();
        } catch(_) {}

        // _master 폴더 열기
        try { masterFolder.execute(); } catch(_) {}

        return "rendered:" + moved;
    } catch(e) {
        return "error: " + e.toString();
    }
};

// Public API - 트리의 _master 폴더를 탐색기로 열기
$.global.brc_openMasterFolder = function(baseTreePath) {
    try {
        function scoreName(nm) {
            var lower = nm.toLowerCase();
            if (lower === "master") return 3;
            var re = /[_\- ]master$/;
            if (re.test(lower)) return 3;
            if (lower.indexOf("master") !== -1) return 1;
            return 0;
        }
        function findMasterIn(parentFolder) {
            if (!parentFolder || !parentFolder.exists) return null;
            var subs = parentFolder.getFiles(function(f){ return f instanceof Folder; });
            var best = null, bestScore = 0;
            for (var i = 0; i < subs.length; i++) {
                var s = scoreName(_decodeName(subs[i].name));
                if (s > bestScore) { bestScore = s; best = subs[i]; }
            }
            return best;
        }

        // 1순위: 현재 프로젝트 파일 기준 (한 단계 위, 두 단계 위 둘 다 시도)
        var master = null;
        try {
            if (app.project && app.project.file) {
                var p1 = app.project.file.parent;
                if (p1) master = findMasterIn(p1);
                if (!master && p1 && p1.parent) master = findMasterIn(p1.parent);
            }
        } catch(_) {}

        // 2순위: baseTreePath 기준
        if (!master && baseTreePath) {
            var rootF = new Folder(baseTreePath);
            if (rootF.exists) master = findMasterIn(rootF) || rootF;
        }

        if (!master || !master.exists) return "error: no master folder";
        master.execute();
        return "done";
    } catch(e) {
        return "error: " + e.toString();
    }
};

// 좌클릭 폴더트리: 프로젝트 내 분류된 footage 파일을 로컬 디스크 트리로 복사 (AE 전용)
$.global.brc_copyProjectFootageToDisk = function(diskTreePath) {
    try {
        var proj = app.project;
        if (!proj) return "error: no project";
        var diskRoot = new Folder(diskTreePath);
        if (!diskRoot.exists) return "error: tree not found";

        function _normSeg(s){ return String(s).toLowerCase().replace(/^[0-9]+[ _-]*/, "").replace(/[ _-]+/g, ""); }
        function _edit1(a, b){ if (a.length !== b.length || !a.length) return false; var d = 0; for (var i = 0; i < a.length; i++) { if (a.charAt(i) !== b.charAt(i)) { d++; if (d > 1) return false; } } return d === 1; }
        function resolveDiskFromAePath(aePath) {
            if (!aePath || !aePath.length) return null;
            var cur = diskRoot, matched = 0;
            for (var i = 0; i < aePath.length; i++) {
                var target = _normSeg(aePath[i]);
                if (!target || target.charAt(0) === "[") continue;
                var subs = cur.getFiles(function(f){ return f instanceof Folder; });
                var found = null, contains = null, fuzzy = null;
                for (var j = 0; j < subs.length; j++) {
                    var dn = _normSeg(_decodeName(subs[j].name));
                    if (dn === target) { found = subs[j]; break; }
                    if (!contains && dn.length > 1 && (dn.indexOf(target) !== -1 || target.indexOf(dn) !== -1)) contains = subs[j];
                    if (!fuzzy && _edit1(dn, target)) fuzzy = subs[j];
                }
                found = found || contains || fuzzy;
                if (!found) break;
                cur = found; matched = i + 1;
            }
            return matched > 0 ? cur : null;
        }
        function aeBinPath(item) {
            var names = [], cur = item.parentFolder, guard = 0;
            while (cur && cur !== proj.rootFolder && guard < 50) { names.unshift(_decodeName(cur.name)); cur = cur.parentFolder; guard++; }
            return names;
        }

        // ── 프리미어 분기: rootItem 하위 빈(bin) 구조를 따라가며 소스를 디스크 트리로 복사 ──
        if (IS_PREMIERE) {
            var prCopied = 0, prSkipped = 0;
            // getMediaPath()가 돌려주는 경로를 File 객체로 (역슬래시/인코딩 변형까지 시도)
            var _prSrcFile = function(p) {
                if (!p) return null;
                var cands = [String(p), String(p).replace(/\\/g, "/"), _decodeName(p)];
                for (var ci = 0; ci < cands.length; ci++) {
                    var f = null;
                    try { f = new File(cands[ci]); } catch(_) { f = null; }
                    if (f && f.exists) return f;
                }
                return null;
            };
            var _walkPR = function(bin, binPath) {
                var kids = null;
                try { kids = bin.children; } catch(_) { return; }
                if (!kids) return;
                for (var i = 0; i < kids.numItems; i++) {
                    var c = kids[i];
                    var ty = 0; try { ty = c.type; } catch(_) { ty = 0; }
                    if (ty === 2) { // BIN
                        var bn = ""; try { bn = _decodeName(c.name); } catch(_) { bn = ""; }
                        _walkPR(c, binPath.concat([bn]));
                        continue;
                    }
                    try { if (c.isSequence && c.isSequence()) continue; } catch(_) {}
                    var mp = ""; try { mp = c.getMediaPath(); } catch(_) { mp = ""; }
                    var srcFile = _prSrcFile(mp);
                    if (!srcFile) { prSkipped++; continue; }
                    var destFolder = resolveDiskFromAePath(binPath);
                    if (!destFolder || !destFolder.exists) { prSkipped++; continue; }
                    var destFile = new File(destFolder.fsName + "/" + _decodeName(srcFile.name));
                    if (destFile.fsName === srcFile.fsName) { prSkipped++; continue; }
                    var ok = true;
                    if (!destFile.exists) { ok = false; try { ok = srcFile.copy(destFile); } catch(_) { ok = false; } }
                    if (!ok) { prSkipped++; continue; }
                    prCopied++;
                    // 복사본으로 재링크 (지원되는 버전에서만)
                    try {
                        if (c.canChangeMediaPath && c.canChangeMediaPath(destFile.fsName)) c.changeMediaPath(destFile.fsName);
                    } catch(_) {}
                }
            };
            try { _walkPR(proj.rootItem, []); } catch(e) { return "error: " + e.toString(); }
            return "done:copied=" + prCopied + ",skipped=" + prSkipped;
        }

        var items = [];
        for (var i = 1; i <= proj.numItems; i++) {
            var it = proj.item(i);
            if (it instanceof FootageItem && it.mainSource && (it.mainSource instanceof FileSource) && it.file) items.push(it);
        }

        var copied = 0, skipped = 0;
        app.beginUndoGroup("Copy footage to local tree");
        for (var k = 0; k < items.length; k++) {
            var ft = items[k];
            try {
                var srcFile = ft.file;
                if (!srcFile || !srcFile.exists) { skipped++; continue; }
                var destFolder = resolveDiskFromAePath(aeBinPath(ft));
                if (!destFolder || !destFolder.exists) { skipped++; continue; }
                var destFile = new File(destFolder.fsName + "/" + _decodeName(srcFile.name));
                if (destFile.fsName === srcFile.fsName) { skipped++; continue; }
                var ok = true;
                if (!destFile.exists) { ok = false; try { ok = srcFile.copy(destFile); } catch(_) { ok = false; } }
                if (!ok) { skipped++; continue; }
                copied++;
                try { ft.replace(destFile); } catch(_) {}
            } catch(_) { skipped++; }
        }
        app.endUndoGroup();
        return "done:copied=" + copied + ",skipped=" + skipped;
    } catch(e) { return "error: " + e.toString(); }
};

// Public API - 네이티브 한글 입력창 (현재 패널에서 호출하지 않음)
// 동작 검증 완료. UI 일관성 때문에 배선만 보류한 상태다. main.js 하단 참고.
// CEP 패널은 한글 인라인 조합이 깨진다. 조합 문자열이 페이지까지 오지 않고
// (composition 이벤트 0건, 실측) 확정된 글자만 도착하며, 조합은 화면 좌상단
// OS 기본 창에서 일어난다. Adobe CEP-3029. CSS/DOM 으로는 손댈 수 없다.
// ScriptUI 는 호스트 앱 네이티브 위젯이라 조합이 정상이므로 텍스트 입력만 넘겨받는다.
//
// specJson: {"title":"...", "fields":[{"id":"client","label":"광고주명","value":"기존값"}, ...]}
// 반환    : {"ok":1,"values":[{"id":"client","value":"입력값"}, ...]}
//           {"ok":0}  = 사용자가 취소   /  ""  = 오류 (패널이 HTML 창으로 폴백)
$.global.brc_promptKo = function(specJson) {
    try {
        var spec;
        try { spec = JSON.parse(specJson); } catch(_) { return ""; }
        if (!spec || !spec.fields || !spec.fields.length) return "";

        var w = new Window("dialog", spec.title || "입력");
        w.orientation = "column";
        w.alignChildren = ["fill", "top"];
        w.margins = 14;
        w.spacing = 8;

        var boxes = [], i, f, row, lb, et;
        for (i = 0; i < spec.fields.length; i++) {
            f = spec.fields[i];
            row = w.add("group");
            row.orientation = "row";
            row.alignChildren = ["left", "center"];
            if (f.label) {
                lb = row.add("statictext", undefined, String(f.label));
                lb.preferredSize.width = 76;
            }
            et = row.add("edittext", undefined, String(f.value === undefined ? "" : f.value));
            et.characters = 30;
            boxes.push(et);
        }

        var g = w.add("group");
        g.alignment = "right";
        g.add("button", undefined, "확인", { name: "ok" });
        g.add("button", undefined, "취소", { name: "cancel" });

        boxes[0].active = true;
        if (w.show() !== 1) return '{"ok":0}';

        var out = [];
        for (i = 0; i < boxes.length; i++) {
            out.push({ id: spec.fields[i].id, value: boxes[i].text });
        }
        return '{"ok":1,"values":' + JSON.stringify(out) + '}';
    } catch(e) {
        return "";
    }
};

"BatchRenameComps hostscript loaded";
