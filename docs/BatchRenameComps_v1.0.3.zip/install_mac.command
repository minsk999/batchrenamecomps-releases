#!/bin/bash
cd "$(dirname "$0")"

echo ""
echo "  ============================================"
echo "   BatchRenameComps 설치 (After Effects / Premiere Pro)"
echo "  ============================================"
echo ""

SRC="$(pwd)/com.batchrenamecomps"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/com.batchrenamecomps"

hold() {
    echo ""
    read -n 1 -s -r -p "  아무 키나 누르면 닫혀요..."
    echo ""
}

if [ ! -f "$SRC/CSXS/manifest.xml" ]; then
    echo "  [오류] 이 파일 옆에서 com.batchrenamecomps 폴더를 찾을 수 없어요."
    echo "  압축을 통째로 푼 뒤, 그 폴더 안에서 이 파일을 실행해 주세요."
    hold
    exit 1
fi

# Adobe 앱이 켜져 있으면 확장 폴더를 붙잡고 있어서 교체가 반쪽만 되고 끝난다.
# 반쪽 설치를 '완료'로 보고하면 원인 추적이 처음부터 헛돌기 때문에 여기서 멈춘다.
RUNNING=""
pgrep -f "/Adobe After Effects" >/dev/null 2>&1 && RUNNING="After Effects"
pgrep -f "/Adobe Premiere Pro" >/dev/null 2>&1 && RUNNING="$RUNNING Premiere Pro"
if [ -n "$RUNNING" ]; then
    echo "  [멈춤] 아직 켜져 있어요:$RUNNING"
    echo ""
    echo "  완전히 종료한 뒤 (Dock 에서도 확인) 다시 실행해 주세요."
    hold
    exit 1
fi

echo "  확장 폴더에 복사 중:"
echo "    $DEST"
echo ""

# 패널 내 업데이트가 남긴 com.batchrenamecomps.bak 은 같은 번들 ID 를 가진
# 두 번째 확장이라, 그대로 두면 CEP 가 패널을 두 번 띄운다.
rm -rf "$DEST.bak"
rm -rf "$DEST"

if [ -e "$DEST" ]; then
    echo "  [오류] 기존 설치를 지우지 못했어요:"
    echo "    $DEST"
    echo ""
    echo "  뭔가가 그 파일들을 붙잡고 있어요. After Effects 와 Premiere Pro 를"
    echo "  완전히 종료한 뒤 다시 실행해 주세요."
    hold
    exit 1
fi

mkdir -p "$DEST"
# "$SRC" 가 아니라 "$SRC/." — 대상이 이미 있을 때 폴더가 중첩 복사되는 것을 막는다.
if ! cp -R "$SRC/." "$DEST/"; then
    echo "  [오류] 복사에 실패했어요. 디스크 여유 공간을 확인하고 다시 시도해 주세요."
    hold
    exit 1
fi

echo "  CEP 디버그 모드 켜는 중 (서명 없는 확장 허용)..."
for V in 9 10 11 12; do
    defaults write "com.adobe.CSXS.$V" PlayerDebugMode 1 >/dev/null 2>&1
done
killall cfprefsd >/dev/null 2>&1

# 폴더 존재만 보면 예전 설치가 남아 있어도 '완료'가 뜬다. 실제로 필요한 파일을 확인한다.
MISSING=""
for f in "CSXS/manifest.xml" "client/index.html" "client/js/main.js" \
         "client/js/update.js" "host/hostscript.jsx"; do
    [ -f "$DEST/$f" ] || MISSING="$MISSING $f"
done

if [ -n "$MISSING" ]; then
    echo ""
    echo "  [오류] 설치가 덜 됐어요. 빠진 파일:$MISSING"
    echo "  이 화면을 팀장(구민석)에게 보여주세요."
    hold
    exit 1
fi

echo ""
echo "  설치 완료!"
echo "  After Effects / Premiere Pro 를 완전히 종료한 뒤 다시 실행하세요."
echo "  메뉴: 창 > 확장 > BatchRenameComps"
hold
exit 0
