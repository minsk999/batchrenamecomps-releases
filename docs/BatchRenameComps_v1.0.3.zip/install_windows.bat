@echo off
setlocal
title BatchRenameComps Installer

echo.
echo  ============================================
echo   BatchRenameComps Installer
echo   After Effects / Premiere Pro
echo  ============================================
echo.

set "SRC=%~dp0com.batchrenamecomps"
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.batchrenamecomps"

if not exist "%SRC%\CSXS\manifest.xml" (
    echo  [ERROR] Cannot find com.batchrenamecomps next to this file.
    echo  Please unzip the whole package and run this .bat from inside it.
    goto :fail
)

rem  Adobe apps hold the extension folder open. Copying over a running
rem  install half-succeeds and leaves a broken panel, so stop here instead.
set "RUNNING="
tasklist /fi "IMAGENAME eq AfterFX.exe" 2>nul | find /i "AfterFX.exe" >nul && set "RUNNING=After Effects"
tasklist /fi "IMAGENAME eq Adobe Premiere Pro.exe" 2>nul | find /i "Adobe Premiere Pro.exe" >nul && set "RUNNING=%RUNNING% Premiere Pro"
if defined RUNNING (
    echo  [STOP] Still running:%RUNNING%
    echo.
    echo  Quit them completely ^(check the taskbar and the tray^),
    echo  then run this installer again.
    goto :fail
)

echo  Installing extension to:
echo    %DEST%
echo.

rem  A leftover com.batchrenamecomps.bak is a second copy of the extension
rem  with the same bundle id, so CEP would list the panel twice. Clear it.
if exist "%DEST%.bak" rmdir /s /q "%DEST%.bak"
if exist "%DEST%"     rmdir /s /q "%DEST%"

if exist "%DEST%" (
    echo  [ERROR] Could not remove the previous install:
    echo    %DEST%
    echo.
    echo  Something is still holding those files. Quit After Effects and
    echo  Premiere Pro completely, then run this installer again.
    goto :fail
)

xcopy /e /i /y /q "%SRC%" "%DEST%" >nul
if errorlevel 1 (
    echo  [ERROR] Copying the extension failed.
    echo  Check that you have space on the drive and try again.
    goto :fail
)

echo  Enabling CEP debug mode (unsigned extension)...
for %%V in (9 10 11 12) do (
    reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
)

rem  Verify what the panel actually needs, not just that the folder exists -
rem  an old install would satisfy a bare "does the folder exist" check.
if not exist "%DEST%\CSXS\manifest.xml"   goto :incomplete
if not exist "%DEST%\client\index.html"   goto :incomplete
if not exist "%DEST%\client\js\main.js"   goto :incomplete
if not exist "%DEST%\client\js\update.js" goto :incomplete
if not exist "%DEST%\host\hostscript.jsx" goto :incomplete

echo.
echo  Installation complete!
echo  Quit After Effects / Premiere Pro completely, then reopen.
echo  Open via: Window ^> Extensions ^> BatchRenameComps
echo.
pause
endlocal
exit /b 0

:incomplete
echo.
echo  [ERROR] The install is missing files:
echo    %DEST%
echo  Please send this screen to the team lead.

:fail
echo.
pause
endlocal
exit /b 1
